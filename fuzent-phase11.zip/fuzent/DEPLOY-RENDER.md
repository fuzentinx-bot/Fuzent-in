# FUZENT free launch: Render + Supabase + your own domain

Hosting free. Sirf domain ka saal ka kharcha. Saare features chalte hain.

## Free plan ki limits (pehle jaan lo)
- Render free service 15 minute koi na aaye to so jati hai. Agle visitor ko pehli baar lagbhag 1 minute lag sakta hai. Neeche step 8 me ek free timer isse roke rakhta hai.
- CPU aur memory kam hain (512 MB). Chhote launch ke liye theek, bade traffic ke liye nahi.
- Supabase free project bahut din use na ho to pause ho sakta hai.
- Plan ki shartein (commercial use wagairah) Render ki site pe ek baar padh lo.

## Steps
1. **GitHub:** free account banao, ek *private* repo banao, project ka code upload karo. `.env` file kabhi upload mat karna.
2. **Supabase:** supabase.com pe free project banao. SQL Editor me `fuzent_schema_v1.sql`, phir `supabase/migrations/` ki 002 se 007 tak, order me chalao. Storage me *private* bucket `products` banao. Settings, API se URL, anon key aur service_role key copy karo.
3. **Render:** render.com pe account banao (GitHub se login). New, **Blueprint**, apni repo chuno. Woh values poochega (render.yaml me likhi hain). Bharo:
   - `NEXT_PUBLIC_SITE_URL` = `https://aapka-domain.in`
   - Supabase URL, anon key, service_role key
   - `CRON_SECRET` = koi lambi random text (kam se kam 32 akshar)
   - baaki (email wale) abhi khali chhod sakte ho
4. Deploy hone do (5 se 15 minute). Render aapko `xxxx.onrender.com` link dega. Pehle us pe check karo.
5. **Domain jodo:** Render me service ke Settings, Custom Domains me aapka domain add karo. Render jo DNS record dikhaye wahi domain ke panel me daalo. SSL apne aap lagta hai.
6. **Supabase me URL badlo:** Authentication, URL Configuration me Site URL = `https://aapka-domain.in`, Redirect URL = `https://aapka-domain.in/auth/callback`.
7. **Pehla admin:** site pe signup karo, email verify karo, README wali SQL chalao (super_admin), phir `/admin/settings` me UPI ID aur business details bharo.
8. **Sone se roko aur automation chalao:** cron-job.org (free) pe account banao. Naya job: URL `https://aapka-domain.in/api/cron/automation`, har 5 minute, header `Authorization: Bearer <aapka CRON_SECRET>`.
9. Poora flow test karo: signup, order, UPI payment, admin confirm, invoice.

## Baad me upgrade
- Render free se paid: service ko paid plan pe daalo, so jaana band ho jata hai. Code wahi rehta hai.
- Aur bada: `DEPLOY-VPS.md` wala chhota server, ya Vercel Pro.
- Supabase free se paid: dashboard me ek click.
- Aapka data Supabase me hai, isliye hosting badalne se kuch nahi khota.
