# FUZENT on one small server (VPS), about Rs 500 a month

Poora app (store, UPI checkout, dashboards, invoices, alerts, emails) isi tarah chalta hai.

## Kharcha (andaza)
- VPS: Ubuntu 24.04, kam se kam 2 GB RAM (4 GB behtar). Hetzner, Hostinger, IONOS, DigitalOcean jaise providers. Price badalte rehte hain, checkout pe confirm karo.
- Supabase: free plan se shuru. Traffic aur data badhe to paid plan.
- Resend (email): free plan. Domain: saal ka alag kharcha.

## Step 1: Server
1. Provider pe Ubuntu 24.04 server banao. Server ka IP note karo.
2. Domain ke DNS me do A records: `fuzent.in` aur `www` dono us IP pe.
3. Terminal se jao: `ssh root@SERVER-IP`
4. Chalao:
   ```
   apt update && apt upgrade -y
   curl -fsSL https://get.docker.com | sh
   ufw allow 22 && ufw allow 80 && ufw allow 443 && ufw --force enable
   fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
   echo '/swapfile none swap sw 0 0' >> /etc/fstab
   ```
   (Swap isliye ki build ke time memory kam na pade.)

## Step 2: Supabase
1. Naya project banao. SQL Editor me `fuzent_schema_v1.sql`, phir `supabase/migrations/` ki 002 se 007 tak order me chalao.
2. Storage me **private** bucket `products` banao.
3. Authentication, URL Configuration: Site URL `https://fuzent.in`, Redirect URL `https://fuzent.in/auth/callback`.
4. Project Settings, API se URL, anon key, service_role key lo.

## Step 3: Code server pe
1. Project folder server pe lao (GitHub private repo se `git clone`, ya zip ko `scp` se bhej ke unzip).
2. `cd fuzent`
3. `cp .env.production.example .env && chmod 600 .env` aur `nano .env` me sab values bharo.
   `CRON_SECRET` ke liye: `openssl rand -hex 32`
4. `docker compose up -d --build` (pehli baar 5 se 10 minute lag sakte hain).
5. `docker compose logs -f app` se dekho ki error to nahi. `https://fuzent.in` kholo. HTTPS apne aap ban jata hai (DNS sahi hone par).

## Step 4: Pehla admin
1. Site pe signup karo aur email verify karo.
2. Supabase SQL Editor me README wali SQL chalao (apna user id daalke, super_admin role).
3. `/admin/settings` me business UPI ID aur invoice details bharo.

## Roz ka kaam
- Update: `git pull && docker compose up -d --build`
- Logs: `docker compose logs --tail 100 app`
- Backup: `crontab -e` me daalo `0 3 * * * /root/fuzent/scripts/backup.sh` (path apne hisaab se). Backups `backups/` folder me. Kabhi kabhi unhe server ke bahar bhi copy karo.
- Uptime: UptimeRobot (free) se `https://fuzent.in` ko monitor karo.
- Security: server pe SSH key use karo, password login band karo, `.env` kabhi share mat karo.

## Jab traffic bade
Cloudflare free aage lagao (CDN aur bot protection). Phir bada VPS, ya Vercel Pro. Details `SCALING.md` me.
