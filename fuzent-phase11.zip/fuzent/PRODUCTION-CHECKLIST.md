# Production checklist (honest status)

PASSED = ran and passed. BLOCKED = cannot be verified without a running app or database. OPEN = work remains.

| Area | Status | Evidence / what is missing |
|---|---|---|
| Authentication Security | BLOCKED | Reset flow and generic errors added. Needs a running Supabase. Login limits and CAPTCHA are settings still to turn on |
| Authorization Security | BLOCKED | Static review plus fixes F-01 to F-04. Run `supabase/tests/rls_tests.sql` on staging |
| Database Security | BLOCKED | Same script. RLS present on every table by review |
| User Privacy | OPEN | Export and deletion request built. Policy text, retention rules, DPDP review missing |
| Payment Security | BLOCKED | Manual-confirmation design reviewed. Money logic PASSED (unit tests). End-to-end not run |
| Refund Reliability | BLOCKED | Locking trigger added. Not run |
| API Security | BLOCKED | Reviewed. E2E written, not run |
| QR Security | PASSED (logic) / BLOCKED (runtime) | Link builder and VPA checks PASSED. A scan is never proof of payment: only admin confirmation marks paid |
| Admin Security | OPEN | Every admin action checks `requireAdmin` (script-verified). MFA and idle timeout missing |
| File Upload Security | N/A | The app has no user uploads. Product files are uploaded by you in Supabase |
| Error Handling | BLOCKED | Error pages and health route added. Not run |
| Duplicate Request Protection | BLOCKED | Unique indexes, idempotent confirm, order reuse. Not run |
| Backup and Recovery | BLOCKED | `scripts/backup.sh` and `RECOVERY.md`. Restore never tested |
| Automated Tests | PASSED (14 unit) / BLOCKED (e2e) | `npm test` passes. Playwright suites written, not run |
| Responsive Testing | NOT TESTED | Needs a browser: `npx playwright test` against staging |
| Performance Testing | NOT TESTED | `loadtest/k6-public.js` against staging |
| Monitoring | OPEN | `/api/health` and structured logs exist. Alerts not wired (use UptimeRobot and Supabase alerts) |
| Legal Pages | OPEN | Outlines only: `[YOUR POLICY TEXT]` |
| Production Configuration | BLOCKED | Never compiled. Remove `ignoreBuildErrors` after a clean build. Check env vars on the host |
