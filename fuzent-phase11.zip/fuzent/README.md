# FUZENT (Phase 1: foundation + auth)

Next.js 15, TypeScript, Tailwind 3, Supabase (Auth + Postgres).

## Setup
1. Create a Supabase project. In the SQL editor, run `fuzent_schema_v1.sql`.
2. Auth settings: enable Email and Google providers. Add redirect URL
   `http://localhost:3000/auth/callback` (and your production URL).
3. `cp .env.example .env.local` and fill in the Supabase URL and anon key.
4. `npm install` then `npm run dev`.
5. Sign up, verify your email, then make yourself admin in the SQL editor:

   insert into user_roles (user_id, role_id)
   select '<your-user-uuid>', id from roles where key = 'super_admin';

## What is here
- Session refresh and login gate for /dashboard and /admin (src/middleware.ts)
- Email sign-up and login, Google login, logout, verification callback
- Server-side validation (zod), safe redirects, security headers
- Role helper and admin layout guard (RLS is the second lock)
- Brand tokens in tailwind.config.ts, base components in globals.css

## Not built yet
Store, orders, payments, QR, invoices, automation, and the
other public pages. Each is its own phase; nothing is faked here.

## Needed later
Google OAuth client id and secret, Resend key.

---
# Phase 2 (revised): Store and direct UPI checkout

No third-party gateway. Customers pay straight into your business bank account by UPI.

## Setup
1. Run `supabase/migrations/002_upi_direct.sql` after `fuzent_schema_v1.sql`.
2. Create a PRIVATE storage bucket `products` and upload paid files there.
3. Optional dev data: `supabase/seed_dev_products.sql`.
4. `.env.local`: Supabase URL, anon key and `SUPABASE_SERVICE_ROLE_KEY`.
5. Log in as admin, open `/admin/settings`, save your business UPI ID and payee name.
   Until you do, checkout says payments are not set up.

## How a payment works
1. Buy now creates an order (price read from the database) and sends the customer to `/checkout/[orderId]`.
2. Checkout shows a UPI QR code, deep-link buttons (any UPI app, Google Pay, PhonePe, Paytm) and the UPI ID.
3. The customer pays, then enters the 12-digit UTR from their UPI app. One UTR can back only one payment.
4. The order shows "checking". An admin opens `/admin/payments`, compares the UTR and amount with the
   bank statement, and clicks Confirm (or Reject with a reason the customer sees).
5. Only that confirm action marks the order paid. Then downloads unlock (60-second signed links).

## Important limits
- Nothing here can see your bank. A QR scan, a screenshot or a typed UTR is NOT proof of payment;
  an admin must check the bank. Never confirm from a screenshot alone.
- Money lands in YOUR account. Holding customer money to pay creators or freelancers later may count
  as payment aggregation, which RBI regulates. Get advice before building marketplace payouts.
- App deep links (tez://, phonepe://, paytmmp://) depend on the app being installed and can change.
- Use a business or current account UPI ID, and keep GST and invoice records with an accountant.

## Next options
Automatic confirmation needs a bank or payment-provider API later. The `markPaid` function is the
single place to plug it in. Also to do: cart, coupons, refunds, invoices, rate limiting, expiry for
unpaid orders, emails.

---
# Phase 3: cart, coupons, refunds, invoices

Run `supabase/migrations/003_cart_coupons_refunds_invoices.sql` after 002, then `npm install` (adds pdf-lib).

- **Cart** (`/cart`): add from a product page, change quantity, remove, apply a coupon, go to checkout.
  Totals are always recomputed on the server from database prices.
- **Coupons** (`/admin/coupons`): percent or rupee-off, minimum order, max uses, expiry, one use per customer,
  enable/disable. Validated on the server; the last redemption is claimed atomically.
- **Refunds** (`/admin/orders`): send the money back from your UPI/bank app, then record it (full or partial,
  optional refund UTR). A full refund sets the order to refunded and blocks downloads. Every refund is audit-logged.
- **Invoices**: created automatically when an admin confirms a payment (one per order). PDF at
  `/api/invoices/[id]/pdf`, listed at `/invoices`, linked from each paid order. Fill in `/admin/settings`
  first (name, address, GSTIN, SAC, GST rate).

## Limits
- GST is configuration, not compliance. Prices are treated as GST-inclusive; intra-state splits CGST/SGST,
  inter-state uses IGST when the buyer's billing state is known. An accountant must validate this.
- No credit notes yet for refunds; the original invoice stays as issued.
- PDF uses standard fonts (shows "Rs." instead of the rupee sign, basic characters only).
- Still to do: rate limiting, expiry for unpaid orders, emails, product detail galleries.

---
# Phase 4: creators, brands and freelance

Run `supabase/migrations/004_creators_freelance.sql` after 003.

- **Creators**: `/creators` (open campaigns and approved creators), `/creators/join` (apply), `/creators/[handle]` (public profile).
- **Brands**: `/brand/new` (register), `/brand` (post campaigns once approved, see applicants, accept or reject).
- **Campaigns**: `/campaigns/[id]`; only approved creators can apply.
- **Freelance**: `/freelance`, `/freelance/join`, `/freelance/[id]` (profile with reviews).
- **Projects**: `/projects/new` (post), `/projects/[id]` (apply, accept a freelancer, mark complete, review).
- **Messages**: `/messages`. A conversation opens automatically when an application is accepted.
- **Admin**: `/admin/approvals` approves or rejects creators, freelancers, brands and campaigns. Approval grants the role.

## How it stays safe
- Nobody can approve themselves: a database trigger blocks status changes by non-admins.
- Accept, reject, assign and review run as server actions that check ownership first.
- Only https links are accepted for portfolios and websites; profile text is escaped by React.
- Open projects are visible only to logged-in users. Contact details are never shown; people talk in messages.

## Limits and still to do
- Payment between client and freelancer or brand and creator is NOT handled here. Holding their money
  may count as payment aggregation under RBI rules; get advice before building escrow or payouts.
- No notifications UI or email yet (events are queued in automation_events). Messages refresh every few seconds.
- No file uploads for portfolios yet (links only). No profile editing page yet. Admin cannot yet close an open project.

---
# Phase 5: support, alerts, emails, service pages, SEO

Run `supabase/migrations/005_support_notifications.sql` after 004. New env vars are in `.env.example`.

- **Support**: `/support` (open a ticket, reply), `/admin/support` (inbox, reply, resolve or close). Contact-form messages show in the same inbox.
- **Alerts**: `/notifications` and an Alerts link in the header with an unread count.
- **Emails** (Resend): payment confirmed, payment to verify, refund, accepted or rejected, project assigned, ticket replies.
  Without `RESEND_API_KEY` and `EMAIL_FROM`, emails are skipped and logged in `email_log`; in-app alerts still work.
- **Automation engine** (`src/lib/automation.ts`): actions queue events in `automation_events`; handlers turn them into alerts and emails.
  Each event is claimed before it runs and retried up to 5 times. Key actions process the queue right away; also set a cron
  (any free cron service, every minute) to call `GET /api/cron/automation` with header `Authorization: Bearer <CRON_SECRET>`.
- **Service pages**: `/makepro` and `/digixbite` list active services from the `services` table and take a project brief
  (saved as a project, admins are alerted). `/solutions`, `/pricing`, `/about`, `/faq`, `/contact`, footer, `robots.txt`, `sitemap.xml`.
- **Rate limits**: tickets and contact messages are capped at 5 per hour per user or email.

## Limits and still to do
- Legal pages are outlines marked `[YOUR POLICY TEXT]`. A lawyer must write them. Pricing commission terms are a placeholder.
- No welcome email on sign-up yet, no blog or careers pages, no admin screen for services, products or projects (use SQL or Supabase for now).
- No general rate limiting on login (turn on Supabase Auth rate limits and CAPTCHA in the dashboard).
- Still to do: admin product and service management, testing, and deployment.

---
# Phase 6: dashboard redesign (sidebar on desktop, bottom bar on phones)

Run `supabase/migrations/006_dashboards.sql` after 005.

- Shared shell and widgets: `src/components/dash/` (nav, KPI cards, bar and donut charts, activity feed, status pills).
- **Admin** (`/admin/*`), **My account** (`/dashboard`, `/orders`, `/invoices`, `/messages`, `/notifications`, `/support`),
  **Freelancer hub** (`/freelancer/*`: overview, find work, applications, settings) and **Brand hub**
  (`/brand/*`: overview, campaigns, applicants, hire talent, settings) all use it. Sidebar badges show pending work.
- Settings pages: edit profile or brand, freelancer availability, notification preferences (email and in-app).
  The automation engine now respects those preferences.
- Charts use real data only and show empty states; nothing is invented.
- The account pages moved into a `(account)` route group. URLs did not change.

---
# Phase 7: ready for traffic
Run `supabase/migrations/007_scale.sql`. Read `SCALING.md` for the launch plan and use `loadtest/k6-public.js` on staging.

---
# Phase 8: self-host on one small server
See `DEPLOY-VPS.md`. Files: `Dockerfile`, `docker-compose.yml`, `Caddyfile`, `.env.production.example`, `scripts/backup.sh`.

---
# Phase 9: free launch on Render
See `DEPLOY-RENDER.md` and `render.yaml`.

---
# Phase 10: one-file Supabase setup
`supabase/setup_all.sql` runs everything in one go; `supabase/make_admin.sql` makes the first admin. Follow `START-HERE.md`.

---
# Phase 11: security audit and hardening
Read `SECURITY-AUDIT.md` and `PRODUCTION-CHECKLIST.md`. Run `supabase/migrations/008_security_hardening.sql` (already inside `supabase/setup_all.sql`).
Tests: `npm test` (unit, no install needed on Node 22) and `npm run test:e2e` (Playwright, staging only). Database checks: `supabase/tests/rls_tests.sql` on staging.
