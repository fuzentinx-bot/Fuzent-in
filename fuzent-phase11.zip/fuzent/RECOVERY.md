# If something breaks

1. **Site down:** check `/api/health`. On Render open Logs. Redeploy the last good commit (Render: Manual Deploy, pick a previous deploy).
2. **Database trouble:** Supabase dashboard, Reports and Logs. A paused free project: click Restore.
3. **Bad deploy:** revert the commit on GitHub; Render redeploys.
4. **Lost data:** restore from the newest file in `backups/` (made by `scripts/backup.sh`) or from the Supabase plan backup, into a NEW project first and check it before switching.
5. **Payments look wrong:** do not confirm anything in a hurry. Compare each order with the bank statement. The `audit_logs` table shows who confirmed or refunded what.
6. **Leaked key:** Supabase, Project Settings, API: reset the service-role key, update it on the host, redeploy. Rotate `CRON_SECRET` too.
7. **Test a restore once before launch.** A backup you have never restored is only a hope.
