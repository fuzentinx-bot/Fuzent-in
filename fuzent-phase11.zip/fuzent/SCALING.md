# FUZENT: going live for large traffic

Plan for peaks, not averages. "1 lakh users" is rarely 1 lakh at once; test the real peak (a viral post, a sale).

## What is already done in the code
- Public pages (home, store, creators, pricing, FAQ) need no login check, so they can be cached and served from a CDN.
- The header runs in the browser, so no page waits on an auth call. Middleware only guards private pages.
- Catalog lists are cached for 60 seconds (`src/lib/public-data.ts`), refreshed when an admin approves something.
- Indexes and cheaper row-level-security checks: `supabase/migrations/007_scale.sql`.
- Load test script: `loadtest/k6-public.js`.

## Architecture
Visitors -> Cloudflare (DNS, CDN, WAF, rate limits, bot challenge) -> Next.js on Vercel or Cloudflare (auto-scales)
-> Supabase (Postgres with the connection pooler, Auth, Storage). Resend for email. Sentry for errors.

## Before launch
1. Run migrations 001 to 007 on the production project, not a copy.
2. Use the pooled database connection string for anything server-side that talks to Postgres directly.
3. Put Cloudflare in front; turn on bot protection and rate limits for /login, /contact and the forms.
4. Turn on Supabase Auth CAPTCHA and rate limits.
5. Paid Supabase plan (backups, bigger compute). Check current plan limits and prices on their site before choosing.
6. Load test staging with k6 until the thresholds pass; watch database CPU and connections while it runs.
7. Add error monitoring, uptime alerts and a status page.

## Stages
- Up to about 10k users: Vercel or Cloudflare plus a small paid Supabase. Mostly cached public pages.
- About 100k users: bigger database compute, read replica for heavy reads, Redis for rate limits and hot data, queue for email and automation.
- Lakhs of users: dedicated database sizing, search service for the catalog, image CDN, a licensed payment gateway with automatic confirmation.

## Known limits to fix as you grow
- Payments are confirmed by hand. This is the first thing that breaks. Move to a licensed gateway with automatic confirmation.
- Messages and order pages refresh by polling. Switch to Supabase Realtime when many people are online at once.
- The automation queue runs from a cron. Use a proper queue when volume rises.
- Dashboard pages query live data per visit; add caching or summary tables when admins have large order tables.
