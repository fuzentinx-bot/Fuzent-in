# FUZENT security audit report

Method: static review of the real source (118 source files, 8 SQL files, deployment files) plus 14 automated checks of the pure logic.
**Not done, because it is not possible in this environment:** running the app, running Postgres or Supabase, running a browser, installing packages, `npm audit`.
Nothing here is a claim of 100% security.

Status words used: **Tested and Passed** (ran, passed) / **Tested and Failed** / **Fixed and Retested** (only for logic that was re-run) / **Fixed, retest BLOCKED** (changed in code or SQL, cannot be run here) / **Not Tested** / **Blocked**.

## A. Executive summary
- No CRITICAL issue was found by static review. Several HIGH and MEDIUM issues were found and fixed in code (see L).
- The riskiest area was **rules enforced only in the app but not in the database** (anyone with a login can call the database API directly). Migration 008 moves the key rules into the database.
- The design has **no payment gateway**. Money is confirmed by a person comparing the bank statement. That is safe against fake payments, but slow and error-prone at volume.
- **Production readiness: NOT READY** (see N). The fixes have never been run against a real database, and the app has never been compiled.

## Architecture discovered
Next.js 15 (server actions + a few API routes) on Node, Supabase Auth + Postgres (Row Level Security) + Storage, direct-UPI checkout with admin confirmation, email via Resend, automation queue in Postgres processed by a cron call. The browser holds only the anon key; the service-role key is used only by server-only code (`src/lib/supabase/admin.ts`, 25 server files, none are client components).

## B. Critical vulnerabilities
None found by static review. Not tested dynamically.

## C. High risk issues
| ID | Finding | Where | Impact | Fix | Status |
|---|---|---|---|---|---|
| F-01 | Applying to campaigns or projects was only checked in app code. The database allowed any logged-in user to insert applications for any campaign or project, including not being approved, or to their own project. | `supabase/migrations/004` policy `app_ins` | Bypass of approval rules, spam, fake applicants | New policy requires approved creator or freelancer, and an open, approved target (`008`) | Fixed, retest BLOCKED. Script: `supabase/tests/rls_tests.sql` |
| F-02 | A freelancer could edit their own `rating_avg` directly. | `004` policy `own_upd` on `freelancers` | Fake ratings, trust fraud | Trigger blocks non-admin changes (`008`) | Fixed, retest BLOCKED |
| F-20 | No way to export or delete personal data (DPDP expectation). | whole app | Compliance gap | Export (`/api/account/export`) and deletion request workflow (`/my-data`) added. Retention rules still need a lawyer | Partly fixed. Retest BLOCKED |
| F-21 | No MFA and no idle timeout for admins. | admin area | Admin account takeover impact is large | **Not fixed.** Turn on Supabase MFA and require it for admins (next step) | Open |

## D. Medium risk issues
| ID | Finding | Where | Fix | Status |
|---|---|---|---|---|
| F-03 | Users could edit `profiles.email` and `is_active`; alerts and admin screens trust that email. | `v1` policy `own_upd` | Trigger blocks it (`008`) | Fixed, retest BLOCKED |
| F-04 | A new project could be inserted with someone already assigned or a non-marketplace division. | `004` policy `client_ins` | Policy tightened (`008`) | Fixed, retest BLOCKED |
| F-05 | Two refunds submitted at once could exceed the order total (read then write). | `src/app/admin/orders/actions.ts` | Locking trigger sums refunds in the database; refund UTR unique (`008`) | Fixed, retest BLOCKED |
| F-06 | Repeated clicks created duplicate unpaid orders; no cap per user. | `src/app/store/actions.ts`, `cart/actions.ts` | Reuse unpaid order (30 min), cap 20 orders per hour, one payment row per order | Fixed, retest BLOCKED |
| F-07 | `markPaid` accepted a payment that had no transaction ID. | `src/lib/payments.ts` | Only `pending` payments with a UTR can be confirmed | Fixed, retest BLOCKED |
| F-08 | No password reset. | auth | Reset flow added: `/login/forgot`, `/reset-password`; same answer for any email; other devices signed out after a change | Fixed, retest BLOCKED |
| F-09 | Unpaid orders never expired; coupon uses stayed locked. | none | Expiry job after 48 hours (never touches orders with a UTR) inside the cron call | Fixed, retest BLOCKED |
| F-10 | No timeout on outbound calls (database, email). | clients | 10 s timeout on every Supabase call, 8 s on email | Fixed, retest BLOCKED |
| F-11 | Guessable actions had no limits: coupon codes, UTR submissions, order creation, login. | cart, checkout, auth | Coupon 10 per 10 min, UTR max 5 waiting, orders 20 per hour. Login: use Supabase Auth limits and CAPTCHA (settings, not code) | Partly fixed. Login limits Open |
| F-22 | Browser session cookies are readable by page scripts (needed by the browser client). | `src/lib/supabase/client.ts` | Accepted trade-off; mitigated by React escaping and no raw HTML sinks (0 found). Add a full CSP with nonces later | Accepted risk |
| F-25 | After email or Google login, the redirect could use the internal server address behind a proxy. | `src/app/auth/callback/route.ts` | Uses `NEXT_PUBLIC_SITE_URL` | Fixed, retest BLOCKED |

## E. Low risk issues
F-12 support ticket could name another person's order (fixed: ownership check). F-13 private file path and seller id readable through the public API (fixed: column permissions, `008`). F-14 alerts could be rewritten by their owner (fixed: only `read_at` editable). F-15 cron secret compared in non-constant time (fixed). F-16 download id not validated (fixed). F-17 missing HSTS, Permissions-Policy and partial CSP (fixed: `next.config.mjs`; full script policy still open). F-18 no friendly error pages or health check (fixed). F-19 product under Rs 1 could be bought (fixed). **All Fixed, retest BLOCKED.**

## Informational
F-23 `typescript.ignoreBuildErrors` and `eslint.ignoreDuringBuilds` are ON for the first launch because the code was never compiled. Remove them after a clean local `npm run build`. F-24 stock testing: **not applicable**, products are digital with no inventory model. If you add limited stock later, it needs atomic reservation.

## F. Payment reliability report
There is no gateway, so there are no webhooks, no signatures and no gateway timeouts to test. Scenario results by design:
- Frontend never marks paid: **by design, confirmed by reading `markPaid` (only caller is the admin action `confirmPayment`)**. Runtime test BLOCKED.
- Callback missing / customer closes browser / payment pending long: order stays `created` or `pending`; admin queue shows pending ones; unpaid ones expire after 48 h (F-09).
- Wrong or reused transaction ID: unique index on UTR rejects reuse; admin compares with bank. Wrong amount: **a person must check** (no machine check).
- Duplicate confirm clicks: second call changes nothing (`status = pending` filter). Duplicate invoice: unique per order.
- Reconciliation: manual from the bank statement. **Not automated.** Needs a gateway or bank API to scale.

## G. User privacy report
Data held: name, email, phone (forms), orders, invoices, UPI transaction IDs, messages, tickets. No card data or UPI PINs are ever collected. Row Level Security limits reads to the owner (static review; runtime test BLOCKED). No personal data in logs (`src/lib/log.ts` logs only names and ids). Export and deletion request added. **Open:** retention policy text, privacy and cookie policy text (placeholders), consent records, DPDP assessment with a lawyer.

## H. Database security report
RLS is on for every table. Policy gaps found and fixed: F-01 to F-04, F-13, F-14. Role promotion: there is no insert policy on `user_roles`, so a user cannot make themselves admin (static review; `rls_tests.sql` checks it). Backups: Supabase plan backups plus `scripts/backup.sh`; **restore never tested**.

## I. API security report
All 6 admin server-action files call `requireAdmin()` (checked by script). Ownership checks exist for accept, reject, assign, review. No `dangerouslySetInnerHTML`, `eval` or raw HTML sinks (0 found). No server fetch of user-supplied URLs (no SSRF path). CSRF: Next.js server actions check the request origin; the only state-changing GET is the cron route, protected by a secret. Anonymous access to `/api/account/export`, `/api/cron/automation`, `/api/download/*` is covered by `tests/e2e/public.spec.ts` (written, not run).

## J. Responsive testing report
**Not Tested.** No browser is available here. `tests/e2e/public.spec.ts` checks all 17 required widths for sideways scrolling on 12 public pages. Run it against staging.

## K. Performance report
**Not Tested** (nothing could be measured). Reviewed: public pages avoid auth calls, catalog queries cached 60 s, indexes in `007`. Run `loadtest/k6-public.js` on staging.

## L. Fixed issues
F-01 to F-19 and F-25 as listed above. Logic re-run and passing (**Fixed and Retested**): discount maths, GST split (no lost paise), UPI link builder and VPA validation, redirect safety, https-only links, limiter. 14 checks: `npm test`.

## M. Remaining issues
F-21 admin MFA and idle timeout. Login brute-force limits (Supabase and Cloudflare settings). Full CSP. Retention, privacy and cookie policy text. Dependency audit. Monitoring alerts (health endpoint and logs exist, no alert wiring). Real restore test. A payment gateway or bank API for automatic confirmation.

## N. Production readiness assessment
**NOT READY.** Blockers: never compiled; SQL (including 008) never run against a database; end-to-end flows never exercised; admin MFA missing; legal text missing; no tested backup restore. See `PRODUCTION-CHECKLIST.md`. Suggested order: run `setup_all.sql` on a staging project, run `supabase/tests/rls_tests.sql`, build and deploy staging, run Playwright, turn on admin MFA, then a small invited launch.
