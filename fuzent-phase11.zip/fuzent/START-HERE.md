# FUZENT: shuru yahan se (Supabase + Render + apna domain)

Aapke paas Supabase account hai. Baaki yeh karo, is order me.

## A. Supabase (database)  ~10 minute
1. supabase.com, **New project**. Name `fuzent`, ek strong database password (kahin likh lo), region sabse paas ka. Create.
2. Left menu **SQL Editor**, New query. File `supabase/setup_all.sql` poori kholo, sab copy karke paste karo, **Run**.
   "Success" aana chahiye. Error aaye to error ka text mujhe bhejo. Kuch aadha nahi banta, isliye theek karke dobara Run kar sakte ho.
3. **Project Settings, API** se 3 cheezein copy karke ek notepad me rakho:
   - Project URL
   - anon public key
   - service_role key (SECRET: kisi ko mat dikhana)
4. **Authentication, Providers, Email**: shuru me "Confirm email" band rakh sakte ho (testing aasan). Launch se pehle on karo aur SMTP (Resend) lagao, kyunki Supabase ka built-in email bahut kam bhejta hai.

## B. GitHub (code ka ghar)  ~10 minute
1. github.com pe free account, **New repository**, naam `fuzent`, **Private**.
2. Is project zip ko computer pe extract karo. Repo me **uploading an existing file** se saari files daalo.
   `.env` jaisi file kabhi upload mat karna.

## C. Render (website chalane wala)  ~15 minute
Poori detail `DEPLOY-RENDER.md` me hai. Chhota version:
1. render.com, GitHub se login. **New, Blueprint**, repo `fuzent` chuno.
2. Jo values maange: `NEXT_PUBLIC_SITE_URL` (abhi `https://xxxx.onrender.com` ya apna domain), Supabase URL, anon key, service_role key, `CRON_SECRET` (lambi random text).
3. Deploy. 5 se 15 minute. Link milega.

## D. Domain jodo
Render, Settings, Custom Domains, apna domain add. Render jo DNS record bataye wahi domain ke panel me daalo.
Phir Render me `NEXT_PUBLIC_SITE_URL` ko `https://aapka-domain.in` karo (redeploy hoga).

## E. Supabase me domain batao
**Authentication, URL Configuration**: Site URL = `https://aapka-domain.in`. Redirect URLs me `https://aapka-domain.in/auth/callback`.

## F. Pehla admin
1. Apni site pe **signup** karo (email verify karo agar on hai).
2. Supabase SQL Editor me `supabase/make_admin.sql` kholo, email badlo, Run.
3. Site pe `/admin/settings` kholo: business UPI ID aur invoice details bharo.

## G. Automation (alerts, emails)
cron-job.org (free): har 5 minute `https://aapka-domain.in/api/cron/automation`, header `Authorization: Bearer <CRON_SECRET>`.

## H. Test
Signup, ek test product (optional: `supabase/seed_dev_products.sql`), order, UPI payment, admin se confirm, invoice.
