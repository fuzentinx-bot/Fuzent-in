-- =====================================================================
-- FUZENT  |  Database schema v1  |  Supabase / PostgreSQL
-- Money is stored in paise (integer). Currency: INR.
-- Payments/payment_events are written ONLY by the server (service role).
-- Run in order. Review every policy before going live.
-- =====================================================================

create extension if not exists pgcrypto;
create extension if not exists citext;

-- ---------- ENUMS ----------------------------------------------------
create type division        as enum ('digital','makepro','digixbite','creators','freelance');
create type approval_status as enum ('pending','approved','rejected','suspended');
create type order_status    as enum ('pending','confirmed','processing','in_progress','under_review','completed','cancelled','refunded');
create type payment_status  as enum ('created','pending','paid','failed','refunded','partially_refunded');
create type invoice_status  as enum ('draft','issued','paid','void');
create type project_status  as enum ('not_started','in_progress','under_review','completed','on_hold','cancelled');
create type qr_type         as enum ('payment','order','business','custom');
create type ticket_status   as enum ('open','pending','resolved','closed');
create type application_status as enum ('submitted','shortlisted','accepted','rejected','withdrawn');

-- ---------- HELPERS --------------------------------------------------
create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- IDENTITY & RBAC -----------------------------------------
create table roles (
  id          smallint primary key generated always as identity,
  key         text unique not null,   -- super_admin, admin, customer, freelancer, creator, brand, business_client
  label       text not null
);
insert into roles (key,label) values
  ('super_admin','Super Admin'),('admin','Administrator'),('customer','Customer'),
  ('freelancer','Freelancer'),('creator','Creator'),('brand','Brand'),('business_client','Business Client');

create table permissions (
  id    int primary key generated always as identity,
  key   text unique not null           -- e.g. orders.read_all, products.write
);
create table role_permissions (
  role_id       smallint references roles(id) on delete cascade,
  permission_id int references permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

create table profiles (               -- 1:1 with auth.users
  id          uuid primary key references auth.users(id) on delete cascade,
  email       citext unique not null,
  full_name   text,
  phone       text,
  avatar_url  text,
  city        text,
  locale      text not null default 'en',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger trg_profiles_upd before update on profiles for each row execute function set_updated_at();

create table user_roles (
  user_id uuid references profiles(id) on delete cascade,
  role_id smallint references roles(id) on delete cascade,
  granted_at timestamptz not null default now(),
  primary key (user_id, role_id)
);
create index on user_roles (role_id);

-- Auto-create profile + default 'customer' role on signup
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  insert into user_roles (user_id, role_id)
  select new.id, id from roles where key = 'customer';
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Role checks (security definer avoids RLS recursion)
create or replace function has_role(_key text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles ur join roles r on r.id = ur.role_id
                 where ur.user_id = auth.uid() and r.key = _key);
$$;
create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles ur join roles r on r.id = ur.role_id
                 where ur.user_id = auth.uid() and r.key in ('admin','super_admin'));
$$;

-- ---------- ROLE PROFILES -------------------------------------------
create table customers (               -- billing identity for customers / business clients
  user_id      uuid primary key references profiles(id) on delete cascade,
  company_name text,
  gstin        text,
  billing_address jsonb,
  created_at   timestamptz not null default now()
);

create table creators (
  user_id      uuid primary key references profiles(id) on delete cascade,
  handle       text unique not null,
  bio          text,
  niche        text[],
  social_links jsonb not null default '{}',   -- {instagram:'', youtube:''}
  portfolio    jsonb not null default '[]',
  status       approval_status not null default 'pending',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create table freelancers (
  user_id      uuid primary key references profiles(id) on delete cascade,
  headline     text,
  skills       text[],
  experience   text,
  portfolio    jsonb not null default '[]',
  hourly_rate_paise int,
  status       approval_status not null default 'pending',
  rating_avg   numeric(3,2) not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create table brands (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null references profiles(id) on delete cascade,
  name         text not null,
  website      text,
  industry     text,
  logo_url     text,
  status       approval_status not null default 'pending',
  created_at   timestamptz not null default now()
);
create index on brands (owner_id);

-- ---------- CATALOG --------------------------------------------------
create table product_categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null, name text not null, sort_order int not null default 0
);
create table products (                -- Fuzent Digital
  id            uuid primary key default gen_random_uuid(),
  category_id   uuid references product_categories(id),
  seller_id     uuid references profiles(id),     -- null = FUZENT; set for creator-sold products
  slug          text unique not null,
  title         text not null,
  description   text,
  price_paise   int not null check (price_paise >= 0),
  file_path     text,                              -- private storage path, never public
  cover_url     text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on products (category_id);
create index on products (seller_id);

create table service_categories (
  id uuid primary key default gen_random_uuid(),
  division division not null check (division in ('makepro','digixbite')),
  slug text unique not null, name text not null
);
create table services (                -- MakePro / DigixBite packages
  id            uuid primary key default gen_random_uuid(),
  category_id   uuid references service_categories(id),
  division      division not null check (division in ('makepro','digixbite','freelance')),
  provider_id   uuid references profiles(id),      -- freelancer for marketplace listings
  slug          text unique not null,
  title         text not null,
  description   text,
  price_paise   int,                               -- null = custom quote
  billing       text not null default 'one_time',  -- one_time | monthly
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

create table coupons (
  id uuid primary key default gen_random_uuid(),
  code citext unique not null,
  percent_off smallint check (percent_off between 1 and 100),
  amount_off_paise int,
  valid_from timestamptz, valid_until timestamptz,
  max_redemptions int, redeemed int not null default 0,
  is_active boolean not null default true
);

-- ---------- ORDERS & PAYMENTS ---------------------------------------
create sequence order_seq start 1001;
create table orders (                  -- single table for all divisions
  id            uuid primary key default gen_random_uuid(),
  order_no      text unique not null default ('FZ-' || to_char(now(),'YY') || '-' || nextval('order_seq')),
  customer_id   uuid not null references profiles(id),
  division      division not null,
  status        order_status not null default 'pending',
  payment_status payment_status not null default 'created',
  subtotal_paise int not null check (subtotal_paise >= 0),
  discount_paise int not null default 0,
  tax_paise      int not null default 0,
  total_paise    int not null check (total_paise >= 0),
  coupon_id     uuid references coupons(id),
  requirements  jsonb not null default '{}',
  admin_notes   text,                              -- internal only
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on orders (customer_id, created_at desc);
create index on orders (status);
create trigger trg_orders_upd before update on orders for each row execute function set_updated_at();

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id),
  service_id uuid references services(id),
  title_snapshot text not null,
  unit_price_paise int not null,
  quantity int not null default 1 check (quantity > 0),
  check (num_nonnulls(product_id, service_id) = 1)
);
create index on order_items (order_id);

create table payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id),
  gateway text not null default 'upi_direct',
  gateway_order_id text unique,   -- unused with direct UPI
  gateway_payment_id text unique,
  method text,                                    -- upi, card, netbanking, wallet
  amount_paise int not null,
  status payment_status not null default 'created',
  failure_reason text,
  verified_at timestamptz,                        -- set ONLY after webhook/API verification
  created_at timestamptz not null default now()
);
create index on payments (order_id);

create table payment_events (          -- raw webhook log, idempotency
  id uuid primary key default gen_random_uuid(),
  gateway_event_id text unique not null,
  payment_id uuid references payments(id),
  event_type text not null,
  payload jsonb not null,
  signature_valid boolean not null,
  processed_at timestamptz,
  created_at timestamptz not null default now()
);

create table invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_no text unique not null,
  order_id uuid not null references orders(id),
  customer_id uuid not null references profiles(id),
  status invoice_status not null default 'draft',
  seller_gstin text, buyer_gstin text,
  sac_hsn text,
  subtotal_paise int not null, discount_paise int not null default 0,
  cgst_paise int not null default 0, sgst_paise int not null default 0, igst_paise int not null default 0,
  total_paise int not null,
  pdf_path text,
  issued_at timestamptz,
  created_at timestamptz not null default now()
);
create index on invoices (customer_id);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  service_id uuid references services(id),
  gateway_subscription_id text unique,
  status text not null default 'active',
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

-- ---------- QR -------------------------------------------------------
create table qr_codes (
  id uuid primary key default gen_random_uuid(),
  type qr_type not null,
  label text,
  order_id uuid references orders(id),
  target_url text,                                -- for order/business/custom
  upi_payload jsonb,                              -- merchant VPA, name, amount, ref (payment QR)
  style jsonb not null default '{}',              -- colors, logo, size
  is_active boolean not null default true,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);
create table qr_scans (
  id bigint primary key generated always as identity,
  qr_id uuid not null references qr_codes(id) on delete cascade,
  scanned_at timestamptz not null default now(),
  user_agent text, country text
);
create index on qr_scans (qr_id, scanned_at desc);

-- ---------- PROJECTS & MARKETPLACE ----------------------------------
create table projects (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id),
  division division not null,
  client_id uuid not null references profiles(id),
  assignee_id uuid references profiles(id),
  title text not null, brief text,
  status project_status not null default 'not_started',
  budget_paise int, due_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on projects (client_id);
create index on projects (assignee_id);
create table project_milestones (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null, due_date date,
  status project_status not null default 'not_started',
  sort_order int not null default 0
);
create table campaigns (               -- brand -> creator collaborations
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references brands(id) on delete cascade,
  title text not null, brief text,
  budget_paise int, deliverables jsonb not null default '[]',
  status text not null default 'draft',          -- draft | open | closed
  approval approval_status not null default 'pending',
  created_at timestamptz not null default now()
);
create table applications (            -- creators->campaigns, freelancers->projects
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null references profiles(id) on delete cascade,
  campaign_id uuid references campaigns(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  pitch text, quote_paise int,
  status application_status not null default 'submitted',
  created_at timestamptz not null default now(),
  check (num_nonnulls(campaign_id, project_id) = 1),
  unique (applicant_id, campaign_id), unique (applicant_id, project_id)
);
create table reviews (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles(id) on delete cascade,
  product_id uuid references products(id), service_id uuid references services(id),
  freelancer_id uuid references freelancers(user_id),
  order_id uuid references orders(id),           -- verified-purchase link
  rating smallint not null check (rating between 1 and 5),
  body text, is_published boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- COMMUNICATION -------------------------------------------
create table conversations (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id), project_id uuid references projects(id),
  created_at timestamptz not null default now()
);
create table conversation_members (
  conversation_id uuid references conversations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (conversation_id, user_id)
);
create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  body text not null, attachments jsonb not null default '[]',
  created_at timestamptz not null default now()
);
create index on messages (conversation_id, created_at);
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text not null, body text, link text,
  read_at timestamptz, created_at timestamptz not null default now()
);
create index on notifications (user_id, created_at desc);
create table support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  order_id uuid references orders(id),
  subject text not null, body text not null,
  status ticket_status not null default 'open',
  created_at timestamptz not null default now()
);

-- ---------- OPS ------------------------------------------------------
create table automation_events (       -- queue for the automation engine
  id uuid primary key default gen_random_uuid(),
  event_type text not null,            -- order.created, payment.verified, ...
  payload jsonb not null,
  attempts int not null default 0,
  processed_at timestamptz, error text,
  created_at timestamptz not null default now()
);
create index on automation_events (processed_at) where processed_at is null;
create table audit_logs (
  id bigint primary key generated always as identity,
  actor_id uuid, action text not null, entity text, entity_id text,
  meta jsonb, created_at timestamptz not null default now()
);
create table website_settings (
  key text primary key, value jsonb not null, updated_at timestamptz not null default now()
);

-- =====================================================================
-- ROW LEVEL SECURITY  (deny by default, then allow)
-- =====================================================================
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- Admin: full access on everything except secrets-by-design tables handled below
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public'
           and tablename not in ('payments','payment_events','audit_logs') loop
    execute format('create policy admin_all on public.%I for all using (is_admin()) with check (is_admin())', t);
  end loop;
end $$;
create policy admin_read on payments        for select using (is_admin());
create policy admin_read on payment_events  for select using (is_admin());
create policy admin_read on audit_logs      for select using (is_admin());
-- No insert/update policies on payments, payment_events, audit_logs:
-- only the server (service role) can write them.

-- Public catalog
create policy public_read on product_categories for select using (true);
create policy public_read on service_categories for select using (true);
create policy public_read on products  for select using (is_active);
create policy public_read on services  for select using (is_active);
create policy public_read on website_settings for select using (key like 'public.%');
create policy public_read on reviews   for select using (is_published);
create policy public_read on creators  for select using (status = 'approved');
create policy public_read on freelancers for select using (status = 'approved');
create policy public_read on campaigns for select using (approval = 'approved' and status = 'open');

-- Own-data policies
create policy own on profiles for select using (id = auth.uid());
create policy own_upd on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy own on user_roles for select using (user_id = auth.uid());
create policy own on customers  for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own on creators   for all using (user_id = auth.uid()) with check (user_id = auth.uid() and status = 'pending');
create policy own on freelancers for all using (user_id = auth.uid()) with check (user_id = auth.uid() and status = 'pending');
create policy own on brands     for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy own on subscriptions for select using (user_id = auth.uid());
create policy own on notifications for select using (user_id = auth.uid());
create policy own_upd on notifications for update using (user_id = auth.uid());
create policy own on support_tickets for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Orders: customers read their own; creation goes through server actions (price computed server-side)
create policy own on orders      for select using (customer_id = auth.uid());
create policy own on order_items for select using (exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));
create policy own on payments    for select using (exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));
create policy own on invoices    for select using (customer_id = auth.uid() and status <> 'draft');
create policy own on qr_codes    for select using (created_by = auth.uid());

-- Projects & applications
create policy parties on projects for select using (client_id = auth.uid() or assignee_id = auth.uid());
create policy parties on project_milestones for select using (exists (select 1 from projects p where p.id = project_id and (p.client_id = auth.uid() or p.assignee_id = auth.uid())));
create policy own on applications for all using (applicant_id = auth.uid()) with check (applicant_id = auth.uid());
create policy brand_sees on applications for select using (exists (select 1 from campaigns c join brands b on b.id = c.brand_id where c.id = campaign_id and b.owner_id = auth.uid()));
create policy brand_campaigns on campaigns for all using (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()))
  with check (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()) and approval = 'pending');
create policy own on reviews for insert with check (author_id = auth.uid());

-- Messaging: members only
create policy members on conversation_members for select using (user_id = auth.uid());
create policy members on conversations for select using (exists (select 1 from conversation_members m where m.conversation_id = id and m.user_id = auth.uid()));
create policy members_read on messages for select using (exists (select 1 from conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));
create policy members_write on messages for insert with check (sender_id = auth.uid() and exists (select 1 from conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));

-- NOTE: orders.admin_notes must never reach customers. Expose orders to the
-- client through a view without admin_notes, or select explicit columns.
-- Digital downloads: serve via signed URLs generated server-side after verifying a paid order.
