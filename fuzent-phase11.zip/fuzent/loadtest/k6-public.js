// Load test for the public pages. Run ONLY against your own staging site, never someone else's.
//   k6 run -e BASE_URL=https://your-staging-url loadtest/k6-public.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [{ duration: '1m', target: 100 }, { duration: '3m', target: 1000 }, { duration: '1m', target: 0 }],
  thresholds: { http_req_failed: ['rate<0.01'], http_req_duration: ['p(95)<800'] },
};

export default function () {
  for (const path of ['/', '/store', '/creators', '/pricing', '/faq']) {
    const res = http.get(`${__ENV.BASE_URL}${path}`);
    check(res, { 'status is 200': (r) => r.status === 200 });
    sleep(1);
  }
}
