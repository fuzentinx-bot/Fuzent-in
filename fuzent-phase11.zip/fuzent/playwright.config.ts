import { defineConfig } from '@playwright/test';

// Run against a STAGING site, never production:  E2E_BASE_URL=https://staging.example npx playwright test
export default defineConfig({
  testDir: 'tests/e2e',
  timeout: 30_000,
  retries: 1,
  use: { baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:3000' },
});
