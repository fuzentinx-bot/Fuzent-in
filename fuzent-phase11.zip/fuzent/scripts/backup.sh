#!/bin/sh
# Daily database backup. Run from the project folder. Keeps the last 14 files.
set -e
cd "$(dirname "$0")/.."
. ./.env
mkdir -p backups
docker run --rm postgres:16-alpine pg_dump "$DATABASE_URL" --no-owner | gzip > "backups/fuzent-$(date +%F).sql.gz"
ls -1t backups/*.sql.gz | tail -n +15 | xargs -r rm --
echo "Backup done: backups/fuzent-$(date +%F).sql.gz"
