import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { getRoles, isAdmin } from '@/lib/auth/roles';
import { inr } from '@/lib/money';
import { Kpis, Panel, Bars, Donut, Feed, OrdersTable, orderParts } from '@/components/dash/widgets';

export const metadata = { title: 'Dashboard' };

export default async function Dashboard() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/dashboard');
  const [{ data: profile }, roles, { data: orders }, { count: invoices }, { data: feed }] = await Promise.all([
    supabase.from('profiles').select('full_name').eq('id', user.id).single(),
    getRoles(supabase, user.id),
    supabase.from('orders').select('id, order_no, total_paise, payment_status, status').order('created_at', { ascending: false }).limit(500), // RLS: own orders
    supabase.from('invoices').select('id', { count: 'exact', head: true }).neq('status', 'draft'),
    supabase.from('notifications').select('title, body, created_at').order('created_at', { ascending: false }).limit(5),
  ]);
  const all = orders ?? [], paid = all.filter((o) => o.payment_status === 'paid');
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Hey, {profile?.full_name ?? 'there'}</h1>
      <p className="text-forest/70">Roles: {roles.join(', ') || 'none'}</p>
      <div className="mt-4"><Kpis items={[
        { tone: 1, label: 'Orders', value: all.length }, { tone: 2, label: 'Total paid', value: inr(paid.reduce((a, o) => a + o.total_paise, 0)) },
        { tone: 3, label: 'Awaiting payment', value: all.filter((o) => ['created', 'pending'].includes(o.payment_status)).length }, { tone: 4, label: 'Invoices', value: invoices ?? 0 },
      ]} /></div>
      <div className="cg">
        <Panel title="Spending by paid order"><Bars label="Amount per paid order" data={paid.slice(0, 8).reverse().map((o) => ({ label: o.order_no, value: o.total_paise / 100 }))} /></Panel>
        <Panel title="Orders by status"><Donut label="Orders by status" parts={orderParts(all)} /></Panel>
      </div>
      <div className="cg">
        <Panel title="Recent orders"><OrdersTable rows={all.slice(0, 5)} /></Panel>
        <Feed items={feed ?? []} />
      </div>
      {isAdmin(roles) && <Link href="/admin" className="btn mt-6">Open control center</Link>}
    </>
  );
}
