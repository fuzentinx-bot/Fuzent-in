import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';

export const metadata = { title: 'My invoices' };

export default async function Invoices() {
  const supabase = await createClient(); // RLS: own, issued invoices only
  const { data } = await supabase.from('invoices').select('id, invoice_no, total_paise, issued_at').neq('status', 'draft').order('issued_at', { ascending: false });
  return (
    <main className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">My invoices</h1>
      {!data?.length ? <p className="mt-6 text-forest/70">No invoices yet. One is created when a payment is confirmed.</p> : (
        <div className="mt-6 grid gap-3">
          {data.map((i) => (
            <a key={i.id} href={`/api/invoices/${i.id}/pdf`} className="card flex flex-wrap items-center justify-between gap-2">
              <span className="font-bold">{i.invoice_no}</span><span>{inr(i.total_paise)}</span>
              <span className="text-sm">{i.issued_at ? new Date(i.issued_at).toLocaleDateString('en-IN') : ''} · PDF</span>
            </a>
          ))}
        </div>
      )}
    </main>
  );
}
