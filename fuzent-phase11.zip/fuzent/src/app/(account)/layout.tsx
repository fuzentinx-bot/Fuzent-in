import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { DashShell } from '@/components/dash/shell';

export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { count } = await supabase.from('notifications').select('id', { count: 'exact', head: true }).is('read_at', null);
  return (
    <DashShell label="My account" links={[['/freelancer', 'Freelancer hub'], ['/brand', 'Brand hub']]} nav={[
      { href: '/dashboard', label: 'Overview', icon: '▦', exact: true },
      { href: '/orders', label: 'Orders', icon: '▤' },
      { href: '/invoices', label: 'Invoices', icon: '₹' },
      { href: '/messages', label: 'Messages', icon: '✉' },
      { href: '/notifications', label: 'Alerts', icon: '🔔', badge: count ?? 0 },
      { href: '/support', label: 'Support', icon: '?' },
      { href: '/my-data', label: 'My data', icon: '🔒' },
    ]}>{children}</DashShell>
  );
}
