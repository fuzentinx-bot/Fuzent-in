import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { AutoRefresh } from '@/components/auto-refresh';
import { sendMessage } from '../actions';

export const metadata = { title: 'Conversation' };

export default async function Conversation({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: c } = await supabase.from('conversations').select('id, title').eq('id', id).maybeSingle(); // RLS: members only
  if (!c || !user) notFound();
  const { data: msgs } = await supabase.from('messages').select('id, sender_id, body, created_at').eq('conversation_id', id).order('created_at').limit(200);
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <AutoRefresh />
      <h1 className="text-4xl font-extrabold tracking-tight">{c.title}</h1>
      <div className="mt-6 grid gap-3" aria-live="polite">
        {(msgs ?? []).map((m) => (
          <div key={m.id} className={`max-w-[85%] rounded-2xl border-2 border-forest p-3 ${m.sender_id === user.id ? 'ml-auto bg-lime' : 'bg-white'}`}>
            <p className="whitespace-pre-wrap">{m.body}</p>
            <p className="mt-1 text-xs opacity-70">{m.sender_id === user.id ? 'You' : 'Them'} · {new Date(m.created_at).toLocaleString('en-IN')}</p>
          </div>
        ))}
      </div>
      <form action={sendMessage} className="mt-6 flex gap-2">
        <input type="hidden" name="conversationId" value={id} />
        <label className="sr-only" htmlFor="body">Message</label>
        <input id="body" name="body" className="field" required maxLength={2000} placeholder="Write a message" autoComplete="off" />
        <button className="btn">Send</button>
      </form>
    </main>
  );
}
