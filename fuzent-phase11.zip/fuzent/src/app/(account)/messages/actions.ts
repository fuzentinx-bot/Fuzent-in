'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createClient } from '@/lib/supabase/server';

export async function sendMessage(fd: FormData) {
  const p = z.object({ conversationId: z.string().uuid(), body: z.string().trim().min(1).max(2000) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;
  await supabase.from('messages').insert({ conversation_id: p.data.conversationId, sender_id: user.id, body: p.data.body }); // RLS: members only
  revalidatePath(`/messages/${p.data.conversationId}`);
}
