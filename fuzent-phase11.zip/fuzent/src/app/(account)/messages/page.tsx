import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';

export const metadata = { title: 'Messages' };

export default async function Messages() {
  const supabase = await createClient(); // RLS: only conversations you belong to
  const { data } = await supabase.from('conversations').select('id, title, created_at').order('created_at', { ascending: false });
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Messages</h1>
      {!data?.length ? <p className="mt-6 text-forest/70">No conversations yet. One opens when a brand or client accepts an application.</p> : (
        <div className="mt-6 grid gap-3">{data.map((c) => <Link key={c.id} href={`/messages/${c.id}`} className="card font-bold">{c.title ?? 'Conversation'}</Link>)}</div>
      )}
    </main>
  );
}
