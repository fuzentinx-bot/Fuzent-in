'use server';

import { redirect } from 'next/navigation';
import { after } from 'next/server';
import { needUser } from '@/lib/forms';
import { admin } from '@/lib/supabase/admin';
import { processEvents } from '@/lib/automation';

// Deletion is a request that staff complete, because orders and invoices may have to be kept for legal and tax reasons.
export async function requestDeletion() {
  const { supabase, user } = await needUser('/my-data');
  const { data: open } = await supabase.from('support_tickets').select('id').eq('subject', 'Account deletion request').neq('status', 'closed').limit(1);
  if (!open?.length) {
    const { data } = await supabase.from('support_tickets').insert({ user_id: user.id, subject: 'Account deletion request', body: 'Please delete my account and personal data, keeping only what the law requires.' }).select('id').single();
    if (data) await admin().from('automation_events').insert({ event_type: 'ticket.created', payload: { ticket_id: data.id } });
    after(() => processEvents());
  }
  redirect('/my-data?done=1');
}
