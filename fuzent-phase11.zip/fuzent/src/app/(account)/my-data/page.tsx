import { Ok } from '@/components/ui';
import { Panel } from '@/components/dash/widgets';
import { requestDeletion } from './actions';

export const metadata = { title: 'My data' };

export default async function MyData({ searchParams }: { searchParams: Promise<{ done?: string }> }) {
  const sp = await searchParams;
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">My data</h1>
      <div className="mt-4"><Ok t={sp.done ? 'Request received. Our team will confirm by email.' : undefined} /></div>
      <Panel title="Download my data">
        <p className="mb-3">Get a copy of the information FUZENT holds about you: profile, orders, invoices, tickets and messages you sent.</p>
        <a className="btn" href="/api/account/export">Download as JSON</a>
      </Panel>
      <Panel title="Delete my account">
        <p className="mb-3">We will delete your personal data. Orders and invoices may have to be kept for legal and tax reasons: [YOUR RETENTION POLICY].</p>
        <form action={requestDeletion}><button className="btn btn-ghost">Request deletion</button></form>
      </Panel>
    </>
  );
}
