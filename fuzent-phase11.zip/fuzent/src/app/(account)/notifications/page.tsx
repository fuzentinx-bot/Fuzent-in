import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { markAllRead } from './actions';

export const metadata = { title: 'Alerts' };

export default async function Notifications() {
  const supabase = await createClient();
  const { data } = await supabase.from('notifications').select('id, title, body, link, read_at, created_at').order('created_at', { ascending: false }).limit(50);
  const unread = (data ?? []).some((n) => !n.read_at);
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-5xl font-extrabold tracking-tight">Alerts</h1>
        {unread && <form action={markAllRead}><button className="btn btn-ghost min-h-[44px] px-4">Mark all read</button></form>}
      </div>
      {!data?.length ? <p className="mt-6 text-forest/70">Nothing yet.</p> : (
        <div className="mt-6 grid gap-3">
          {data.map((n) => (
            <Link key={n.id} href={n.link ?? '#'} className={`card block ${n.read_at ? '' : 'bg-lime'}`}>
              <p className="font-bold">{n.title}</p><p>{n.body}</p>
              <p className="mt-1 text-xs opacity-70">{new Date(n.created_at).toLocaleString('en-IN')}</p>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
