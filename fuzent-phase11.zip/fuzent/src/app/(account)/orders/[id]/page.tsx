import Link from 'next/link';
import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { AutoRefresh } from '@/components/auto-refresh';

export const metadata = { title: 'Order' };

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: o } = await supabase.from('orders')
    .select('id, order_no, status, payment_status, total_paise, order_items(id, product_id, title_snapshot), payments(failure_reason), invoices(id, invoice_no)')
    .eq('id', id).single(); // RLS: not yours = null
  if (!o) notFound();
  const paid = o.payment_status === 'paid';
  const checking = o.payment_status === 'pending';
  const unpaid = o.payment_status === 'created';

  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      {checking && <AutoRefresh />}
      <h1 className="text-4xl font-extrabold tracking-tight">{o.order_no}</h1>
      <p role="status" className="mt-3 rounded-xl bg-lime p-3 font-bold">
        {paid ? 'Payment confirmed. Thank you!' : checking ? 'We are checking your payment. This updates by itself.' : unpaid ? 'Waiting for your payment.' : `Order ${o.status}.`}
      </p>
      {paid && o.invoices?.[0] && <a className="btn btn-ghost mt-4" href={`/api/invoices/${o.invoices[0].id}/pdf`}>Invoice {o.invoices[0].invoice_no}</a>}
      {unpaid && <Link href={`/checkout/${o.id}`} className="btn mt-4">Go to checkout</Link>}
      <div className="card mt-6 grid gap-3">
        {o.order_items.map((i: any) => (
          <div key={i.id} className="flex flex-wrap items-center justify-between gap-2">
            <span>{i.title_snapshot}</span>
            {paid && i.product_id && <a className="btn min-h-[44px] px-4" href={`/api/download/${i.product_id}`}>Download</a>}
          </div>
        ))}
        <p className="border-t-2 border-forest pt-3 text-xl font-extrabold">Total {inr(o.total_paise)}</p>
      </div>
    </main>
  );
}
