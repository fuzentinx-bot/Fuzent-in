import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';

export const metadata = { title: 'My orders' };

export default async function Orders() {
  const supabase = await createClient(); // RLS returns only this user's orders
  const { data } = await supabase.from('orders').select('id, order_no, status, payment_status, total_paise, created_at').order('created_at', { ascending: false });
  return (
    <main className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">My orders</h1>
      {!data?.length ? (
        <p className="mt-6 text-forest/70">No orders yet. <Link className="underline" href="/store">Browse the store</Link></p>
      ) : (
        <div className="mt-6 grid gap-3">
          {data.map((o) => (
            <Link key={o.id} href={`/orders/${o.id}`} className="card flex flex-wrap items-center justify-between gap-2">
              <span className="font-bold">{o.order_no}</span>
              <span>{inr(o.total_paise)}</span>
              <span className="rounded-full bg-lime px-3 py-1 text-sm font-bold">{o.payment_status === 'paid' ? o.status : `payment ${o.payment_status}`}</span>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
