import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { StatusTag } from '@/components/ui';
import { replyTicket } from '../actions';

export const metadata = { title: 'Ticket' };

export default async function Ticket({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: t } = await supabase.from('support_tickets').select('id, subject, body, status').eq('id', id).maybeSingle(); // RLS: own only
  if (!t) notFound();
  const { data: msgs } = await supabase.from('ticket_messages').select('id, is_staff, body, created_at').eq('ticket_id', id).order('created_at');
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-4xl font-extrabold tracking-tight">{t.subject}</h1><p className="mt-2"><StatusTag s={t.status} /></p>
      <div className="card mt-6"><p className="whitespace-pre-wrap">{t.body}</p></div>
      <div className="mt-4 grid gap-3">
        {(msgs ?? []).map((m) => (
          <div key={m.id} className={`max-w-[85%] rounded-2xl border-2 border-forest p-3 ${m.is_staff ? 'bg-lime' : 'ml-auto bg-white'}`}>
            <p className="whitespace-pre-wrap">{m.body}</p><p className="mt-1 text-xs opacity-70">{m.is_staff ? 'FUZENT support' : 'You'} · {new Date(m.created_at).toLocaleString('en-IN')}</p>
          </div>
        ))}
      </div>
      {t.status !== 'closed' && (
        <form action={replyTicket} className="mt-6 flex gap-2">
          <input type="hidden" name="ticketId" value={id} /><label className="sr-only" htmlFor="b">Reply</label>
          <input id="b" name="body" className="field" required maxLength={2000} placeholder="Write a reply" autoComplete="off" /><button className="btn">Send</button>
        </form>
      )}
    </main>
  );
}
