'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { after } from 'next/server';
import { bail, needUser } from '@/lib/forms';
import { admin } from '@/lib/supabase/admin';
import { tooMany } from '@/lib/rate-limit';
import { processEvents } from '@/lib/automation';

export async function createTicket(fd: FormData) {
  const { supabase, user } = await needUser('/support');
  const p = z.object({
    subject: z.string().trim().min(3).max(120), body: z.string().trim().min(10).max(2000),
    orderId: z.string().uuid().optional().or(z.literal('')),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/support', p.error.issues[0].message);
  if (p.data.orderId) {
    const { data: own } = await supabase.from('orders').select('id').eq('id', p.data.orderId).maybeSingle(); // RLS: own orders only
    if (!own) return bail('/support', 'That order was not found.');
  }
  if (await tooMany('support_tickets', 'user_id', user.id)) return bail('/support', 'Too many tickets this hour. Please wait a little.');
  const { data, error } = await supabase.from('support_tickets').insert({ user_id: user.id, subject: p.data.subject, body: p.data.body, order_id: p.data.orderId || null }).select('id').single();
  if (error || !data) return bail('/support', 'Could not send. Try again.');
  await admin().from('automation_events').insert({ event_type: 'ticket.created', payload: { ticket_id: data.id } });
  after(() => processEvents());
  redirect(`/support/${data.id}`);
}

export async function replyTicket(fd: FormData) {
  const p = z.object({ ticketId: z.string().uuid(), body: z.string().trim().min(1).max(2000) }).safeParse(Object.fromEntries(fd));
  const { supabase, user } = await needUser('/support');
  if (!p.success) return;
  const { data: t } = await supabase.from('support_tickets').select('id').eq('id', p.data.ticketId).maybeSingle(); // RLS: own only
  if (!t) return;
  await supabase.from('ticket_messages').insert({ ticket_id: t.id, author_id: user.id, body: p.data.body });
  const db = admin();
  await db.from('support_tickets').update({ status: 'open' }).eq('id', t.id);
  await db.from('automation_events').insert({ event_type: 'ticket.customer_replied', payload: { ticket_id: t.id } });
  after(() => processEvents());
  revalidatePath(`/support/${t.id}`);
}
