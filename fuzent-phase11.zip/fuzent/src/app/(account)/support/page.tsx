import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Err, F, StatusTag } from '@/components/ui';
import { createTicket } from './actions';

export const metadata = { title: 'Support' };

export default async function Support({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const [{ data: tickets }, { data: orders }] = await Promise.all([
    supabase.from('support_tickets').select('id, subject, status, created_at').order('created_at', { ascending: false }),
    supabase.from('orders').select('id, order_no').order('created_at', { ascending: false }).limit(20),
  ]);
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Support</h1>
      <div className="mt-4"><Err e={sp.error} /></div>
      <form action={createTicket} className="card grid gap-4">
        <h2 className="text-xl font-bold">New ticket</h2>
        <F label="Subject" name="subject" /><F label="What happened?" name="body" area />
        <label className="grid gap-1 text-sm font-bold">About an order (optional)
          <select name="orderId" className="field"><option value="">None</option>{(orders ?? []).map((o) => <option key={o.id} value={o.id}>{o.order_no}</option>)}</select></label>
        <button className="btn">Send</button>
      </form>
      <h2 className="mb-3 mt-10 text-3xl font-extrabold">Your tickets</h2>
      {!tickets?.length ? <p className="text-forest/70">No tickets yet.</p> : (
        <div className="grid gap-3">{tickets.map((t) => <Link key={t.id} href={`/support/${t.id}`} className="card flex flex-wrap items-center justify-between gap-2"><b>{t.subject}</b><StatusTag s={t.status} /></Link>)}</div>
      )}
    </main>
  );
}
