export const metadata = { title: 'About FUZENT' };

export default function About() {
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">About FUZENT</h1>
      <p className="mt-4 text-lg">FUZENT brings digital products, growth services, automation, creators and freelancers into one place for businesses in India. Build beyond limits.</p>
    </main>
  );
}
