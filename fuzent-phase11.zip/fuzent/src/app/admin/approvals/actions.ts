'use server';

import { z } from 'zod';
import { revalidatePath, revalidateTag } from 'next/cache';
import { requireAdmin } from '@/lib/auth/require-admin';
import { admin } from '@/lib/supabase/admin';

const KINDS = {
  creator: { table: 'creators', key: 'user_id', col: 'status', role: 'creator', owner: 'user_id' },
  freelancer: { table: 'freelancers', key: 'user_id', col: 'status', role: 'freelancer', owner: 'user_id' },
  brand: { table: 'brands', key: 'id', col: 'status', role: 'brand', owner: 'owner_id' },
  campaign: { table: 'campaigns', key: 'id', col: 'approval', role: null, owner: null },
} as const;

export async function decide(fd: FormData) {
  const user = await requireAdmin();
  const p = z.object({ kind: z.enum(['creator', 'freelancer', 'brand', 'campaign']), id: z.string().uuid(), decision: z.enum(['approved', 'rejected']) }).parse(Object.fromEntries(fd));
  const k = KINDS[p.kind];
  const db = admin();
  const { data: row } = await db.from(k.table).update({ [k.col]: p.decision }).eq(k.key, p.id).select('*').single();
  if (row && p.decision === 'approved' && k.role && k.owner) {
    const { data: role } = await db.from('roles').select('id').eq('key', k.role).single();
    if (role) await db.from('user_roles').upsert({ user_id: (row as any)[k.owner], role_id: role.id });
  }
  await db.from('audit_logs').insert({ actor_id: user.id, action: `${p.kind}.${p.decision}`, entity: k.table, entity_id: p.id });
  revalidatePath('/admin/approvals');
  revalidateTag('catalog'); // public lists refresh right after an approval
}
