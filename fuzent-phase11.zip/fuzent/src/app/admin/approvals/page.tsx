import { createClient } from '@/lib/supabase/server';
import { decide } from './actions';

export const metadata = { title: 'Approvals' };

function Row({ kind, id, title, sub }: { kind: string; id: string; title: string; sub?: string }) {
  return (
    <div className="card flex flex-wrap items-center justify-between gap-3">
      <div><p className="text-lg font-extrabold">{title}</p><p className="max-w-xl whitespace-pre-line text-sm">{sub}</p></div>
      <div className="flex gap-2">
        {(['approved', 'rejected'] as const).map((d) => (
          <form key={d} action={decide}><input type="hidden" name="kind" value={kind} /><input type="hidden" name="id" value={id} /><input type="hidden" name="decision" value={d} />
            <button className={`btn min-h-[44px] px-4 ${d === 'rejected' ? 'btn-ghost' : ''}`}>{d === 'approved' ? 'Approve' : 'Reject'}</button></form>
        ))}
      </div>
    </div>
  );
}

export default async function Approvals() {
  const supabase = await createClient(); // admin role passes RLS
  const [cr, fr, br, ca] = await Promise.all([
    supabase.from('creators').select('user_id, handle, bio, niche, social_links, portfolio').eq('status', 'pending'),
    supabase.from('freelancers').select('user_id, display_name, headline, skills, experience, portfolio').eq('status', 'pending'),
    supabase.from('brands').select('id, name, website, industry').eq('status', 'pending'),
    supabase.from('campaigns').select('id, title, brief, budget_paise').eq('approval', 'pending'),
  ]);
  const sections: [string, any[] | null, (r: any) => [string, string, string]][] = [
    ['Creators', cr.data, (r) => [r.user_id, `@${r.handle} · ${r.niche?.join(', ')}`, `Instagram: ${r.social_links?.instagram}\n${r.bio ?? ''}\n${(r.portfolio ?? []).join('\n')}`]],
    ['Freelancers', fr.data, (r) => [r.user_id, `${r.display_name} · ${r.headline}`, `${r.skills?.join(', ')}\n${r.experience ?? ''}\n${(r.portfolio ?? []).join('\n')}`]],
    ['Brands', br.data, (r) => [r.id, r.name, `${r.website}\n${r.industry ?? ''}`]],
    ['Campaigns', ca.data, (r) => [r.id, r.title, `${r.brief}\nBudget ₹${(r.budget_paise ?? 0) / 100}`]],
  ];
  const kinds = ['creator', 'freelancer', 'brand', 'campaign'];
  return (
    <>
      <h1 className="text-5xl font-extrabold tracking-tight">Approvals</h1>
      <p className="mt-3 max-w-2xl">Open the links and check the profile is real before you approve. Approving a creator, freelancer or brand also gives them that role.</p>
      {sections.map(([label, rows, map], i) => (
        <section key={label} className="mt-10"><h2 className="mb-3 text-3xl font-extrabold">{label}</h2>
          {!rows?.length ? <p className="text-forest/70">Nothing waiting.</p> : <div className="grid gap-3">{rows.map((r) => { const [id, t, s] = map(r); return <Row key={id} kind={kinds[i]} id={id} title={t} sub={s} />; })}</div>}
        </section>
      ))}
    </>
  );
}
