'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth/require-admin';
import { admin } from '@/lib/supabase/admin';

const num = z.preprocess((v) => (v === '' || v == null ? undefined : v), z.coerce.number().min(0).optional());

export async function createCoupon(formData: FormData) {
  const user = await requireAdmin();
  const p = z.object({
    code: z.string().trim().toUpperCase().regex(/^[A-Z0-9]{3,20}$/, 'Code: 3-20 letters or digits.'),
    percent: num, rupees: num, max: num, min: num, until: z.string().optional(),
  }).safeParse(Object.fromEntries(formData));
  if (!p.success) redirect(`/admin/coupons?error=${encodeURIComponent(p.error.issues[0].message)}`);
  const d = p.data;
  if ((d.percent ? 1 : 0) + (d.rupees ? 1 : 0) !== 1 || (d.percent ?? 0) > 100) redirect('/admin/coupons?error=Set either a percent (1-100) or a rupee amount.');
  const { error } = await admin().from('coupons').insert({
    code: d.code, percent_off: d.percent ? Math.round(d.percent) : null, amount_off_paise: d.rupees ? Math.round(d.rupees * 100) : null,
    max_redemptions: d.max ? Math.round(d.max) : null, min_order_paise: Math.round((d.min ?? 0) * 100),
    valid_until: d.until ? new Date(d.until + 'T23:59:59+05:30').toISOString() : null,
  });
  if (error) redirect('/admin/coupons?error=' + encodeURIComponent(error.code === '23505' ? 'That code already exists.' : 'Could not save.'));
  await admin().from('audit_logs').insert({ actor_id: user.id, action: 'coupon.created', entity: 'coupon', entity_id: d.code });
  revalidatePath('/admin/coupons');
}

export async function toggleCoupon(formData: FormData) {
  await requireAdmin();
  const id = z.string().uuid().parse(formData.get('id'));
  const on = formData.get('on') === 'true';
  await admin().from('coupons').update({ is_active: on }).eq('id', id);
  revalidatePath('/admin/coupons');
}
