import { createClient } from '@/lib/supabase/server';
import { createCoupon, toggleCoupon } from './actions';

export const metadata = { title: 'Coupons' };

export default async function Coupons({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  const supabase = await createClient();
  const { data } = await supabase.from('coupons').select('*').order('code');
  return (
    <>
      <h1 className="text-5xl font-extrabold tracking-tight">Coupons</h1>
      {error && <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      <form action={createCoupon} className="card mt-6 grid max-w-xl gap-3 sm:grid-cols-2">
        <label className="grid gap-1 text-sm font-bold">Code<input className="field" name="code" required /></label>
        <label className="grid gap-1 text-sm font-bold">Percent off<input className="field" name="percent" type="number" min={1} max={100} /></label>
        <label className="grid gap-1 text-sm font-bold">Or rupees off<input className="field" name="rupees" type="number" min={1} /></label>
        <label className="grid gap-1 text-sm font-bold">Max uses (optional)<input className="field" name="max" type="number" min={1} /></label>
        <label className="grid gap-1 text-sm font-bold">Minimum order in rupees<input className="field" name="min" type="number" min={0} /></label>
        <label className="grid gap-1 text-sm font-bold">Valid until (optional)<input className="field" name="until" type="date" /></label>
        <button className="btn sm:col-span-2">Create coupon</button>
      </form>
      <div className="mt-8 grid gap-3">
        {(data ?? []).map((c: any) => (
          <div key={c.id} className="card flex flex-wrap items-center justify-between gap-3">
            <div><p className="text-xl font-extrabold">{c.code}</p>
              <p>{c.percent_off ? `${c.percent_off}% off` : `₹${c.amount_off_paise / 100} off`} · used {c.redeemed}{c.max_redemptions ? ` of ${c.max_redemptions}` : ''}{c.valid_until ? ` · until ${new Date(c.valid_until).toLocaleDateString('en-IN')}` : ''}</p></div>
            <form action={toggleCoupon}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="on" value={String(!c.is_active)} />
              <button className="btn btn-ghost min-h-[44px] px-4">{c.is_active ? 'Disable' : 'Enable'}</button></form>
          </div>
        ))}
      </div>
    </>
  );
}
