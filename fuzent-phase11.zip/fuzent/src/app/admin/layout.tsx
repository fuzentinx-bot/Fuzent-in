import { notFound, redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { getRoles, isAdmin } from '@/lib/auth/roles';
import { DashShell } from '@/components/dash/shell';

// Server-side role gate. RLS in the database is the second lock.
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/admin');
  if (!isAdmin(await getRoles(supabase, user.id))) notFound();

  const n = async (table: string, col: string, val: string) => (await supabase.from(table).select('id', { count: 'exact', head: true }).eq(col, val)).count ?? 0;
  const [pay, tix, cr, fr, br, ca] = await Promise.all([
    n('payments', 'status', 'pending'), n('support_tickets', 'status', 'open'),
    n('creators', 'status', 'pending'), n('freelancers', 'status', 'pending'), n('brands', 'status', 'pending'), n('campaigns', 'approval', 'pending'),
  ]);
  return (
    <DashShell label="Admin" links={[['/dashboard', 'My account']]} nav={[
      { href: '/admin', label: 'Overview', icon: '▦', exact: true },
      { href: '/admin/payments', label: 'Payments', icon: '₹', badge: pay },
      { href: '/admin/orders', label: 'Orders', icon: '▤' },
      { href: '/admin/support', label: 'Support', icon: '✉', badge: tix },
      { href: '/admin/approvals', label: 'Approvals', icon: '☑', badge: cr + fr + br + ca },
      { href: '/admin/coupons', label: 'Coupons', icon: '%' },
      { href: '/admin/settings', label: 'Settings', icon: '⚙' },
    ]}>{children}</DashShell>
  );
}
