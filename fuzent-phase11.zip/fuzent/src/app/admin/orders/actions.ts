'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth/require-admin';
import { admin } from '@/lib/supabase/admin';

const fail = (m: string): never => redirect('/admin/orders?error=' + encodeURIComponent(m));

// Records a refund AFTER you have sent the money back from your UPI or bank app.
export async function recordRefund(formData: FormData) {
  const user = await requireAdmin();
  const p = z.object({
    orderId: z.string().uuid(),
    rupees: z.coerce.number().positive(),
    reason: z.string().trim().min(3).max(200),
    utr: z.string().trim().regex(/^(\d{12})?$/, 'Refund UTR is 12 digits, or leave it empty.'),
  }).safeParse(Object.fromEntries(formData));
  if (!p.success) return fail(p.error.issues[0].message);
  const amount = Math.round(p.data.rupees * 100);

  const db = admin();
  const { data: order } = await db.from('orders').select('id, total_paise').eq('id', p.data.orderId).single();
  const { data: pay } = await db.from('payments').select('id').eq('order_id', p.data.orderId).in('status', ['paid', 'partially_refunded']).maybeSingle();
  if (!order || !pay) return fail('Only paid orders can be refunded.');
  const { data: prior } = await db.from('refunds').select('amount_paise').eq('order_id', order.id);
  const remaining = order.total_paise - (prior ?? []).reduce((a, r) => a + r.amount_paise, 0);
  if (amount > remaining) return fail(`You can refund at most ₹${remaining / 100} on this order.`);

  await db.from('refunds').insert({ payment_id: pay.id, order_id: order.id, amount_paise: amount, reason: p.data.reason, refund_utr: p.data.utr || null, created_by: user.id });
  const full = amount === remaining;
  await db.from('payments').update({ status: full ? 'refunded' : 'partially_refunded' }).eq('id', pay.id);
  if (full) await db.from('orders').update({ payment_status: 'refunded', status: 'refunded' }).eq('id', order.id); // blocks downloads
  await db.from('audit_logs').insert({ actor_id: user.id, action: 'refund.recorded', entity: 'order', entity_id: order.id, meta: { amount_paise: amount, full } });
  await db.from('automation_events').insert({ event_type: 'order.refunded', payload: { order_id: order.id, amount_paise: amount } });
  revalidatePath('/admin/orders');
}
