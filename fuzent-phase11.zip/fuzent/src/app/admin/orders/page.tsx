import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { recordRefund } from './actions';

export const metadata = { title: 'Orders and refunds' };

export default async function OrdersAdmin({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  const supabase = await createClient();
  const { data } = await supabase.from('orders')
    .select('id, order_no, total_paise, payment_status, created_at, profiles(email), refunds(amount_paise)')
    .in('payment_status', ['paid', 'refunded']).order('created_at', { ascending: false }).limit(50);
  return (
    <>
      <h1 className="text-5xl font-extrabold tracking-tight">Orders and refunds</h1>
      <p className="mt-3 max-w-2xl text-forest/80">Send the money back from your UPI or bank app first, then record it here. A full refund also blocks the customer&rsquo;s downloads.</p>
      {error && <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      <div className="mt-8 grid gap-4">
        {(data ?? []).map((o: any) => {
          const refunded = (o.refunds ?? []).reduce((a: number, r: any) => a + r.amount_paise, 0);
          const left = o.total_paise - refunded;
          return (
            <div key={o.id} className="card grid gap-3 md:grid-cols-[1fr_auto] md:items-center">
              <div>
                <p className="text-xl font-extrabold">{o.order_no} · {inr(o.total_paise)}</p>
                <p>{o.profiles?.email} · {o.payment_status}{refunded ? ` · refunded ${inr(refunded)}` : ''}</p>
              </div>
              {left > 0 && (
                <form action={recordRefund} className="grid gap-2 sm:grid-cols-2">
                  <input type="hidden" name="orderId" value={o.id} />
                  <label className="sr-only" htmlFor={`a${o.id}`}>Refund amount in rupees</label>
                  <input id={`a${o.id}`} className="field" name="rupees" type="number" step="0.01" min="0.01" max={left / 100} defaultValue={left / 100} required />
                  <label className="sr-only" htmlFor={`u${o.id}`}>Refund UTR</label>
                  <input id={`u${o.id}`} className="field" name="utr" placeholder="Refund UTR (optional)" />
                  <input className="field sm:col-span-2" name="reason" placeholder="Reason" aria-label="Reason" required />
                  <button className="btn btn-ghost sm:col-span-2">Record refund</button>
                </form>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}
