import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Kpis, Panel, Bars, Donut, Feed, OrdersTable, orderParts } from '@/components/dash/widgets';

export const metadata = { title: 'Admin' };

export default async function AdminHome() {
  const supabase = await createClient(); // admin role passes RLS
  const { data: { user } } = await supabase.auth.getUser();
  const [{ data: orders }, { count: toVerify }, { count: openTickets }, { data: feed }] = await Promise.all([
    supabase.from('orders').select('id, order_no, total_paise, payment_status, status').order('created_at', { ascending: false }).limit(1000),
    supabase.from('payments').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('support_tickets').select('id', { count: 'exact', head: true }).eq('status', 'open'),
    supabase.from('notifications').select('title, body, created_at').eq('user_id', user!.id).order('created_at', { ascending: false }).limit(5),
  ]);
  const all = orders ?? [], paid = all.filter((o) => o.payment_status === 'paid');
  const revenue = paid.reduce((a, o) => a + o.total_paise, 0);
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Overview</h1>
      <div className="mt-4"><Kpis items={[
        { tone: 1, label: 'Revenue (paid)', value: inr(revenue) }, { tone: 2, label: 'Orders', value: all.length },
        { tone: 3, label: 'Payments to verify', value: toVerify ?? 0 }, { tone: 4, label: 'Open tickets', value: openTickets ?? 0 },
      ]} /></div>
      <div className="cg">
        <Panel title="Revenue by paid order"><Bars label="Amount per paid order" data={paid.slice(0, 8).reverse().map((o) => ({ label: o.order_no, value: o.total_paise / 100 }))} /></Panel>
        <Panel title="Orders by status"><Donut label="Orders by status" parts={orderParts(all)} /></Panel>
      </div>
      <div className="cg">
        <Panel title="Recent orders"><OrdersTable rows={all.slice(0, 5)} /></Panel>
        <Feed items={feed ?? []} />
      </div>
    </>
  );
}
