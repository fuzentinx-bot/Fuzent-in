'use server';

import { after } from 'next/server';
import { processEvents } from '@/lib/automation';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth/require-admin';
import { markPaid, rejectPayment } from '@/lib/payments';

export async function confirmPayment(formData: FormData) {
  const user = await requireAdmin();
  const id = z.string().uuid().parse(formData.get('paymentId'));
  await markPaid(id, user.id);
  revalidatePath('/admin/payments');
  after(() => processEvents());
}

export async function rejectPaymentAction(formData: FormData) {
  const user = await requireAdmin();
  const id = z.string().uuid().parse(formData.get('paymentId'));
  const reason = z.string().trim().min(3).max(200).parse(formData.get('reason'));
  await rejectPayment(id, user.id, reason);
  revalidatePath('/admin/payments');
  after(() => processEvents());
}
