import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { confirmPayment, rejectPaymentAction } from './actions';

export const metadata = { title: 'Payments to verify' };

export default async function PaymentsAdmin() {
  const supabase = await createClient(); // admin role passes RLS
  const { data } = await supabase.from('payments')
    .select('id, amount_paise, utr, submitted_at, orders(order_no, profiles(email))')
    .eq('status', 'pending').order('submitted_at');
  return (
    <>
      <h1 className="text-5xl font-extrabold tracking-tight">Payments to verify</h1>
      <p className="mt-3 max-w-2xl text-forest/80">Open your bank app or statement. Confirm only if a credit with the same UTR and the same amount is there.</p>
      {!data?.length ? <p className="mt-8">Nothing waiting.</p> : (
        <div className="mt-8 grid gap-4">
          {data.map((p: any) => (
            <div key={p.id} className="card grid gap-3 md:grid-cols-[1fr_auto] md:items-center">
              <div>
                <p className="text-xl font-extrabold">{p.orders?.order_no} · {inr(p.amount_paise)}</p>
                <p>UTR <b>{p.utr}</b> · {p.orders?.profiles?.email}</p>
                <p className="text-sm text-forest/70">Submitted {new Date(p.submitted_at).toLocaleString('en-IN')}</p>
              </div>
              <div className="grid gap-2">
                <form action={confirmPayment}><input type="hidden" name="paymentId" value={p.id} /><button className="btn w-full">Confirm: money received</button></form>
                <form action={rejectPaymentAction} className="flex gap-2">
                  <input type="hidden" name="paymentId" value={p.id} />
                  <label className="sr-only" htmlFor={`r${p.id}`}>Reason</label>
                  <input id={`r${p.id}`} name="reason" required minLength={3} placeholder="Reason (customer sees it)" className="field" />
                  <button className="btn btn-ghost px-4">Reject</button>
                </form>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
