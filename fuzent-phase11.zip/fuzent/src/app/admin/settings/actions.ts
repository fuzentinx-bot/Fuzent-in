'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth/require-admin';
import { admin } from '@/lib/supabase/admin';
import { VPA_RE } from '@/lib/upi';

export type SettingsState = { error?: string; message?: string };

export async function saveUpi(_: SettingsState, formData: FormData): Promise<SettingsState> {
  const user = await requireAdmin();
  const parsed = z.object({
    vpa: z.string().trim().regex(VPA_RE, 'Enter a valid UPI ID like name@bank.'),
    name: z.string().trim().min(2).max(60),
  }).safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const db = admin();
  await db.from('website_settings').upsert({ key: 'payment.upi', value: parsed.data, updated_at: new Date().toISOString() });
  await db.from('audit_logs').insert({ actor_id: user.id, action: 'settings.upi_changed', entity: 'website_settings', entity_id: 'payment.upi' });
  revalidatePath('/admin/settings');
  return { message: 'Saved. New checkouts use this UPI ID.' };
}
