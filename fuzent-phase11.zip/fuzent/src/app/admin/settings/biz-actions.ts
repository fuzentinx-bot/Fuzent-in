'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth/require-admin';
import { admin } from '@/lib/supabase/admin';

export type BizState = { error?: string; message?: string };

export async function saveBusiness(_: BizState, formData: FormData): Promise<BizState> {
  const user = await requireAdmin();
  const p = z.object({
    name: z.string().trim().min(2).max(80),
    address: z.string().trim().max(200),
    state: z.string().trim().max(40),
    gstin: z.string().trim().toUpperCase().regex(/^([0-9]{2}[A-Z0-9]{13})?$/, 'GSTIN has 15 characters, or leave it empty.'),
    sac: z.string().trim().max(10),
    gst_rate: z.coerce.number().min(0).max(28),
  }).safeParse(Object.fromEntries(formData));
  if (!p.success) return { error: p.error.issues[0].message };
  if (p.data.gst_rate > 0 && !p.data.gstin) return { error: 'Add your GSTIN before charging GST.' };
  const db = admin();
  await db.from('website_settings').upsert({ key: 'business.profile', value: p.data, updated_at: new Date().toISOString() });
  await db.from('audit_logs').insert({ actor_id: user.id, action: 'settings.business_changed', entity: 'website_settings', entity_id: 'business.profile' });
  revalidatePath('/admin/settings');
  return { message: 'Saved. New invoices use these details.' };
}
