'use client';

import { useActionState } from 'react';
import { saveBusiness, type BizState } from './biz-actions';

export function BizForm({ v }: { v: Record<string, any> }) {
  const [state, action, pending] = useActionState<BizState, FormData>(saveBusiness, {});
  const f = (label: string, name: string, extra: Record<string, any> = {}) => (
    <label className="grid gap-1 text-sm font-bold">{label}<input className="field" name={name} defaultValue={v[name] ?? ''} {...extra} /></label>
  );
  return (
    <form action={action} className="card mt-8 grid max-w-lg gap-4">
      <h2 className="text-xl font-bold">Invoice details</h2>
      {f('Business name', 'name', { required: true })}{f('Address', 'address')}{f('State', 'state')}
      {f('GSTIN (leave empty if not registered)', 'gstin')}{f('SAC/HSN code', 'sac')}
      {f('GST rate in % (0 if none). Prices are treated as GST-inclusive.', 'gst_rate', { type: 'number', min: 0, max: 28, step: '0.01', required: true })}
      <p className="text-sm text-forest/70">This is configuration only. Have an accountant confirm the rate, codes and place-of-supply rules before issuing real invoices.</p>
      {state.error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{state.error}</p>}
      {state.message && <p role="status" className="rounded-xl bg-lime p-3 text-sm font-bold">{state.message}</p>}
      <button className="btn" disabled={pending}>{pending ? 'Saving' : 'Save'}</button>
    </form>
  );
}
