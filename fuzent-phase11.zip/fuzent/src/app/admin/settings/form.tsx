'use client';

import { useActionState } from 'react';
import { saveUpi, type SettingsState } from './actions';

export function UpiForm({ vpa, name }: { vpa: string; name: string }) {
  const [state, action, pending] = useActionState<SettingsState, FormData>(saveUpi, {});
  return (
    <form action={action} className="card mt-8 grid max-w-lg gap-4">
      <label className="grid gap-1 text-sm font-bold">Business UPI ID<input className="field" name="vpa" defaultValue={vpa} placeholder="yourbusiness@bank" required /></label>
      <label className="grid gap-1 text-sm font-bold">Payee name shown in UPI apps<input className="field" name="name" defaultValue={name} required /></label>
      {state.error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{state.error}</p>}
      {state.message && <p role="status" className="rounded-xl bg-lime p-3 text-sm font-bold">{state.message}</p>}
      <button className="btn" disabled={pending}>{pending ? 'Saving' : 'Save'}</button>
    </form>
  );
}
