import { createClient } from '@/lib/supabase/server';
import { UpiForm } from './form';
import { BizForm } from './biz-form';

export const metadata = { title: 'Settings' };

export default async function Settings() {
  const supabase = await createClient();
  const { data } = await supabase.from('website_settings').select('key, value').in('key', ['payment.upi', 'business.profile']);
  const get = (k: string) => data?.find((r) => r.key === k)?.value ?? {};
  const upi = get('payment.upi');
  return (
    <>
      <h1 className="text-5xl font-extrabold tracking-tight">Settings</h1>
      <p className="mt-3 max-w-xl text-forest/80">Use the UPI ID of your business bank account. Customers pay straight into it.</p>
      <UpiForm vpa={upi.vpa ?? ''} name={upi.name ?? 'FUZENT'} />
      <BizForm v={get('business.profile')} />
    </>
  );
}
