import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { StatusTag } from '@/components/ui';
import { staffReply, setTicketStatus } from '../actions';

export const metadata = { title: 'Ticket' };

export default async function AdminTicket({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: t } = await supabase.from('support_tickets').select('id, subject, body, status, orders(order_no), profiles(email)').eq('id', id).maybeSingle();
  if (!t) notFound();
  const { data: msgs } = await supabase.from('ticket_messages').select('id, is_staff, body, created_at').eq('ticket_id', id).order('created_at');
  const o: any = Array.isArray(t.orders) ? t.orders[0] : t.orders, pr: any = Array.isArray(t.profiles) ? t.profiles[0] : t.profiles;
  return (
    <>
      <h1 className="text-4xl font-extrabold tracking-tight">{t.subject}</h1>
      <p className="mt-2"><StatusTag s={t.status} /> {pr?.email} {o?.order_no ? `· ${o.order_no}` : ''}</p>
      <div className="card mt-6"><p className="whitespace-pre-wrap">{t.body}</p></div>
      <div className="mt-4 grid gap-3">
        {(msgs ?? []).map((m) => <div key={m.id} className={`max-w-[85%] rounded-2xl border-2 border-forest p-3 ${m.is_staff ? 'ml-auto bg-lime' : 'bg-white'}`}><p className="whitespace-pre-wrap">{m.body}</p><p className="mt-1 text-xs opacity-70">{m.is_staff ? 'Staff' : 'Customer'} · {new Date(m.created_at).toLocaleString('en-IN')}</p></div>)}
      </div>
      <form action={staffReply} className="mt-6 flex gap-2"><input type="hidden" name="ticketId" value={id} /><label className="sr-only" htmlFor="b">Reply</label>
        <input id="b" name="body" className="field" required maxLength={2000} placeholder="Reply to the customer" autoComplete="off" /><button className="btn">Reply</button></form>
      <div className="mt-4 flex gap-2">
        {(['resolved', 'closed', 'open'] as const).map((s) => <form key={s} action={setTicketStatus}><input type="hidden" name="ticketId" value={id} /><input type="hidden" name="status" value={s} /><button className="btn btn-ghost min-h-[44px] px-4">Mark {s}</button></form>)}
      </div>
    </>
  );
}
