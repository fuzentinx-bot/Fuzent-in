'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { after } from 'next/server';
import { requireAdmin } from '@/lib/auth/require-admin';
import { admin } from '@/lib/supabase/admin';
import { processEvents } from '@/lib/automation';

export async function staffReply(fd: FormData) {
  const user = await requireAdmin();
  const p = z.object({ ticketId: z.string().uuid(), body: z.string().trim().min(1).max(2000) }).parse(Object.fromEntries(fd));
  const db = admin();
  await db.from('ticket_messages').insert({ ticket_id: p.ticketId, author_id: user.id, is_staff: true, body: p.body });
  await db.from('support_tickets').update({ status: 'pending' }).eq('id', p.ticketId);
  await db.from('automation_events').insert({ event_type: 'ticket.replied', payload: { ticket_id: p.ticketId } });
  after(() => processEvents());
  revalidatePath(`/admin/support/${p.ticketId}`);
}

export async function setTicketStatus(fd: FormData) {
  const user = await requireAdmin();
  const p = z.object({ ticketId: z.string().uuid(), status: z.enum(['open', 'pending', 'resolved', 'closed']) }).parse(Object.fromEntries(fd));
  const db = admin();
  await db.from('support_tickets').update({ status: p.status }).eq('id', p.ticketId);
  await db.from('audit_logs').insert({ actor_id: user.id, action: `ticket.${p.status}`, entity: 'support_ticket', entity_id: p.ticketId });
  revalidatePath(`/admin/support/${p.ticketId}`); revalidatePath('/admin/support');
}
