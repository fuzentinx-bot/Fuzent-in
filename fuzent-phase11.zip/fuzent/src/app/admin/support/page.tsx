import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { StatusTag } from '@/components/ui';

export const metadata = { title: 'Support inbox' };

export default async function SupportAdmin() {
  const supabase = await createClient();
  const [{ data: tickets }, { data: contacts }] = await Promise.all([
    supabase.from('support_tickets').select('id, subject, status, created_at').neq('status', 'closed').order('created_at', { ascending: false }).limit(50),
    supabase.from('contact_messages').select('id, name, email, message, created_at').order('created_at', { ascending: false }).limit(30),
  ]);
  return (
    <>
      <h1 className="text-5xl font-extrabold tracking-tight">Support inbox</h1>
      <h2 className="mb-3 mt-8 text-3xl font-extrabold">Tickets</h2>
      {!tickets?.length ? <p>No open tickets.</p> : <div className="grid gap-3">{tickets.map((t) => <Link key={t.id} href={`/admin/support/${t.id}`} className="card flex flex-wrap items-center justify-between gap-2"><b>{t.subject}</b><StatusTag s={t.status} /></Link>)}</div>}
      <h2 className="mb-3 mt-10 text-3xl font-extrabold">Contact form messages</h2>
      {!contacts?.length ? <p>None yet.</p> : <div className="grid gap-3">{contacts.map((c) => <div key={c.id} className="card"><p className="font-bold">{c.name} · {c.email}</p><p className="whitespace-pre-wrap">{c.message}</p><p className="text-xs opacity-70">{new Date(c.created_at).toLocaleString('en-IN')}</p></div>)}</div>}
    </>
  );
}
