import { createClient } from '@/lib/supabase/server';
import { hitLimit } from '@/lib/mem-limit';

export const dynamic = 'force-dynamic';

// Downloads the signed-in person's own data as JSON. Row Level Security means only their own rows come back.
export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new Response('Log in first', { status: 401 });
  if (hitLimit(`export:${user.id}`, 5, 3_600_000)) return new Response('Too many requests. Try again later.', { status: 429 });

  const get = async (table: string, select = '*', col?: string) => {
    let q = supabase.from(table).select(select);
    if (col) q = q.eq(col, user.id);
    return (await q.limit(5000)).data ?? [];
  };
  const [profile, orders, invoices, tickets, ticketMessages, messages, notifications, applications, creator, freelancer, brands] = await Promise.all([
    get('profiles'), get('orders', '*, order_items(*)'), get('invoices'), get('support_tickets'), get('ticket_messages'),
    get('messages', '*', 'sender_id'), get('notifications'), get('applications'), get('creators'), get('freelancers'), get('brands'),
  ]);
  const body = JSON.stringify({ exported_at: new Date().toISOString(), account: { id: user.id, email: user.email }, profile, orders, invoices, tickets, ticketMessages, messages, notifications, applications, creator, freelancer, brands }, null, 2);
  return new Response(body, { headers: { 'Content-Type': 'application/json', 'Content-Disposition': 'attachment; filename="fuzent-my-data.json"', 'Cache-Control': 'no-store' } });
}
