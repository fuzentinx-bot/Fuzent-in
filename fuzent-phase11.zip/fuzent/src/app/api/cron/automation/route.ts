import { timingSafeEqual } from 'crypto';
import { processEvents } from '@/lib/automation';
import { expireStaleOrders } from '@/lib/maintenance';

// Call every minute from any cron service with:  Authorization: Bearer <CRON_SECRET>
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return new Response('CRON_SECRET not set', { status: 503 });
  const given = Buffer.from(req.headers.get('authorization') ?? ''), want = Buffer.from(`Bearer ${secret}`);
  if (given.length !== want.length || !timingSafeEqual(given, want)) return new Response('Unauthorized', { status: 401 });
  return Response.json({ processed: await processEvents(50), expired: await expireStaleOrders() });
}
