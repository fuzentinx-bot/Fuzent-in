import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { admin } from '@/lib/supabase/admin';

// Signed-URL download, only for buyers with a PAID order containing the product.
export async function GET(_: Request, { params }: { params: Promise<{ productId: string }> }) {
  const { productId } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(productId)) return new NextResponse('Not found', { status: 404 });
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new NextResponse('Log in first', { status: 401 });

  const db = admin();
  const { data: owned } = await db.from('order_items')
    .select('id, orders!inner(customer_id, payment_status)')
    .eq('product_id', productId).eq('orders.customer_id', user.id).eq('orders.payment_status', 'paid').limit(1);
  if (!owned?.length) return new NextResponse('Not purchased', { status: 403 });

  const { data: prod } = await db.from('products').select('file_path').eq('id', productId).single();
  if (!prod?.file_path) return new NextResponse('File not available yet', { status: 404 });
  const { data: signed } = await db.storage.from('products').createSignedUrl(prod.file_path, 60, { download: true });
  if (!signed) return new NextResponse('Could not prepare download', { status: 500 });
  return NextResponse.redirect(signed.signedUrl);
}
