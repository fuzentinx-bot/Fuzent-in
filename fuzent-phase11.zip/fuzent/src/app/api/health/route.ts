import { admin } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

// For uptime monitors. Says only ok or not ok: no internal details.
export async function GET() {
  try {
    const { error } = await admin().from('roles').select('id').limit(1);
    if (error) throw error;
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 503 });
  }
}
