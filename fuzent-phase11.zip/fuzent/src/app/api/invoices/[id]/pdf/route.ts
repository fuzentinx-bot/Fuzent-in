import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { createClient } from '@/lib/supabase/server';

const rs = (p: number) => 'Rs. ' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: 2 });
const clean = (s: unknown) => String(s ?? '').replace(/[^\x20-\x7E]/g, '?'); // standard PDF fonts: basic characters only

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: inv } = await supabase.from('invoices').select('*').eq('id', id).single(); // RLS: owner or admin
  if (!inv || inv.status === 'draft') return new Response('Not found', { status: 404 });

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([595, 842]);
  const f = await pdf.embedFont(StandardFonts.Helvetica), fb = await pdf.embedFont(StandardFonts.HelveticaBold);
  const ink = rgb(0.04, 0.25, 0.18);
  let y = 790;
  const line = (t: string, o: { x?: number; b?: boolean; s?: number } = {}) => { page.drawText(clean(t), { x: o.x ?? 50, y, size: o.s ?? 10, font: o.b ? fb : f, color: ink }); };
  const row = (a: string, b: string, bold = false) => { line(a, { b: bold }); line(b, { x: 430, b: bold }); y -= 16; };
  const s = inv.seller_snapshot ?? {};

  line(s.name ?? 'FUZENT', { b: true, s: 20 }); y -= 18;
  if (s.address) { line(s.address); y -= 14; }
  if (inv.seller_gstin) { line('GSTIN: ' + inv.seller_gstin); y -= 14; }
  y -= 14; line('TAX INVOICE', { b: true, s: 14 }); y -= 20;
  line('Invoice no: ' + inv.invoice_no); y -= 14;
  line('Date: ' + new Date(inv.issued_at ?? inv.created_at).toLocaleDateString('en-IN')); y -= 14;
  line('Billed to: ' + (inv.buyer_name ?? '')); y -= 14;
  if (inv.buyer_gstin) { line('Buyer GSTIN: ' + inv.buyer_gstin); y -= 14; }
  y -= 12; page.drawLine({ start: { x: 50, y }, end: { x: 545, y }, thickness: 1, color: ink }); y -= 18;
  for (const l of inv.lines as any[]) row(`${l.title_snapshot} x ${l.quantity}`, rs(l.unit_price_paise * l.quantity));
  y -= 6; page.drawLine({ start: { x: 50, y }, end: { x: 545, y }, thickness: 0.5, color: ink }); y -= 16;
  if (inv.discount_paise) row('Discount', '- ' + rs(inv.discount_paise));
  row('Taxable value', rs(inv.subtotal_paise));
  if (inv.cgst_paise) row('CGST', rs(inv.cgst_paise));
  if (inv.sgst_paise) row('SGST', rs(inv.sgst_paise));
  if (inv.igst_paise) row('IGST', rs(inv.igst_paise));
  row('Total', rs(inv.total_paise), true);
  if (inv.sac_hsn) { y -= 6; line('SAC/HSN: ' + inv.sac_hsn); }
  y -= 24; line('Payment status: Paid', { b: true });

  const bytes = await pdf.save();
  return new Response(Buffer.from(bytes), {
    headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="${inv.invoice_no.replace(/\//g, '-')}.pdf"`, 'Cache-Control': 'private, no-store' },
  });
}
