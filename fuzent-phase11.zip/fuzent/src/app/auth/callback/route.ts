import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { safeRedirectPath } from '@/lib/safe-redirect';

// Handles the email-verification and Google OAuth redirect.
export async function GET(request: Request) {
  const { searchParams, origin: internal } = new URL(request.url);
  const origin = process.env.NEXT_PUBLIC_SITE_URL ?? internal;
  const next = safeRedirectPath(searchParams.get('next'));
  const code = searchParams.get('code');
  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(`${origin}${next}`);
  }
  return NextResponse.redirect(`${origin}/login?error=callback`);
}
