'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { bail, needUser, httpsUrl } from '@/lib/forms';
import { admin } from '@/lib/supabase/admin';

export async function registerBrand(fd: FormData) {
  const { supabase, user } = await needUser('/brand/new');
  const p = z.object({ name: z.string().trim().min(2).max(80), website: httpsUrl, industry: z.string().trim().max(60) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/brand/new', p.error.issues[0].message);
  const { error } = await supabase.from('brands').insert({ owner_id: user.id, ...p.data });
  if (error) return bail('/brand/new', 'Could not save. Try again.');
  redirect('/brand');
}

export async function createCampaign(fd: FormData) {
  const { supabase } = await needUser('/brand/campaigns');
  const p = z.object({
    brandId: z.string().uuid(), title: z.string().trim().min(3).max(100), brief: z.string().trim().min(10).max(1500),
    budget: z.coerce.number().min(0).max(100000000), deliverables: z.string().max(800),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/brand/campaigns', p.error.issues[0].message);
  const { error } = await supabase.from('campaigns').insert({ // RLS: only for your approved brand
    brand_id: p.data.brandId, title: p.data.title, brief: p.data.brief, budget_paise: Math.round(p.data.budget * 100),
    deliverables: p.data.deliverables.split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 10), status: 'open',
  });
  if (error) return bail('/brand/campaigns', 'Your brand must be approved before you can post a campaign.');
  revalidatePath('/brand/campaigns');
  redirect('/brand/campaigns?done=1');
}

// Accept or reject an application. Ownership is checked here, then the server writes.
export async function decideApplication(fd: FormData) {
  const { user } = await needUser('/brand/applicants');
  const p = z.object({ id: z.string().uuid(), decision: z.enum(['accepted', 'rejected']) }).parse(Object.fromEntries(fd));
  const db = admin();
  const { data: a } = await db.from('applications').select('id, applicant_id, status, campaign_id, campaigns(id, title, brands(owner_id))').eq('id', p.id).single();
  const camp: any = Array.isArray(a?.campaigns) ? a?.campaigns[0] : a?.campaigns;
  const brand: any = Array.isArray(camp?.brands) ? camp.brands[0] : camp?.brands;
  if (!a || a.status !== 'submitted' || brand?.owner_id !== user.id) return bail('/brand/applicants', 'Not allowed.');
  await db.from('applications').update({ status: p.decision }).eq('id', a.id);
  if (p.decision === 'accepted') {
    const { data: conv } = await db.from('conversations').insert({ campaign_id: camp.id, title: camp.title }).select('id').single();
    if (conv) await db.from('conversation_members').insert([{ conversation_id: conv.id, user_id: user.id }, { conversation_id: conv.id, user_id: a.applicant_id }]);
  }
  await db.from('automation_events').insert({ event_type: `application.${p.decision}`, payload: { application_id: a.id } });
  revalidatePath('/brand/applicants');
}

export async function updateBrand(fd: FormData) {
  const { supabase } = await needUser('/brand/settings');
  const p = z.object({ id: z.string().uuid(), name: z.string().trim().min(2).max(80), website: httpsUrl, industry: z.string().trim().max(60) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/brand/settings', p.error.issues[0].message);
  await supabase.from('brands').update({ name: p.data.name, website: p.data.website, industry: p.data.industry }).eq('id', p.data.id); // RLS: own brand only
  revalidatePath('/brand/settings');
  redirect('/brand/settings?saved=1');
}
