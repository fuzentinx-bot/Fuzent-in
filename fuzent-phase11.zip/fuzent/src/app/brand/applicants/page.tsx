import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Err } from '@/components/ui';
import { Panel, Pill, one } from '@/components/dash/widgets';
import { decideApplication } from '../actions';

export const metadata = { title: 'Applicants' };

export default async function Applicants({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: apps } = await supabase.from('applications').select('id, applicant_id, pitch, quote_paise, status, campaigns(title)').not('campaign_id', 'is', null).order('created_at', { ascending: false });
  const ids = [...new Set((apps ?? []).map((a) => a.applicant_id))];
  const { data: cs } = ids.length ? await supabase.from('creators').select('user_id, handle').in('user_id', ids) : { data: [] as any[] };
  const handle = (id: string) => cs?.find((c: any) => c.user_id === id)?.handle ?? 'creator';
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Creator applicants</h1>
      <div className="mt-4"><Err e={sp.error} /></div>
      <Panel>
        {!apps?.length ? <p className="text-forest/70">No applicants yet. Approved creators apply from the Creators page.</p> : apps.map((a) => (
          <div key={a.id} className="mb-3 rounded-2xl border-2 border-forest p-4">
            <p><Link className="font-bold underline" href={`/creators/${handle(a.applicant_id)}`}>@{handle(a.applicant_id)}</Link> on {one(a.campaigns as any)?.title} · {inr(a.quote_paise ?? 0)} · <Pill s={a.status} /></p>
            <p className="mt-1 whitespace-pre-line">{a.pitch}</p>
            {a.status === 'submitted' && (
              <div className="mt-3 flex gap-2">{(['accepted', 'rejected'] as const).map((d) => (
                <form key={d} action={decideApplication}><input type="hidden" name="id" value={a.id} /><input type="hidden" name="decision" value={d} />
                  <button className={`btn min-h-[44px] px-4 ${d === 'rejected' ? 'btn-ghost' : ''}`}>{d === 'accepted' ? 'Accept' : 'Reject'}</button></form>
              ))}</div>
            )}
          </div>
        ))}
      </Panel>
    </>
  );
}
