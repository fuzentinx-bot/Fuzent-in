import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Err, Ok, F } from '@/components/ui';
import { Panel, Pill } from '@/components/dash/widgets';
import { createCampaign } from '../actions';

export const metadata = { title: 'Campaigns' };

export default async function Campaigns({ searchParams }: { searchParams: Promise<{ error?: string; done?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const [{ data: brands }, { data: camps }] = await Promise.all([
    supabase.from('brands').select('id, name, status'),
    supabase.from('campaigns').select('id, title, approval, budget_paise').order('created_at', { ascending: false }),
  ]);
  const approved = (brands ?? []).filter((b) => b.status === 'approved');
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Campaigns</h1>
      <div className="mt-4"><Err e={sp.error} /><Ok t={sp.done ? 'Campaign sent for review.' : undefined} /></div>
      <Panel title="New campaign">
        {!approved.length ? <p>Your brand must be approved first. <Link className="underline" href="/brand/new">Register a brand</Link></p> : (
          <form action={createCampaign} className="grid max-w-lg gap-4">
            <label className="grid gap-1 text-sm font-bold">Brand<select name="brandId" className="field">{approved.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></label>
            <F label="Title" name="title" /><F label="Brief" name="brief" area /><F label="Budget in rupees" name="budget" type="number" ph="10000" />
            <F label="Deliverables, one per line" name="deliverables" area req={false} /><button className="btn w-fit">Submit for review</button>
          </form>
        )}
      </Panel>
      <Panel title="Your campaigns">
        {!camps?.length ? <p className="text-forest/70">No campaigns yet.</p> : camps.map((c) => (
          <p key={c.id} className="mb-2 flex flex-wrap items-center justify-between gap-2"><b>{c.title}</b><span>{c.budget_paise ? inr(c.budget_paise) : ''} <Pill s={c.approval} /></span></p>
        ))}
      </Panel>
    </>
  );
}
