import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Panel, Pill } from '@/components/dash/widgets';

export const metadata = { title: 'Hire talent' };

export default async function Hire() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: projects } = await supabase.from('projects').select('id, title, status, is_open, budget_paise').eq('client_id', user!.id).eq('division', 'freelance').order('created_at', { ascending: false });
  const { data: apps } = await supabase.from('applications').select('project_id, status').eq('status', 'submitted').not('project_id', 'is', null);
  const waiting = (id: string) => (apps ?? []).filter((a) => a.project_id === id).length;
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Hire talent</h1>
      <Link href="/projects/new" className="btn mt-4">Post a project</Link>
      <Panel title="Your projects">
        {!projects?.length ? <p className="text-forest/70">No projects yet.</p> : projects.map((p) => (
          <p key={p.id} className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <Link className="font-bold underline" href={`/projects/${p.id}`}>{p.title}</Link>
            <span>{p.budget_paise ? inr(p.budget_paise) : ''} <Pill s={p.is_open ? 'open' : p.status} /> {waiting(p.id) ? `${waiting(p.id)} new applicants` : ''}</span>
          </p>
        ))}
      </Panel>
    </>
  );
}
