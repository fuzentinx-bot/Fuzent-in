import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { DashShell } from '@/components/dash/shell';

export default async function BrandLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/brand');
  const [{ count: ca }, { count: pa }] = await Promise.all([
    supabase.from('applications').select('id', { count: 'exact', head: true }).eq('status', 'submitted').not('campaign_id', 'is', null), // RLS: only your campaigns
    supabase.from('applications').select('id', { count: 'exact', head: true }).eq('status', 'submitted').not('project_id', 'is', null).neq('applicant_id', user.id),
  ]);
  return (
    <DashShell label="Brand hub" links={[['/dashboard', 'My account'], ['/freelancer', 'Freelancer hub']]} nav={[
      { href: '/brand', label: 'Overview', icon: '▦', exact: true },
      { href: '/brand/campaigns', label: 'Campaigns', icon: '◎' },
      { href: '/brand/applicants', label: 'Applicants', icon: '☑', badge: ca ?? 0 },
      { href: '/brand/hire', label: 'Hire talent', icon: '⚑', badge: pa ?? 0 },
      { href: '/brand/settings', label: 'Settings', icon: '⚙' },
    ]}>{children}</DashShell>
  );
}
