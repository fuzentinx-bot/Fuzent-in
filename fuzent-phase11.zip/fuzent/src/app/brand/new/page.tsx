import { Err, F } from '@/components/ui';
import { registerBrand } from '../actions';

export const metadata = { title: 'Register a brand' };

export default async function NewBrand({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const sp = await searchParams;
  return (
    <main className="mx-auto max-w-xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Register a brand</h1>
      <div className="mt-4"><Err e={sp.error} /></div>
      <form action={registerBrand} className="card grid gap-4">
        <F label="Brand name" name="name" /><F label="Website" name="website" type="url" ph="https://" /><F label="Industry" name="industry" req={false} />
        <button className="btn">Register</button>
      </form>
      <p className="mt-3 text-sm text-forest/70">We review every brand before it can post campaigns.</p>
    </main>
  );
}
