import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Kpis, Panel, Bars, Donut, Feed, Pill, appParts } from '@/components/dash/widgets';

export const metadata = { title: 'Brand hub' };

export default async function BrandHome() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const [{ data: brands }, { data: camps }, { data: capps }, { data: projects }, { data: papps }, { data: feed }] = await Promise.all([
    supabase.from('brands').select('id, name, status'),
    supabase.from('campaigns').select('id, title, budget_paise, approval'),
    supabase.from('applications').select('status').not('campaign_id', 'is', null),
    supabase.from('projects').select('id').eq('client_id', user!.id).eq('division', 'freelance'),
    supabase.from('applications').select('status').not('project_id', 'is', null).neq('applicant_id', user!.id),
    supabase.from('notifications').select('title, body, created_at').order('created_at', { ascending: false }).limit(5),
  ]);
  if (!brands?.length) return (
    <div><h1 className="mt-2 text-4xl font-extrabold tracking-tight">Brand hub</h1>
      <p className="my-4">Register your brand first. We review it before it can post campaigns.</p><Link className="btn" href="/brand/new">Register a brand</Link></div>
  );
  const all = [...(capps ?? []), ...(papps ?? [])], cs = camps ?? [];
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Brand hub</h1>
      <p className="mt-1">{brands.map((b) => <span key={b.id} className="mr-3 font-bold">{b.name} <Pill s={b.status} /></span>)}</p>
      <div className="mt-4"><Kpis items={[
        { tone: 1, label: 'Campaigns', value: cs.length }, { tone: 2, label: 'Live', value: cs.filter((c) => c.approval === 'approved').length },
        { tone: 3, label: 'Applicants', value: all.length }, { tone: 4, label: 'Projects posted', value: projects?.length ?? 0 },
      ]} /></div>
      <div className="cg">
        <Panel title="Budget by campaign"><Bars label="Budget per campaign" data={cs.slice(0, 8).map((c) => ({ label: c.id, value: (c.budget_paise ?? 0) / 100 }))} /></Panel>
        <Panel title="Applicants by status"><Donut label="Applicants by status" parts={appParts(all)} /></Panel>
      </div>
      <Feed items={feed ?? []} />
    </>
  );
}
