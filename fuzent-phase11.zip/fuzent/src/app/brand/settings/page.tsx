import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { Err, Ok, F } from '@/components/ui';
import { Panel, Pill } from '@/components/dash/widgets';
import { PrefsForm } from '@/components/dash/prefs-form';
import { updateBrand } from '../actions';

export const metadata = { title: 'Brand settings' };

export default async function BrandSettings({ searchParams }: { searchParams: Promise<{ error?: string; saved?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: brands } = await supabase.from('brands').select('id, name, website, industry, status');
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Settings</h1>
      <div className="mt-4"><Err e={sp.error} /><Ok t={sp.saved ? 'Saved.' : undefined} /></div>
      {!brands?.length ? <p>Register a brand first. <Link className="underline" href="/brand/new">Register a brand</Link></p> : brands.map((b) => (
        <Panel key={b.id} title="Brand profile">
          <p className="mb-3">Status: <Pill s={b.status} /></p>
          <form action={updateBrand} className="grid max-w-lg gap-4"><input type="hidden" name="id" value={b.id} />
            <F label="Brand name" name="name" def={b.name} /><F label="Website" name="website" type="url" def={b.website ?? ''} /><F label="Industry" name="industry" def={b.industry ?? ''} req={false} />
            <button className="btn w-fit">Save brand</button></form>
        </Panel>
      ))}
      <PrefsForm back="/brand/settings" />
    </>
  );
}
