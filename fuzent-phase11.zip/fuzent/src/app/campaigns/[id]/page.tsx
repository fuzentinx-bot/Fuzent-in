import Link from 'next/link';
import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Err, Ok, F } from '@/components/ui';
import { applyCampaign } from '@/app/creators/actions';

export const metadata = { title: 'Campaign' };

export default async function Campaign({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ error?: string; done?: string }> }) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  const supabase = await createClient();
  const { data: c } = await supabase.from('campaigns').select('id, title, brief, budget_paise, deliverables').eq('id', id).eq('approval', 'approved').maybeSingle();
  if (!c) notFound();
  const { data: { user } } = await supabase.auth.getUser();
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">{c.title}</h1>
      {c.budget_paise ? <p className="mt-3 text-2xl font-extrabold">{inr(c.budget_paise)}</p> : null}
      <p className="mt-4 whitespace-pre-line text-lg">{c.brief}</p>
      {Array.isArray(c.deliverables) && c.deliverables.length > 0 && (
        <ul className="mt-4 list-disc pl-5">{c.deliverables.map((d: string, i: number) => <li key={i}>{d}</li>)}</ul>
      )}
      <div className="mt-8"><Err e={sp.error} /><Ok t={sp.done ? 'Application sent. The brand will reply in your messages if you are accepted.' : undefined} />
        {!user ? <Link className="btn" href={`/login?next=/campaigns/${c.id}`}>Log in to apply</Link> : (
          <form action={applyCampaign} className="card grid gap-4">
            <input type="hidden" name="campaignId" value={c.id} />
            <F label="Your pitch" name="pitch" area />
            <F label="Your quote in rupees" name="quote" type="number" ph="5000" />
            <button className="btn">Apply</button>
          </form>
        )}
      </div>
    </main>
  );
}
