'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { createClient } from '@/lib/supabase/server';
import { admin } from '@/lib/supabase/admin';
import { priceOrder } from '@/lib/pricing';
import { hitLimit } from '@/lib/mem-limit';
import { tooManyOrders } from '@/lib/order-limits';

const id = z.string().uuid();

export async function addToCart(productId: string): Promise<{ ok?: true; error?: string; code?: 'auth' }> {
  if (!id.safeParse(productId).success) return { error: 'Invalid product.' };
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Log in first.', code: 'auth' };
  const { data: ex } = await supabase.from('cart_items').select('qty').eq('product_id', productId).maybeSingle();
  await supabase.from('cart_items').upsert({ user_id: user.id, product_id: productId, qty: Math.min((ex?.qty ?? 0) + 1, 10) });
  revalidatePath('/cart');
  return { ok: true };
}

export async function setQty(formData: FormData) {
  const p = z.object({ productId: id, qty: z.coerce.number().int().min(0).max(10) }).safeParse(Object.fromEntries(formData));
  if (!p.success) return;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;
  if (p.data.qty < 1) await supabase.from('cart_items').delete().eq('product_id', p.data.productId);
  else await supabase.from('cart_items').update({ qty: p.data.qty }).eq('product_id', p.data.productId);
  revalidatePath('/cart');
}

const back = (msg: string, coupon = ''): never =>
  redirect(`/cart?error=${encodeURIComponent(msg)}${coupon ? `&coupon=${encodeURIComponent(coupon)}` : ''}`);

export async function startCartCheckout(formData: FormData) {
  const coupon = String(formData.get('coupon') ?? '').trim().slice(0, 40);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/cart');

  if (coupon && hitLimit(`coupon:${user.id}`, 10, 600_000)) return back('Too many coupon tries. Please wait a few minutes.', coupon);
  const { data: rows } = await supabase.from('cart_items').select('qty, products(id, title, price_paise, is_active)');
  const lines = (rows ?? []).map((r: any) => ({ ...r.products, qty: r.qty })).filter((p: any) => p?.is_active);
  if (!lines.length) return back('Your cart is empty.');

  const subtotal = lines.reduce((a: number, l: any) => a + l.price_paise * l.qty, 0);
  const db = admin();
  if (await tooManyOrders(db, user.id)) return back('Too many orders started. Please wait a little.', coupon);
  const priced = await priceOrder(db, user.id, subtotal, coupon);
  if ('error' in priced) return back(priced.error, coupon);
  if (priced.total < 100) return back('Order total is too low.');

  const { data: order } = await db.from('orders').insert({
    customer_id: user.id, division: 'digital', subtotal_paise: subtotal, discount_paise: priced.discount,
    total_paise: priced.total, coupon_id: priced.coupon?.id ?? null,
  }).select('id').single();
  if (!order) return back('Could not start checkout. Try again.', coupon);

  if (priced.coupon) { // claim atomically: fails if the last redemption was just taken
    const { data: c } = await db.from('coupons').select('redeemed, max_redemptions').eq('id', priced.coupon.id).single();
    const { data: claimed } = await db.from('coupons').update({ redeemed: (c?.redeemed ?? 0) + 1 })
      .eq('id', priced.coupon.id).eq('redeemed', c?.redeemed ?? 0).select('id');
    const full = c?.max_redemptions != null && (c?.redeemed ?? 0) >= c.max_redemptions;
    if (!claimed?.length || full) { await db.from('orders').delete().eq('id', order.id); return back('That coupon was just used up.', coupon); }
    await db.from('coupon_redemptions').insert({ coupon_id: priced.coupon.id, user_id: user.id, order_id: order.id });
  }
  await db.from('order_items').insert(lines.map((l: any) => ({ order_id: order.id, product_id: l.id, title_snapshot: l.title, unit_price_paise: l.price_paise, quantity: l.qty })));
  await db.from('payments').insert({ order_id: order.id, gateway: 'upi_direct', amount_paise: priced.total, status: 'created' });
  await supabase.from('cart_items').delete().eq('user_id', user.id);
  redirect(`/checkout/${order.id}`);
}
