import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { admin } from '@/lib/supabase/admin';
import { priceOrder } from '@/lib/pricing';
import { hitLimit } from '@/lib/mem-limit';
import { inr } from '@/lib/money';
import { setQty, startCartCheckout } from './actions';

export const metadata = { title: 'Cart' };

export default async function Cart({ searchParams }: { searchParams: Promise<{ coupon?: string; error?: string }> }) {
  const { coupon = '', error = '' } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/cart');

  const { data } = await supabase.from('cart_items').select('qty, products(id, title, price_paise, is_active)');
  const items = (data ?? []).map((r: any) => ({ ...r.products, qty: r.qty })).filter((p: any) => p?.is_active);
  const subtotal = items.reduce((a: number, l: any) => a + l.price_paise * l.qty, 0);
  const limited = !!coupon && hitLimit(`coupon:${user.id}`, 10, 600_000);
  const preview = coupon && subtotal && !limited ? await priceOrder(admin(), user.id, subtotal, coupon) : null;
  const couponError = limited ? 'Too many coupon tries. Please wait a few minutes.' : preview && 'error' in preview ? preview.error : '';
  const applied = preview && !('error' in preview) ? preview : null;
  const total = applied ? applied.total : subtotal;

  return (
    <main className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Your cart</h1>
      {error && <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      {!items.length ? (
        <p className="mt-6">Nothing here yet. <Link className="underline" href="/store">Browse the store</Link></p>
      ) : (
        <>
          <div className="mt-6 grid gap-3">
            {items.map((i: any) => (
              <div key={i.id} className="card flex flex-wrap items-center justify-between gap-3">
                <div><p className="font-bold">{i.title}</p><p>{inr(i.price_paise)} each</p></div>
                <div className="flex items-center gap-2">
                  <form action={setQty} className="flex gap-2">
                    <input type="hidden" name="productId" value={i.id} />
                    <label className="sr-only" htmlFor={`q${i.id}`}>Quantity</label>
                    <input id={`q${i.id}`} className="field w-20" name="qty" type="number" min={1} max={10} defaultValue={i.qty} />
                    <button className="btn btn-ghost min-h-[44px] px-4">Update</button>
                  </form>
                  <form action={setQty}><input type="hidden" name="productId" value={i.id} /><input type="hidden" name="qty" value="0" /><button className="btn btn-ghost min-h-[44px] px-4" aria-label={`Remove ${i.title}`}>Remove</button></form>
                </div>
              </div>
            ))}
          </div>
          <form className="mt-6 flex max-w-md gap-2" role="search">
            <label className="sr-only" htmlFor="coupon">Coupon code</label>
            <input id="coupon" name="coupon" defaultValue={coupon} placeholder="Coupon code" className="field" />
            <button className="btn btn-ghost">Apply</button>
          </form>
          {couponError && <p role="alert" className="mt-2 text-sm text-red-800">{couponError}</p>}
          <div className="card mt-6 grid gap-2">
            <p className="flex justify-between"><span>Subtotal</span><span>{inr(subtotal)}</span></p>
            {applied && <p className="flex justify-between"><span>Coupon {applied.coupon?.code}</span><span>- {inr(applied.discount)}</span></p>}
            <p className="flex justify-between border-t-2 border-forest pt-2 text-2xl font-extrabold"><span>Total</span><span>{inr(total)}</span></p>
            <form action={startCartCheckout}>
              <input type="hidden" name="coupon" value={applied ? coupon : ''} />
              <button className="btn mt-2 w-full">Go to checkout</button>
            </form>
          </div>
        </>
      )}
    </main>
  );
}
