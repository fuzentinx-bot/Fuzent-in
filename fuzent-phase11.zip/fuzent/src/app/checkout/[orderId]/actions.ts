'use server';

import { after } from 'next/server';
import { processEvents } from '@/lib/automation';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createClient } from '@/lib/supabase/server';
import { admin } from '@/lib/supabase/admin';

export type UtrState = { error?: string; message?: string };

export async function submitUtr(_: UtrState, formData: FormData): Promise<UtrState> {
  const parsed = z.object({
    orderId: z.string().uuid(),
    utr: z.string().trim().regex(/^\d{12}$/, 'The transaction ID (UTR) is 12 digits. Copy it from your UPI app.'),
  }).safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const { orderId, utr } = parsed.data;

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Please log in again.' };

  const { data: pay } = await supabase.from('payments').select('id, status').eq('order_id', orderId).single(); // RLS: own orders only
  if (!pay || pay.status !== 'created') return { error: 'This order cannot accept a payment submission.' };

  const db = admin();
  const { count: waiting } = await db.from('payments').select('id, orders!inner(customer_id)', { count: 'exact', head: true }).eq('status', 'pending').eq('orders.customer_id', user.id);
  if ((waiting ?? 0) >= 5) return { error: 'You already have several payments waiting to be checked. Please wait for them first.' };
  const { error } = await db.from('payments')
    .update({ utr, status: 'pending', submitted_at: new Date().toISOString(), failure_reason: null })
    .eq('id', pay.id).eq('status', 'created');
  if (error?.code === '23505') return { error: 'That transaction ID is already linked to another order.' };
  if (error) return { error: 'Could not save that. Try again.' };

  await db.from('orders').update({ payment_status: 'pending' }).eq('id', orderId);
  await db.from('automation_events').insert({ event_type: 'payment.submitted', payload: { order_id: orderId, payment_id: pay.id } });
  revalidatePath(`/checkout/${orderId}`);
  after(() => processEvents());
  return { message: 'Received. We will confirm it once it shows in our bank account.' };
}
