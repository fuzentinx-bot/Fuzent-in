import { notFound, redirect } from 'next/navigation';
import QRCode from 'qrcode';
import { createClient } from '@/lib/supabase/server';
import { admin } from '@/lib/supabase/admin';
import { inr } from '@/lib/money';
import { upiLinks, upiQuery } from '@/lib/upi';
import { AutoRefresh } from '@/components/auto-refresh';
import { UtrForm } from './utr-form';
import { CopyButton } from './copy-button';

export const metadata = { title: 'Checkout' };

export default async function Checkout({ params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const supabase = await createClient();
  const { data: o } = await supabase.from('orders')
    .select('id, order_no, total_paise, payment_status, order_items(id, title_snapshot), payments(status, utr, failure_reason)')
    .eq('id', orderId).single(); // RLS: not yours = null
  if (!o) notFound();
  const pay = o.payments?.[0];
  if (o.payment_status === 'paid') redirect(`/orders/${o.id}`);

  const { data: cfg } = await admin().from('website_settings').select('value').eq('key', 'payment.upi').single();
  const vpa: string | undefined = cfg?.value?.vpa;
  const payee: string = cfg?.value?.name ?? 'FUZENT';

  return (
    <main className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Checkout</h1>
      <div className="mt-8 grid items-start gap-6 md:grid-cols-2">
        <section className="card grid gap-3" aria-label="Order summary">
          <h2 className="text-xl font-bold">{o.order_no}</h2>
          {o.order_items.map((i: any) => <p key={i.id}>{i.title_snapshot}</p>)}
          <p className="border-t-2 border-forest pt-3 text-3xl font-extrabold">{inr(o.total_paise)}</p>
        </section>

        {pay?.status === 'pending' ? (
          <section className="card grid gap-3">
            <AutoRefresh />
            <h2 className="text-xl font-bold">Checking your payment</h2>
            <p>We have your transaction ID <b>{pay.utr}</b>. This page updates by itself once it is confirmed.</p>
          </section>
        ) : !vpa ? (
          <section className="card"><h2 className="text-xl font-bold">Payments are not set up yet</h2><p className="mt-2">Please contact us to complete this order.</p></section>
        ) : (
          <Pay order={o} vpa={vpa} payee={payee} reason={pay?.failure_reason} />
        )}
      </div>
    </main>
  );
}

async function Pay({ order, vpa, payee, reason }: { order: any; vpa: string; payee: string; reason?: string | null }) {
  const q = upiQuery({ vpa, name: payee, paise: order.total_paise, ref: order.order_no });
  const qr = await QRCode.toDataURL(`upi://pay?${q}`, { margin: 2, width: 360, color: { dark: '#0A3F2F', light: '#F3F0E4' } });
  return (
    <section className="card grid gap-5">
      {reason && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">We could not match your last submission: {reason}. Please check the ID and send it again.</p>}
      <div>
        <h2 className="text-xl font-bold">1. Pay {inr(order.total_paise)}</h2>
        <div className="mt-3 grid grid-cols-2 gap-2 md:hidden">
          {upiLinks(q).map((l) => <a key={l.label} href={l.href} className="btn min-h-[44px] px-3 text-sm">{l.label}</a>)}
        </div>
        <p className="mt-2 text-sm text-forest/70 md:hidden">If a button does nothing, that app is not installed. Use Any UPI app.</p>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={qr} alt={`UPI QR code to pay ${inr(order.total_paise)} to ${payee}`} width={240} height={240} className="mx-auto mt-4 rounded-2xl border-2 border-forest" />
        <p className="mt-2 text-center text-sm">Scan with any UPI app, or pay to <b>{vpa}</b></p>
        <div className="mt-2 flex justify-center gap-2"><CopyButton text={vpa} label="Copy UPI ID" /><CopyButton text={(order.total_paise / 100).toFixed(2)} label="Copy amount" /></div>
      </div>
      <div>
        <h2 className="mb-3 text-xl font-bold">2. Tell us it is done</h2>
        <UtrForm orderId={order.id} />
        <p className="mt-3 text-sm text-forest/70">A screenshot or scan is not proof of payment. We confirm each order against our bank account.</p>
      </div>
    </section>
  );
}
