'use client';

import { useActionState } from 'react';
import { submitUtr, type UtrState } from './actions';

export function UtrForm({ orderId }: { orderId: string }) {
  const [state, action, pending] = useActionState<UtrState, FormData>(submitUtr, {});
  return (
    <form action={action} className="grid gap-3">
      <input type="hidden" name="orderId" value={orderId} />
      <label className="grid gap-1 text-sm font-bold">
        Transaction ID (UTR) from your UPI app
        <input className="field" name="utr" inputMode="numeric" pattern="\d{12}" maxLength={12} placeholder="12 digits" required />
      </label>
      {state.error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{state.error}</p>}
      {state.message && <p role="status" className="rounded-xl bg-lime p-3 text-sm font-bold">{state.message}</p>}
      <button className="btn" disabled={pending}>{pending ? 'Please wait' : 'I have paid'}</button>
    </form>
  );
}
