'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { bail } from '@/lib/forms';
import { admin } from '@/lib/supabase/admin';
import { tooMany } from '@/lib/rate-limit';
import { sendEmail } from '@/lib/email';

export async function sendContact(fd: FormData) {
  const p = z.object({ name: z.string().trim().min(2).max(80), email: z.string().trim().toLowerCase().email('Enter a valid email.'), message: z.string().trim().min(10).max(2000) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/contact', p.error.issues[0].message);
  if (await tooMany('contact_messages', 'email', p.data.email)) return bail('/contact', 'Too many messages this hour. Please try later.');
  await admin().from('contact_messages').insert(p.data);
  if (process.env.ADMIN_EMAIL) await sendEmail(process.env.ADMIN_EMAIL, `Contact form: ${p.data.name}`, `${p.data.email}\n\n${p.data.message}`);
  redirect('/contact?done=1');
}
