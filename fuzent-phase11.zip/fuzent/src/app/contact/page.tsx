import { Err, Ok, F } from '@/components/ui';
import { sendContact } from './actions';

export const metadata = { title: 'Contact' };

export default async function Contact({ searchParams }: { searchParams: Promise<{ error?: string; done?: string }> }) {
  const sp = await searchParams;
  return (
    <main className="mx-auto max-w-xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Say hi</h1>
      <div className="mt-4"><Err e={sp.error} /><Ok t={sp.done ? 'Sent. We will reply by email.' : undefined} /></div>
      <form action={sendContact} className="card grid gap-4">
        <F label="Name" name="name" /><F label="Email" name="email" type="email" /><F label="Message" name="message" area />
        <button className="btn">Send</button>
      </form>
    </main>
  );
}
