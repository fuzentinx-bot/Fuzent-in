import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getCreator } from '@/lib/public-data';

type Props = { params: Promise<{ handle: string }> };
const load = (h: string) => getCreator(h);

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const c = await load((await params).handle);
  return c ? { title: `@${c.handle}`, description: c.bio?.slice(0, 150) } : {};
}

export default async function CreatorPage({ params }: Props) {
  const c = await load((await params).handle);
  if (!c) notFound();
  const ig = c.social_links?.instagram, yt = c.social_links?.youtube;
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">@{c.handle}</h1>
      <p className="mt-2 font-bold">{c.niche?.join(', ')}</p>
      <p className="mt-4 whitespace-pre-line text-lg">{c.bio}</p>
      <div className="mt-6 flex flex-wrap gap-3">
        {ig && <a className="btn" rel="noopener noreferrer" target="_blank" href={`https://instagram.com/${ig}`}>Instagram</a>}
        {yt && yt.startsWith('https://') && <a className="btn btn-ghost" rel="noopener noreferrer" target="_blank" href={yt}>YouTube</a>}
      </div>
      {c.portfolio?.length > 0 && (
        <div className="mt-8"><h2 className="mb-2 text-xl font-bold">Portfolio</h2>
          {c.portfolio.filter((u: string) => u.startsWith('https://')).map((u: string) => <a key={u} className="block underline" rel="noopener noreferrer" target="_blank" href={u}>{u}</a>)}
        </div>
      )}
    </main>
  );
}
