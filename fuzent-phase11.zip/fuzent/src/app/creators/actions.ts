'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { bail, needUser, parseLinks } from '@/lib/forms';

export async function joinCreator(fd: FormData) {
  const { supabase, user } = await needUser('/creators/join');
  const p = z.object({
    handle: z.string().trim().toLowerCase().regex(/^[a-z0-9._]{3,30}$/, 'Handle: 3-30 letters, digits, dot or underscore.'),
    bio: z.string().trim().max(500),
    niche: z.string().trim().min(2).max(60),
    instagram: z.string().trim().regex(/^@?[A-Za-z0-9._]{1,30}$/, 'Enter your Instagram handle.'),
    youtube: z.string().trim().refine((v) => !v || v.startsWith('https://'), 'The YouTube link must start with https://'),
    portfolio: z.string(),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/creators/join', p.error.issues[0].message);
  const portfolio = parseLinks(p.data.portfolio);
  if (!portfolio) return bail('/creators/join', 'Portfolio links must be https:// links, one per line.');
  const { error } = await supabase.from('creators').insert({
    user_id: user.id, handle: p.data.handle, bio: p.data.bio, niche: [p.data.niche],
    social_links: { instagram: p.data.instagram.replace('@', ''), youtube: p.data.youtube }, portfolio,
  });
  if (error) return bail('/creators/join', error.code === '23505' ? 'That handle is taken, or you already have a profile.' : 'Could not save. Try again.');
  revalidatePath('/creators');
  redirect('/creators/join?done=1');
}

export async function applyCampaign(fd: FormData) {
  const p = z.object({ campaignId: z.string().uuid(), pitch: z.string().trim().min(10, 'Tell the brand a little more.').max(800), quote: z.coerce.number().min(0).max(10000000) }).safeParse(Object.fromEntries(fd));
  const back = `/campaigns/${String(fd.get('campaignId'))}`;
  const { supabase, user } = await needUser(back);
  if (!p.success) return bail(back, p.error.issues[0].message);
  const { data: me } = await supabase.from('creators').select('status').eq('user_id', user.id).maybeSingle();
  if (me?.status !== 'approved') return bail(back, 'Only approved creators can apply. Check your creator profile status.');
  const { data: c } = await supabase.from('campaigns').select('id').eq('id', p.data.campaignId).eq('status', 'open').eq('approval', 'approved').maybeSingle();
  if (!c) return bail(back, 'This campaign is closed.');
  const { error } = await supabase.from('applications').insert({ applicant_id: user.id, campaign_id: c.id, pitch: p.data.pitch, quote_paise: Math.round(p.data.quote * 100) });
  if (error) return bail(back, error.code === '23505' ? 'You already applied to this campaign.' : 'Could not send. Try again.');
  redirect(`${back}?done=1`);
}
