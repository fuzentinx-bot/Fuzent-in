import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Err, Ok, F, StatusTag } from '@/components/ui';
import { joinCreator } from '../actions';

export const metadata = { title: 'Join as creator' };

export default async function Join({ searchParams }: { searchParams: Promise<{ error?: string; done?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/creators/join');
  const { data: me } = await supabase.from('creators').select('handle, status').eq('user_id', user.id).maybeSingle();
  return (
    <main className="mx-auto max-w-xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Creator profile</h1>
      <Err e={sp.error} /><Ok t={sp.done ? 'Sent. We review every profile before it goes live.' : undefined} />
      {me ? (
        <p className="card mt-6">@{me.handle} <StatusTag s={me.status} /></p>
      ) : (
        <form action={joinCreator} className="card mt-6 grid gap-4">
          <F label="Handle (your public name)" name="handle" ph="yourpage" />
          <F label="Instagram handle" name="instagram" ph="@yourpage" />
          <F label="Niche" name="niche" ph="Memes and comedy" />
          <F label="About you" name="bio" area req={false} />
          <F label="YouTube link (optional)" name="youtube" type="url" req={false} ph="https://" />
          <F label="Portfolio links, one per line (https only)" name="portfolio" area req={false} />
          <button className="btn">Apply</button>
        </form>
      )}
    </main>
  );
}
