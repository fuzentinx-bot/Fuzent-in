import Link from 'next/link';
import { getCreators, getOpenCampaigns } from '@/lib/public-data';
import { inr } from '@/lib/money';

export const metadata = { title: 'Creators', description: 'Brands and creators, matched for paid collaborations.' };

export default async function Creators() {
  const [creators, campaigns] = await Promise.all([getCreators(), getOpenCampaigns()]);
  return (
    <main className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Creators and brands</h1>
      <div className="mt-6 flex flex-wrap gap-3">
        <Link href="/creators/join" className="btn">Join as creator</Link>
        <Link href="/brand" className="btn btn-ghost">I&rsquo;m a brand</Link>
      </div>
      <h2 className="mb-4 mt-12 text-3xl font-extrabold">Open campaigns</h2>
      {!campaigns.length ? <p className="text-forest/70">No open campaigns yet.</p> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((c) => (
            <Link key={c.id} href={`/campaigns/${c.id}`} className="card block transition hover:-rotate-1">
              <h3 className="text-xl font-bold">{c.title}</h3>
              <p className="mt-1 line-clamp-3 text-forest/70">{c.brief}</p>
              {c.budget_paise ? <p className="mt-3 font-extrabold">{inr(c.budget_paise)}</p> : null}
            </Link>
          ))}
        </div>
      )}
      <h2 className="mb-4 mt-12 text-3xl font-extrabold">Creators</h2>
      {!creators.length ? <p className="text-forest/70">No approved creators yet.</p> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {creators.map((c) => (
            <Link key={c.user_id} href={`/creators/${c.handle}`} className="card block transition hover:-rotate-1">
              <h3 className="text-xl font-bold">@{c.handle}</h3>
              <p className="text-sm font-bold">{c.niche?.join(', ')}</p>
              <p className="mt-1 line-clamp-3 text-forest/70">{c.bio}</p>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
