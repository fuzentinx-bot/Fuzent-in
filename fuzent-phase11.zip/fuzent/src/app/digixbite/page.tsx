import { ServicePage } from '@/components/service-page';

export const metadata = { title: 'DigixBite', description: 'Websites, CRM and automation built around how your business works.' };

export default async function Page({ searchParams }: { searchParams: Promise<{ error?: string; done?: string }> }) {
  const sp = await searchParams;
  return <ServicePage division="digixbite" title="DigixBite" intro="Websites, CRM and automation built around how your business works." error={sp.error} done={sp.done} />;
}
