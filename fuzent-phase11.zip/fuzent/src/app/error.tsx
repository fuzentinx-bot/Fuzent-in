'use client';

export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="mx-auto max-w-xl px-6 py-20">
      <h1 className="text-5xl font-extrabold tracking-tight">Something went wrong</h1>
      <p className="mt-4">Please try again. If it keeps happening, contact support.</p>
      <button className="btn mt-6" onClick={reset}>Try again</button>
    </main>
  );
}
