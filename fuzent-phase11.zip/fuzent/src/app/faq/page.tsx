export const metadata = { title: 'FAQ' };

const faq = [
  ['What is FUZENT?', 'A set of connected divisions: a digital store, MakePro, DigixBite, Creators and Freelance, with one account.'],
  ['How do I pay?', 'By UPI, straight into our business bank account. After you pay you enter the transaction ID, and we confirm it against the bank.'],
  ['Is a screenshot proof of payment?', 'No. We only confirm a payment when we see the money in our bank account.'],
  ['When do I get my download?', 'As soon as we confirm your payment. Your order page updates by itself.'],
  ['How are creators and freelancers approved?', 'Every profile is reviewed by our team before it goes live.'],
];

export default function Faq() {
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">FAQ</h1>
      <div className="mt-8 grid gap-3">{faq.map(([q, a]) => <details key={q} className="card"><summary className="cursor-pointer font-bold">{q}</summary><p className="mt-2">{a}</p></details>)}</div>
    </main>
  );
}
