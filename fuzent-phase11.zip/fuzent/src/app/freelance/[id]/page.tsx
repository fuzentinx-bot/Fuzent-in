import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';

export const metadata = { title: 'Freelancer' };

export default async function FreelancerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: f } = await supabase.from('freelancers').select('user_id, display_name, headline, skills, experience, portfolio, hourly_rate_paise, rating_avg').eq('user_id', id).eq('status', 'approved').maybeSingle();
  if (!f) notFound();
  const { data: reviews } = await supabase.from('reviews').select('id, rating, body').eq('freelancer_id', id).eq('is_published', true).order('created_at', { ascending: false }).limit(20);
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">{f.display_name}</h1>
      <p className="mt-2 text-xl font-bold">{f.headline}</p>
      <p className="mt-2">{f.skills?.join(' · ')}</p>
      {f.hourly_rate_paise ? <p className="mt-2 font-extrabold">{inr(f.hourly_rate_paise)} per hour</p> : null}
      <p className="mt-4 whitespace-pre-line">{f.experience}</p>
      {f.portfolio?.filter((u: string) => u.startsWith('https://')).map((u: string) => <a key={u} className="mt-2 block underline" rel="noopener noreferrer" target="_blank" href={u}>{u}</a>)}
      <h2 className="mb-3 mt-10 text-3xl font-extrabold">Reviews</h2>
      {!reviews?.length ? <p className="text-forest/70">No reviews yet.</p> : reviews.map((r) => <div key={r.id} className="card mb-3"><b>{r.rating} / 5</b><p>{r.body}</p></div>)}
    </main>
  );
}
