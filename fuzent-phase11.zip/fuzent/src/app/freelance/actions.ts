'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { bail, needUser, parseLinks } from '@/lib/forms';
import { admin } from '@/lib/supabase/admin';

export async function joinFreelancer(fd: FormData) {
  const { supabase, user } = await needUser('/freelance/join');
  const p = z.object({
    name: z.string().trim().min(2).max(60), headline: z.string().trim().min(3).max(100), skills: z.string().trim().min(2).max(200),
    experience: z.string().trim().max(800), portfolio: z.string(), rate: z.coerce.number().min(0).max(1000000).optional(),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/freelance/join', p.error.issues[0].message);
  const portfolio = parseLinks(p.data.portfolio);
  if (!portfolio) return bail('/freelance/join', 'Portfolio links must be https:// links, one per line.');
  const { error } = await supabase.from('freelancers').insert({
    user_id: user.id, display_name: p.data.name, headline: p.data.headline,
    skills: p.data.skills.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 10), experience: p.data.experience, portfolio,
    hourly_rate_paise: p.data.rate ? Math.round(p.data.rate * 100) : null,
  });
  if (error) return bail('/freelance/join', error.code === '23505' ? 'You already have a freelancer profile.' : 'Could not save. Try again.');
  revalidatePath('/freelance');
  redirect('/freelance/join?done=1');
}

export async function postProject(fd: FormData) {
  const { supabase, user } = await needUser('/projects/new');
  const p = z.object({
    title: z.string().trim().min(3).max(100), brief: z.string().trim().min(10).max(2000),
    budget: z.coerce.number().min(0).max(100000000), skills: z.string().max(200), due: z.string().optional(),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/projects/new', p.error.issues[0].message);
  const { data, error } = await supabase.from('projects').insert({
    client_id: user.id, division: 'freelance', title: p.data.title, brief: p.data.brief, budget_paise: Math.round(p.data.budget * 100),
    skills: p.data.skills.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 10), due_date: p.data.due || null, is_open: true,
  }).select('id').single();
  if (error || !data) return bail('/projects/new', 'Could not post. Try again.');
  redirect(`/projects/${data.id}`);
}

export async function applyProject(fd: FormData) {
  const p = z.object({ projectId: z.string().uuid(), pitch: z.string().trim().min(10, 'Tell the client a little more.').max(800), quote: z.coerce.number().min(0).max(100000000) }).safeParse(Object.fromEntries(fd));
  const back = `/projects/${String(fd.get('projectId'))}`;
  const { supabase, user } = await needUser(back);
  if (!p.success) return bail(back, p.error.issues[0].message);
  const { data: me } = await supabase.from('freelancers').select('status').eq('user_id', user.id).maybeSingle();
  if (me?.status !== 'approved') return bail(back, 'Only approved freelancers can apply.');
  const { data: proj } = await supabase.from('projects').select('id, client_id').eq('id', p.data.projectId).eq('is_open', true).maybeSingle();
  if (!proj || proj.client_id === user.id) return bail(back, 'You cannot apply to this project.');
  const { error } = await supabase.from('applications').insert({ applicant_id: user.id, project_id: proj.id, pitch: p.data.pitch, quote_paise: Math.round(p.data.quote * 100) });
  if (error) return bail(back, error.code === '23505' ? 'You already applied.' : 'Could not send. Try again.');
  redirect(`${back}?done=1`);
}

// Client picks a freelancer: ownership checked, then the server writes.
export async function acceptApplicant(fd: FormData) {
  const id = z.string().uuid().parse(fd.get('applicationId'));
  const { user } = await needUser('/dashboard');
  const db = admin();
  const { data: a } = await db.from('applications').select('id, applicant_id, status, project_id, projects(id, title, client_id, is_open)').eq('id', id).single();
  const proj: any = Array.isArray(a?.projects) ? a?.projects[0] : a?.projects;
  if (!a || !proj || proj.client_id !== user.id || !proj.is_open || a.status !== 'submitted') return bail('/dashboard', 'Not allowed.');
  await db.from('applications').update({ status: 'accepted' }).eq('id', a.id);
  await db.from('applications').update({ status: 'rejected' }).eq('project_id', proj.id).neq('id', a.id).eq('status', 'submitted');
  await db.from('projects').update({ assignee_id: a.applicant_id, is_open: false, status: 'in_progress' }).eq('id', proj.id);
  const { data: conv } = await db.from('conversations').insert({ project_id: proj.id, title: proj.title }).select('id').single();
  if (conv) await db.from('conversation_members').insert([{ conversation_id: conv.id, user_id: user.id }, { conversation_id: conv.id, user_id: a.applicant_id }]);
  await db.from('automation_events').insert({ event_type: 'project.assigned', payload: { project_id: proj.id } });
  redirect(`/projects/${proj.id}`);
}

export async function completeProject(fd: FormData) {
  const id = z.string().uuid().parse(fd.get('projectId'));
  const { user } = await needUser(`/projects/${id}`);
  await admin().from('projects').update({ status: 'completed' }).eq('id', id).eq('client_id', user.id).eq('status', 'in_progress');
  revalidatePath(`/projects/${id}`);
}

export async function reviewFreelancer(fd: FormData) {
  const p = z.object({ projectId: z.string().uuid(), rating: z.coerce.number().int().min(1).max(5), body: z.string().trim().max(600) }).safeParse(Object.fromEntries(fd));
  const back = `/projects/${String(fd.get('projectId'))}`;
  const { user } = await needUser(back);
  if (!p.success) return bail(back, 'Pick a rating from 1 to 5.');
  const db = admin();
  const { data: proj } = await db.from('projects').select('id, assignee_id').eq('id', p.data.projectId).eq('client_id', user.id).eq('status', 'completed').maybeSingle();
  if (!proj?.assignee_id) return bail(back, 'You can review after the project is completed.');
  const { error } = await db.from('reviews').insert({ author_id: user.id, freelancer_id: proj.assignee_id, project_id: proj.id, rating: p.data.rating, body: p.data.body, is_published: true });
  if (error) return bail(back, 'You already reviewed this project.');
  const { data: all } = await db.from('reviews').select('rating').eq('freelancer_id', proj.assignee_id);
  const avg = (all ?? []).reduce((s, r) => s + r.rating, 0) / Math.max(1, all?.length ?? 1);
  await db.from('freelancers').update({ rating_avg: Math.round(avg * 100) / 100 }).eq('user_id', proj.assignee_id);
  redirect(back);
}
