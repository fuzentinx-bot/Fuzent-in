import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Err, Ok, F, StatusTag } from '@/components/ui';
import { joinFreelancer } from '../actions';

export const metadata = { title: 'Join as freelancer' };

export default async function JoinFreelance({ searchParams }: { searchParams: Promise<{ error?: string; done?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/freelance/join');
  const { data: me } = await supabase.from('freelancers').select('display_name, status').eq('user_id', user.id).maybeSingle();
  return (
    <main className="mx-auto max-w-xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Freelancer profile</h1>
      <div className="mt-4"><Err e={sp.error} /><Ok t={sp.done ? 'Sent. We review every profile before it goes live.' : undefined} /></div>
      {me ? <p className="card">{me.display_name} <StatusTag s={me.status} /></p> : (
        <form action={joinFreelancer} className="card grid gap-4">
          <F label="Name" name="name" /><F label="Headline" name="headline" ph="Video editor for short-form content" />
          <F label="Skills, comma separated" name="skills" ph="Editing, Motion graphics" />
          <F label="Experience" name="experience" area req={false} />
          <F label="Portfolio links, one per line (https only)" name="portfolio" area req={false} />
          <F label="Hourly rate in rupees (optional)" name="rate" type="number" req={false} />
          <button className="btn">Apply</button>
        </form>
      )}
    </main>
  );
}
