import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';

export const metadata = { title: 'Freelance', description: 'Hire skilled freelancers or find paid projects.' };

export default async function Freelance() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const [{ data: people }, { data: projects }] = await Promise.all([
    supabase.from('freelancers').select('user_id, display_name, headline, skills, rating_avg').eq('status', 'approved').order('created_at', { ascending: false }).limit(60),
    user ? supabase.from('projects').select('id, title, brief, budget_paise, skills').eq('is_open', true).order('created_at', { ascending: false }).limit(30) : Promise.resolve({ data: [] as any[] }),
  ]);
  return (
    <main className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Freelance</h1>
      <div className="mt-6 flex flex-wrap gap-3"><Link href="/freelance/join" className="btn">Join as freelancer</Link><Link href="/projects/new" className="btn btn-ghost">Post a project</Link></div>
      <h2 className="mb-4 mt-12 text-3xl font-extrabold">Open projects</h2>
      {!user ? <p><Link className="underline" href="/login?next=/freelance">Log in</Link> to see open projects.</p>
        : !projects?.length ? <p className="text-forest/70">No open projects yet.</p> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p: any) => (
            <Link key={p.id} href={`/projects/${p.id}`} className="card block transition hover:-rotate-1">
              <h3 className="text-xl font-bold">{p.title}</h3><p className="mt-1 line-clamp-3 text-forest/70">{p.brief}</p>
              {p.budget_paise ? <p className="mt-3 font-extrabold">{inr(p.budget_paise)}</p> : null}
            </Link>
          ))}
        </div>
      )}
      <h2 className="mb-4 mt-12 text-3xl font-extrabold">Freelancers</h2>
      {!people?.length ? <p className="text-forest/70">No approved freelancers yet.</p> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {people.map((f) => (
            <Link key={f.user_id} href={`/freelance/${f.user_id}`} className="card block transition hover:-rotate-1">
              <h3 className="text-xl font-bold">{f.display_name}</h3><p className="font-bold">{f.headline}</p>
              <p className="mt-1 text-sm">{f.skills?.join(' · ')}</p>
              {Number(f.rating_avg) > 0 && <p className="mt-2 text-sm">Rating {Number(f.rating_avg).toFixed(1)} / 5</p>}
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
