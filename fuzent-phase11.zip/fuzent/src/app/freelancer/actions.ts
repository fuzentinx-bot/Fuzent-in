'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { bail, needUser } from '@/lib/forms';

export async function updateFreelancer(fd: FormData) {
  const { supabase, user } = await needUser('/freelancer/settings');
  const p = z.object({
    name: z.string().trim().min(2).max(60), headline: z.string().trim().max(100), skills: z.string().trim().min(2).max(200),
    experience: z.string().trim().max(800), rate: z.coerce.number().min(0).max(1000000).optional(),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bail('/freelancer/settings', p.error.issues[0].message);
  await supabase.from('freelancers').update({ // RLS: own row; a trigger blocks status changes
    display_name: p.data.name, headline: p.data.headline, experience: p.data.experience,
    skills: p.data.skills.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 10), hourly_rate_paise: p.data.rate ? Math.round(p.data.rate * 100) : null,
  }).eq('user_id', user.id);
  revalidatePath('/freelance');
  redirect('/freelancer/settings?saved=1');
}

export async function toggleAvailable() {
  const { supabase, user } = await needUser('/freelancer/settings');
  const { data } = await supabase.from('freelancers').select('available').eq('user_id', user.id).single();
  await supabase.from('freelancers').update({ available: !data?.available }).eq('user_id', user.id);
  revalidatePath('/freelancer', 'layout');
}
