import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Panel, Pill, one } from '@/components/dash/widgets';

export const metadata = { title: 'My applications' };

export default async function Applications() {
  const supabase = await createClient();
  const { data } = await supabase.from('applications').select('id, status, quote_paise, project_id, projects(title, status)').not('project_id', 'is', null).order('created_at', { ascending: false });
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">My applications</h1>
      <Panel>
        {!data?.length ? <p className="text-forest/70">No applications yet. <Link className="underline" href="/freelancer/work">Find work</Link></p> : (
          <div className="overflow-x-auto"><table className="w-full text-left"><thead><tr><th className="p-2">Project</th><th className="p-2">Quote</th><th className="p-2">Status</th></tr></thead>
            <tbody>{data.map((a) => { const p = one(a.projects as any); return (
              <tr key={a.id} className="border-t border-forest/15">
                <td className="p-2">{p ? <Link className="underline" href={`/projects/${a.project_id}`}>{p.title}</Link> : 'Project closed'}</td>
                <td className="p-2">{inr(a.quote_paise ?? 0)}</td>
                <td className="p-2"><Pill s={a.status === 'accepted' && p?.status === 'completed' ? 'completed' : a.status} /></td></tr>
            ); })}</tbody></table></div>
        )}
      </Panel>
    </>
  );
}
