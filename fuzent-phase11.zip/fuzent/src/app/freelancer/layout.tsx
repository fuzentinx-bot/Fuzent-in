import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { DashShell } from '@/components/dash/shell';

export default async function FreelancerLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/freelancer');
  const { count } = await supabase.from('applications').select('id', { count: 'exact', head: true }).eq('applicant_id', user.id).eq('status', 'submitted').not('project_id', 'is', null);
  return (
    <DashShell label="Freelancer hub" links={[['/dashboard', 'My account'], ['/brand', 'Brand hub']]} nav={[
      { href: '/freelancer', label: 'Overview', icon: '▦', exact: true },
      { href: '/freelancer/work', label: 'Find work', icon: '⌕' },
      { href: '/freelancer/applications', label: 'Applications', icon: '☰', badge: count ?? 0 },
      { href: '/freelancer/settings', label: 'Settings', icon: '⚙' },
    ]}>{children}</DashShell>
  );
}
