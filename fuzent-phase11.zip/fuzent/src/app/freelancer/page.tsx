import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Kpis, Panel, Donut, Feed, Pill, appParts, one } from '@/components/dash/widgets';

export const metadata = { title: 'Freelancer hub' };

export default async function FreelancerHome() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/freelancer');
  const { data: me } = await supabase.from('freelancers').select('display_name, status, available, rating_avg').eq('user_id', user.id).maybeSingle();
  if (!me) return (
    <div><h1 className="mt-2 text-4xl font-extrabold tracking-tight">Freelancer hub</h1>
      <p className="my-4">Create your freelancer profile first. We review it before it goes live.</p><Link className="btn" href="/freelance/join">Create profile</Link></div>
  );
  const [{ data: apps }, { data: feed }] = await Promise.all([
    supabase.from('applications').select('id, status, projects(status)').eq('applicant_id', user.id).not('project_id', 'is', null),
    supabase.from('notifications').select('title, body, created_at').order('created_at', { ascending: false }).limit(5),
  ]);
  const a = (apps ?? []).map((x) => ({ status: x.status as string, pstatus: one(x.projects as any)?.status as string | undefined }));
  const rating = Number(me.rating_avg);
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Hey, {me.display_name}</h1>
      <div className="mt-4"><Kpis items={[
        { tone: 1, label: 'Applications', value: a.length },
        { tone: 2, label: 'Active projects', value: a.filter((x) => x.status === 'accepted' && x.pstatus === 'in_progress').length },
        { tone: 3, label: 'Completed', value: a.filter((x) => x.status === 'accepted' && x.pstatus === 'completed').length },
        { tone: 4, label: 'Rating', value: rating > 0 ? rating.toFixed(1) : '—' },
      ]} /></div>
      <div className="cg">
        <Panel title="Applications by status"><Donut label="Applications by status" parts={appParts(a)} /></Panel>
        <Panel title="Profile"><p className="mb-2"><Pill s={me.status} /> <Pill s={me.available ? 'open' : 'closed'} /> {me.available ? 'Available' : 'Busy'}</p>
          {me.status !== 'approved' && <p className="text-forest/70">Waiting for approval. You can apply to projects once it is approved.</p>}</Panel>
      </div>
      <Feed items={feed ?? []} />
    </>
  );
}
