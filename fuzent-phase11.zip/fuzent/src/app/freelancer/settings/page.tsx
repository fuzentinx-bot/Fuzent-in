import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Err, Ok, F } from '@/components/ui';
import { Panel, Pill } from '@/components/dash/widgets';
import { PrefsForm } from '@/components/dash/prefs-form';
import { updateFreelancer, toggleAvailable } from '../actions';

export const metadata = { title: 'Freelancer settings' };

export default async function FreelancerSettings({ searchParams }: { searchParams: Promise<{ error?: string; saved?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login?next=/freelancer/settings');
  const { data: f } = await supabase.from('freelancers').select('display_name, headline, skills, experience, hourly_rate_paise, status, available').eq('user_id', user.id).maybeSingle();
  if (!f) return <p className="mt-4">Create your profile first. <Link className="underline" href="/freelance/join">Create profile</Link></p>;
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Settings</h1>
      <div className="mt-4"><Err e={sp.error} /><Ok t={sp.saved ? 'Saved.' : undefined} /></div>
      <Panel title="Profile">
        <p className="mb-3">Status: <Pill s={f.status} /></p>
        <form action={updateFreelancer} className="grid max-w-lg gap-4">
          <F label="Name" name="name" def={f.display_name ?? ''} /><F label="Headline" name="headline" def={f.headline ?? ''} req={false} />
          <F label="Skills, comma separated" name="skills" def={(f.skills ?? []).join(', ')} />
          <F label="Experience" name="experience" area def={f.experience ?? ''} req={false} />
          <F label="Hourly rate in rupees" name="rate" type="number" def={f.hourly_rate_paise ? String(f.hourly_rate_paise / 100) : ''} req={false} />
          <button className="btn w-fit">Save profile</button>
        </form>
        <form action={toggleAvailable} className="mt-5 flex items-center gap-3"><span className="font-bold">Availability</span>
          <button className="btn btn-ghost min-h-[44px] px-4">{f.available ? 'Available for work (tap to set Busy)' : 'Busy (tap to set Available)'}</button></form>
      </Panel>
      <PrefsForm back="/freelancer/settings" />
    </>
  );
}
