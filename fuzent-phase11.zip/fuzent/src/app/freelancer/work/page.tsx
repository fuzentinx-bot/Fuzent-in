import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';

export const metadata = { title: 'Find work' };

export default async function Work({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = '' } = await searchParams;
  const supabase = await createClient();
  let query = supabase.from('projects').select('id, title, brief, budget_paise, skills').eq('is_open', true).order('created_at', { ascending: false }).limit(40);
  if (q.trim()) query = query.ilike('title', `%${q.trim().replace(/[%_]/g, '')}%`);
  const { data } = await query;
  return (
    <>
      <h1 className="mt-2 text-4xl font-extrabold tracking-tight">Find work</h1>
      <form role="search" className="mt-4 flex max-w-md gap-2"><label className="sr-only" htmlFor="q">Search projects</label>
        <input id="q" name="q" defaultValue={q} placeholder="Search projects" className="field" /><button className="btn">Search</button></form>
      {!data?.length ? <p className="mt-6 text-forest/70">No open projects right now.</p> : (
        <div className="gr mt-6 grid gap-5 sm:grid-cols-2">
          {data.map((p) => (
            <Link key={p.id} href={`/projects/${p.id}`} className="card block transition hover:-rotate-1">
              <h2 className="text-xl font-bold">{p.title}</h2><p className="mt-1 line-clamp-3 text-forest/70">{p.brief}</p>
              {p.budget_paise ? <p className="mt-3 font-extrabold">{inr(p.budget_paise)}</p> : null}
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
