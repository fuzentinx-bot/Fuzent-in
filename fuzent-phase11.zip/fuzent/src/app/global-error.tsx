'use client';

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <html lang="en"><body style={{ fontFamily: 'system-ui', padding: '4rem 1.5rem', background: '#F3F0E4', color: '#0A3F2F' }}>
      <h1>Something went wrong</h1><p>Please try again in a moment.</p>
      <button onClick={reset}>Try again</button>
    </body></html>
  );
}
