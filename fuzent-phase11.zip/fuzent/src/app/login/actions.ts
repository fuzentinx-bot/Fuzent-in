'use server';

import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { safeRedirectPath } from '@/lib/safe-redirect';
import { hitLimit } from '@/lib/mem-limit';

export type FormState = { error?: string; message?: string };

const creds = z.object({
  email: z.string().trim().email('Enter a valid email.'),
  password: z.string().min(8, 'Use at least 8 characters.').max(72),
});

async function origin() {
  const h = await headers();
  return process.env.NEXT_PUBLIC_SITE_URL ?? `https://${h.get('host')}`;
}

// Only allow same-site relative paths after login (prevents open redirects).
const safeNext = (v: FormDataEntryValue | null) => safeRedirectPath(v);

export async function signIn(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = creds.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) return { error: 'Email or password is wrong. Check both and try again.' };
  redirect(safeNext(formData.get('next')));
}

export async function signUp(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = creds.extend({ name: z.string().trim().min(2, 'Enter your name.').max(80) })
    .safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const { name, email, password } = parsed.data;
  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email, password,
    options: { data: { full_name: name }, emailRedirectTo: `${await origin()}/auth/callback` },
  });
  if (error) return { error: 'Could not create the account. Try a different email or a stronger password.' };
  return { message: 'Check your email and click the verification link to finish.' };
}

export async function signInWithGoogle() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: `${await origin()}/auth/callback` },
  });
  if (error || !data.url) redirect('/login?error=google');
  redirect(data.url);
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect('/');
}

// Same answer whether or not the email has an account, so nobody can use this to find who is registered.
export async function requestReset(_: FormState, formData: FormData): Promise<FormState> {
  const email = z.string().trim().toLowerCase().email().safeParse(formData.get('email'));
  const same: FormState = { message: 'If that email has an account, a reset link is on its way.' };
  if (!email.success) return { error: 'Enter a valid email.' };
  if (hitLimit(`reset:${email.data}`, 3, 3_600_000)) return same;
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email.data, { redirectTo: `${await origin()}/auth/callback?next=/reset-password` });
  return same;
}

export async function setNewPassword(_: FormState, formData: FormData): Promise<FormState> {
  const p = z.object({ password: z.string().min(8, 'Use at least 8 characters.').max(72), confirm: z.string() }).safeParse(Object.fromEntries(formData));
  if (!p.success) return { error: p.error.issues[0].message };
  if (p.data.password !== p.data.confirm) return { error: 'The two passwords do not match.' };
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'This reset link has expired. Please ask for a new one.' };
  const { error } = await supabase.auth.updateUser({ password: p.data.password });
  if (error) return { error: 'Could not change the password. Try a stronger one.' };
  await supabase.auth.signOut({ scope: 'others' }); // other devices must log in again
  redirect('/dashboard');
}
