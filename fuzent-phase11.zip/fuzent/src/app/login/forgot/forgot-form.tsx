'use client';

import { useActionState } from 'react';
import { requestReset, type FormState } from '../actions';

export function ForgotForm() {
  const [state, action, pending] = useActionState<FormState, FormData>(requestReset, {});
  return (
    <form action={action} className="card grid gap-4">
      <label className="grid gap-1 text-sm font-bold">Email<input className="field" name="email" type="email" autoComplete="email" required /></label>
      {state.error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{state.error}</p>}
      {state.message && <p role="status" className="rounded-xl bg-lime p-3 text-sm font-bold">{state.message}</p>}
      <button className="btn" disabled={pending}>{pending ? 'Please wait' : 'Send reset link'}</button>
    </form>
  );
}
