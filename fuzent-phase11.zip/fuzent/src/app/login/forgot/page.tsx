import { ForgotForm } from './forgot-form';

export const metadata = { title: 'Reset password' };

export default function Forgot() {
  return (
    <main className="mx-auto max-w-md px-6 py-14">
      <h1 className="mb-6 text-5xl font-extrabold tracking-tight">Reset password</h1>
      <ForgotForm />
    </main>
  );
}
