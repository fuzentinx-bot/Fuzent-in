'use client';

import { useActionState } from 'react';
import { signIn, signUp, signInWithGoogle, type FormState } from './actions';

export function LoginForm({ mode, next }: { mode: 'login' | 'signup'; next: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(mode === 'login' ? signIn : signUp, {});
  return (
    <div className="grid gap-4">
      <form action={action} className="card grid gap-4">
        <input type="hidden" name="next" value={next} />
        {mode === 'signup' && (
          <label className="grid gap-1 text-sm font-bold">Name<input className="field" name="name" autoComplete="name" required /></label>
        )}
        <label className="grid gap-1 text-sm font-bold">Email<input className="field" name="email" type="email" autoComplete="email" required /></label>
        <label className="grid gap-1 text-sm font-bold">Password<input className="field" name="password" type="password" minLength={8} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required /></label>
        {state.error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{state.error}</p>}
        {state.message && <p role="status" className="rounded-xl bg-lime p-3 text-sm font-bold">{state.message}</p>}
        <button className="btn" disabled={pending}>{pending ? 'Please wait' : mode === 'login' ? 'Log in' : 'Create account'}</button>
      </form>
      <form action={signInWithGoogle}><button className="btn btn-ghost w-full">Continue with Google</button></form>
    </div>
  );
}
