import Link from 'next/link';
import { LoginForm } from './login-form';
import { safeRedirectPath } from '@/lib/safe-redirect';

export const metadata = { title: 'Log in' };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ mode?: string; next?: string; error?: string }> }) {
  const sp = await searchParams;
  const mode = sp.mode === 'signup' ? 'signup' : 'login';
  const next = safeRedirectPath(sp.next);
  return (
    <main className="mx-auto max-w-md px-5 py-14">
      <h1 className="mb-6 text-5xl font-extrabold tracking-tight">{mode === 'login' ? 'Log in' : 'Create account'}</h1>
      {sp.error && <p role="alert" className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">That did not work. Please try again.</p>}
      <LoginForm mode={mode} next={next} />
      <p className="mt-5 text-forest/70">
        {mode === 'login'
          ? <>New here? <Link className="underline" href="/login?mode=signup">Create an account</Link></>
          : <>Already have an account? <Link className="underline" href="/login">Log in</Link></>}
      </p>
      <p className="mt-2 text-forest/70"><Link className="underline" href="/login/forgot">Forgot your password?</Link></p>
    </main>
  );
}
