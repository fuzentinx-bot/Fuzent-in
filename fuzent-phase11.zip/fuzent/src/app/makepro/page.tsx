import { ServicePage } from '@/components/service-page';

export const metadata = { title: 'MakePro', description: 'Marketing and growth for brands that want to be seen: branding, campaigns, lead generation and more.' };

export default async function Page({ searchParams }: { searchParams: Promise<{ error?: string; done?: string }> }) {
  const sp = await searchParams;
  return <ServicePage division="makepro" title="MakePro" intro="Marketing and growth for brands that want to be seen: branding, campaigns, lead generation and more." error={sp.error} done={sp.done} />;
}
