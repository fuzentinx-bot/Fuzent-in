import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="mx-auto max-w-xl px-6 py-20">
      <h1 className="text-5xl font-extrabold tracking-tight">Page not found</h1>
      <p className="mt-4">That page does not exist.</p>
      <Link className="btn mt-6" href="/">Go home</Link>
    </main>
  );
}
