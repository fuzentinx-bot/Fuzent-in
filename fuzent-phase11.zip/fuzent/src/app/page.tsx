import Link from 'next/link';

const divisions = [
  ['/store', 'Fuzent Digital', 'Digital products and resources'],
  ['/makepro', 'MakePro', 'Growth and marketing agency'],
  ['/digixbite', 'DigixBite', 'Websites, CRM and automation'],
  ['/creators', 'Fuzent Creators', 'Brands meet creators'],
  ['/freelance', 'Fuzent Freelance', 'Hire or get hired'],
] as const;

export default function Home() {
  return (
    <main>
      <section className="bg-forest text-cream">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <h1 className="text-[clamp(42px,8vw,92px)] font-extrabold leading-[.95] tracking-tighter">
            Build <em className="inline-block -rotate-2 rounded-lg bg-lime px-2 not-italic text-forest">beyond</em> limits.
          </h1>
          <p className="mt-5 max-w-xl text-lg opacity-90">
            Digital products, growth, automation, creators and freelancers: your whole business account in one place.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/solutions" className="btn">Explore solutions</Link>
            <Link href="/login?mode=signup" className="btn btn-ghost border-cream text-cream">Start your journey</Link>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-14">
        <h2 className="mb-6 text-4xl font-extrabold tracking-tight">Pick your lane</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {divisions.map(([href, title, text]) => (
            <Link key={href} href={href} className="card block transition hover:-rotate-1">
              <h3 className="text-xl font-bold">{title}</h3>
              <p className="mt-1 text-forest/70">{text}</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
