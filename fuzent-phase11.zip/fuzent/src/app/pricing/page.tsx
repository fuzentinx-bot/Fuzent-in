import Link from 'next/link';

export const metadata = { title: 'Pricing' };

export default function Pricing() {
  return (
    <main className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Pricing</h1>
      <p className="mt-3 text-lg">Pricing depends on what you need. Digital products have fixed prices; services are quoted.</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <div className="card"><h2 className="text-xl font-bold">Digital products</h2><p className="text-forest/70">Fixed price on each product page.</p><Link className="btn mt-3" href="/store">Shop</Link></div>
        <div className="card"><h2 className="text-xl font-bold">Services</h2><p className="text-forest/70">MakePro and DigixBite quote each project.</p><Link className="btn mt-3" href="/contact">Get a quote</Link></div>
        <div className="card"><h2 className="text-xl font-bold">Marketplace</h2><p className="text-forest/70">[YOUR COMMISSION TERMS]</p></div>
      </div>
    </main>
  );
}
