import { LegalPage } from '@/components/legal-page';

export const metadata = { title: 'Privacy Policy' };

export default function Page() {
  return <LegalPage title="Privacy Policy" sections={['What we collect', 'How we use it', 'Cookies', 'Your rights', 'Contact']} />;
}
