import Link from 'next/link';
import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { inr } from '@/lib/money';
import { Err, Ok, F, StatusTag } from '@/components/ui';
import { applyProject, acceptApplicant, completeProject, reviewFreelancer } from '@/app/freelance/actions';

export const metadata = { title: 'Project' };

export default async function ProjectPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ error?: string; done?: string }> }) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return <main className="mx-auto max-w-xl px-5 py-12"><Link className="btn" href={`/login?next=/projects/${id}`}>Log in to view this project</Link></main>;
  const { data: p } = await supabase.from('projects').select('id, title, brief, budget_paise, skills, status, is_open, client_id, assignee_id, due_date').eq('id', id).maybeSingle();
  if (!p) notFound();
  const isClient = p.client_id === user.id;
  const [{ data: apps }, { data: conv }, { data: review }, { data: me }] = await Promise.all([
    isClient ? supabase.from('applications').select('id, applicant_id, pitch, quote_paise, status').eq('project_id', id) : Promise.resolve({ data: [] as any[] }),
    supabase.from('conversations').select('id').eq('project_id', id).maybeSingle(),
    supabase.from('reviews').select('id').eq('project_id', id).maybeSingle(),
    supabase.from('freelancers').select('status').eq('user_id', user.id).maybeSingle(),
  ]);
  const ids = (apps ?? []).map((a: any) => a.applicant_id);
  const { data: fs } = ids.length ? await supabase.from('freelancers').select('user_id, display_name').in('user_id', ids) : { data: [] as any[] };
  const nm = (u: string) => fs?.find((f: any) => f.user_id === u)?.display_name ?? 'Freelancer';

  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">{p.title}</h1>
      <p className="mt-3"><StatusTag s={p.is_open ? 'open' : p.status} /> {p.budget_paise ? <b className="ml-2">{inr(p.budget_paise)}</b> : null}</p>
      <p className="mt-4 whitespace-pre-line text-lg">{p.brief}</p>
      {p.skills?.length > 0 && <p className="mt-2 text-sm">Skills: {p.skills.join(' · ')}</p>}
      <div className="mt-6"><Err e={sp.error} /><Ok t={sp.done ? 'Application sent.' : undefined} /></div>
      {conv && <Link className="btn mb-6" href={`/messages/${conv.id}`}>Open messages</Link>}

      {!isClient && p.is_open && (me?.status === 'approved' ? (
        <form action={applyProject} className="card grid gap-4">
          <input type="hidden" name="projectId" value={p.id} />
          <F label="Your pitch" name="pitch" area /><F label="Your quote in rupees" name="quote" type="number" />
          <button className="btn">Apply</button>
        </form>
      ) : <p className="card">Only approved freelancers can apply. <Link className="underline" href="/freelance/join">Your freelancer profile</Link></p>)}

      {isClient && (
        <>
          {p.status === 'in_progress' && <form action={completeProject}><input type="hidden" name="projectId" value={p.id} /><button className="btn mb-6">Mark as completed</button></form>}
          {p.status === 'completed' && !review && (
            <form action={reviewFreelancer} className="card mb-6 grid gap-3">
              <input type="hidden" name="projectId" value={p.id} /><h2 className="text-xl font-bold">Review the freelancer</h2>
              <label className="grid gap-1 text-sm font-bold">Rating<select name="rating" className="field">{[5, 4, 3, 2, 1].map((n) => <option key={n}>{n}</option>)}</select></label>
              <F label="Comment" name="body" area req={false} /><button className="btn">Submit review</button>
            </form>
          )}
          <h2 className="mb-3 text-2xl font-extrabold">Applicants</h2>
          {!apps?.length ? <p className="text-forest/70">No applicants yet.</p> : apps.map((a: any) => (
            <div key={a.id} className="card mb-3">
              <p><Link className="font-bold underline" href={`/freelance/${a.applicant_id}`}>{nm(a.applicant_id)}</Link> · quote {inr(a.quote_paise ?? 0)} · <StatusTag s={a.status} /></p>
              <p className="whitespace-pre-line">{a.pitch}</p>
              {p.is_open && a.status === 'submitted' && <form action={acceptApplicant} className="mt-3"><input type="hidden" name="applicationId" value={a.id} /><button className="btn min-h-[44px] px-4">Accept</button></form>}
            </div>
          ))}
        </>
      )}
    </main>
  );
}
