import { Err, F } from '@/components/ui';
import { postProject } from '@/app/freelance/actions';

export const metadata = { title: 'Post a project' };

export default async function NewProject({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const sp = await searchParams;
  return (
    <main className="mx-auto max-w-xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Post a project</h1>
      <div className="mt-4"><Err e={sp.error} /></div>
      <form action={postProject} className="card grid gap-4">
        <F label="Title" name="title" /><F label="What do you need?" name="brief" area />
        <F label="Budget in rupees" name="budget" type="number" ph="10000" />
        <F label="Skills wanted, comma separated" name="skills" req={false} />
        <F label="Deadline (optional)" name="due" type="date" req={false} />
        <button className="btn">Post project</button>
      </form>
    </main>
  );
}
