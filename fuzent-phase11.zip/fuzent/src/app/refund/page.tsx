import { LegalPage } from '@/components/legal-page';

export const metadata = { title: 'Refund Policy' };

export default function Page() {
  return <LegalPage title="Refund Policy" sections={['Digital products', 'Services', 'How to ask for a refund', 'Timelines']} />;
}
