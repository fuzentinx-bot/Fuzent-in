import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { ResetForm } from './reset-form';

export const metadata = { title: 'Choose a new password' };

export default async function ResetPassword() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser(); // set by the emailed link
  return (
    <main className="mx-auto max-w-md px-6 py-14">
      <h1 className="mb-6 text-5xl font-extrabold tracking-tight">New password</h1>
      {user ? <ResetForm /> : <p>This link has expired. <Link className="underline" href="/login/forgot">Ask for a new one</Link>.</p>}
    </main>
  );
}
