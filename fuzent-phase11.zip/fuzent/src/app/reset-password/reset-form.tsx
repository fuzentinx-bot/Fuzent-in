'use client';

import { useActionState } from 'react';
import { setNewPassword, type FormState } from '@/app/login/actions';

export function ResetForm() {
  const [state, action, pending] = useActionState<FormState, FormData>(setNewPassword, {});
  return (
    <form action={action} className="card grid gap-4">
      <label className="grid gap-1 text-sm font-bold">New password<input className="field" name="password" type="password" minLength={8} autoComplete="new-password" required /></label>
      <label className="grid gap-1 text-sm font-bold">Repeat it<input className="field" name="confirm" type="password" minLength={8} autoComplete="new-password" required /></label>
      {state.error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{state.error}</p>}
      <button className="btn" disabled={pending}>{pending ? 'Please wait' : 'Save new password'}</button>
    </form>
  );
}
