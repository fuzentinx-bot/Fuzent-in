import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const site = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://fuzent.in';
  return {
    rules: { userAgent: '*', allow: '/', disallow: ['/admin', '/api', '/dashboard', '/cart', '/checkout', '/orders', '/invoices', '/messages', '/notifications', '/support', '/brand', '/projects', '/login'] },
    sitemap: `${site}/sitemap.xml`,
  };
}
