'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { after } from 'next/server';
import { bail, needUser } from '@/lib/forms';
import { admin } from '@/lib/supabase/admin';
import { processEvents } from '@/lib/automation';

export async function requestService(fd: FormData) {
  const p = z.object({
    division: z.enum(['makepro', 'digixbite']), service: z.string().trim().min(2).max(100),
    brief: z.string().trim().min(10).max(2000), budget: z.coerce.number().min(0).max(100000000).optional(),
  }).safeParse(Object.fromEntries(fd));
  const division = String(fd.get('division')) === 'digixbite' ? 'digixbite' : 'makepro';
  const { supabase, user } = await needUser(`/${division}`);
  if (!p.success) return bail(`/${division}`, p.error.issues[0].message);
  const { data, error } = await supabase.from('projects').insert({ // RLS: client_ins
    client_id: user.id, division: p.data.division, title: p.data.service, brief: p.data.brief,
    budget_paise: p.data.budget ? Math.round(p.data.budget * 100) : null,
  }).select('id').single();
  if (error || !data) return bail(`/${division}`, 'Could not send. Try again.');
  await admin().from('automation_events').insert({ event_type: 'project.requested', payload: { project_id: data.id } });
  after(() => processEvents());
  redirect(`/${division}?done=1`);
}
