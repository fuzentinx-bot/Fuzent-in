import { LegalPage } from '@/components/legal-page';

export const metadata = { title: 'Shipping and Delivery Policy' };

export default function Page() {
  return <LegalPage title="Shipping and Delivery Policy" sections={['Digital delivery', 'Service delivery', 'Delays']} />;
}
