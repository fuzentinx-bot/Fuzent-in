import type { MetadataRoute } from 'next';
import { createClient } from '@supabase/supabase-js';

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const site = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://fuzent.in';
  const db = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { auth: { persistSession: false } });
  const [{ data: products }, { data: creators }, { data: freelancers }] = await Promise.all([
    db.from('products').select('slug').eq('is_active', true),
    db.from('creators').select('handle').eq('status', 'approved'),
    db.from('freelancers').select('user_id').eq('status', 'approved'),
  ]);
  const fixed = ['', '/solutions', '/store', '/makepro', '/digixbite', '/creators', '/freelance', '/pricing', '/about', '/faq', '/contact', '/privacy', '/terms', '/refund', '/shipping'];
  return [
    ...fixed.map((p) => ({ url: `${site}${p}` })),
    ...(products ?? []).map((p) => ({ url: `${site}/store/${p.slug}` })),
    ...(creators ?? []).map((c) => ({ url: `${site}/creators/${c.handle}` })),
    ...(freelancers ?? []).map((f) => ({ url: `${site}/freelance/${f.user_id}` })),
  ];
}
