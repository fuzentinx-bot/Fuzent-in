import Link from 'next/link';

export const metadata = { title: 'Solutions' };

const items = [['/store', 'Digital Store', 'Templates, sheets and kits you can use today.'], ['/makepro', 'MakePro', 'Marketing and growth services.'], ['/digixbite', 'DigixBite', 'Websites, CRM and automation.'], ['/creators', 'Creators', 'Brands and creators, matched.'], ['/freelance', 'Freelance', 'Hire talent or find projects.']];

export default function Solutions() {
  return (
    <main className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Solutions</h1>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([href, t, d]) => <Link key={href} href={href} className="card block transition hover:-rotate-1"><h2 className="text-xl font-bold">{t}</h2><p className="mt-1 text-forest/70">{d}</p></Link>)}
      </div>
    </main>
  );
}
