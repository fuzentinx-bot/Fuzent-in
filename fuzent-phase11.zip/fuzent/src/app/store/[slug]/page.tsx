import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getProduct } from '@/lib/public-data';
import { inr } from '@/lib/money';
import { BuyButton } from '../buy-button';
import { AddToCart } from '../add-to-cart';

type Props = { params: Promise<{ slug: string }> };

const load = (slug: string) => getProduct(slug);

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await load((await params).slug);
  return p ? { title: p.title, description: p.description?.slice(0, 150) } : {};
}

export default async function Product({ params }: Props) {
  const slug = (await params).slug;
  const p = await load(slug);
  if (!p) notFound();
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">{p.title}</h1>
      <p className="mt-4 whitespace-pre-line text-lg text-forest/80">{p.description}</p>
      <p className="my-6 text-4xl font-extrabold">{inr(p.price_paise)}</p>
      <div className="flex flex-wrap gap-3"><AddToCart productId={p.id} next={`/store/${p.slug}`} /><BuyButton productId={p.id} next={`/store/${p.slug}`} /></div>
    </main>
  );
}
