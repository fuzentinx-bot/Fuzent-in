'use server';

import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { admin } from '@/lib/supabase/admin';
import { tooManyOrders } from '@/lib/order-limits';

export type CheckoutResult = { error: string; code?: 'auth' } | { orderId: string };

// Price always comes from the database, never from the browser.
export async function startCheckout(productId: string): Promise<CheckoutResult> {
  if (!z.string().uuid().safeParse(productId).success) return { error: 'Invalid product.' };
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Log in to buy.', code: 'auth' };

  const { data: product } = await supabase.from('products').select('id, title, price_paise').eq('id', productId).eq('is_active', true).single();
  if (!product) return { error: 'This product is not available.' };

  if (product.price_paise < 100) return { error: 'This product cannot be bought online.' };

  const db = admin();
  if (await tooManyOrders(db, user.id)) return { error: 'Too many orders started. Please wait a little.' };
  // A double click or a returning customer reuses the unpaid order instead of creating another.
  const { data: existing } = await db.from('orders').select('id, order_items!inner(product_id)').eq('customer_id', user.id)
    .eq('payment_status', 'created').eq('total_paise', product.price_paise).eq('order_items.product_id', product.id)
    .gte('created_at', new Date(Date.now() - 30 * 60_000).toISOString()).limit(1);
  if (existing?.length) return { orderId: existing[0].id };
  const { data: order, error } = await db.from('orders').insert({
    customer_id: user.id, division: 'digital', subtotal_paise: product.price_paise, total_paise: product.price_paise,
  }).select('id').single();
  if (error || !order) return { error: 'Could not start checkout. Try again.' };

  await db.from('order_items').insert({ order_id: order.id, product_id: product.id, title_snapshot: product.title, unit_price_paise: product.price_paise });
  await db.from('payments').insert({ order_id: order.id, gateway: 'upi_direct', amount_paise: product.price_paise, status: 'created' });
  return { orderId: order.id };
}
