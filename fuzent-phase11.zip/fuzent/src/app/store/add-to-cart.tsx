'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { addToCart } from '@/app/cart/actions';

export function AddToCart({ productId, next }: { productId: string; next: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <button className="btn btn-ghost" disabled={busy} onClick={async () => {
      setBusy(true);
      const r = await addToCart(productId);
      if (r.code === 'auth') return router.push(`/login?next=${encodeURIComponent(next)}`);
      router.push('/cart');
    }}>{busy ? 'Adding' : 'Add to cart'}</button>
  );
}
