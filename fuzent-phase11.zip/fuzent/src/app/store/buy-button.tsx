'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { startCheckout } from './actions';

export function BuyButton({ productId, next }: { productId: string; next: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function buy() {
    setBusy(true); setErr('');
    const res = await startCheckout(productId);
    if ('error' in res) {
      if (res.code === 'auth') return router.push(`/login?next=${encodeURIComponent(next)}`);
      setErr(res.error); setBusy(false); return;
    }
    router.push(`/checkout/${res.orderId}`);
  }

  return (
    <>
      <button className="btn" onClick={buy} disabled={busy}>{busy ? 'Please wait' : 'Buy now'}</button>
      {err && <p role="alert" className="mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-800">{err}</p>}
    </>
  );
}
