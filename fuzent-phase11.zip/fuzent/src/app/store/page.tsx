import Link from 'next/link';
import { getCategories, getProducts } from '@/lib/public-data';
import { inr } from '@/lib/money';

export const metadata = { title: 'Digital Store', description: 'Practical digital products and business resources.' };

export default async function Store({ searchParams }: { searchParams: Promise<{ q?: string; cat?: string }> }) {
  const { q = '', cat = '' } = await searchParams;
  const [cats, products] = await Promise.all([getCategories(), getProducts(q.trim().slice(0, 60), cat.slice(0, 40))]);
  return (
    <main className="mx-auto max-w-6xl px-6 py-12 lg:px-12">
      <h1 className="text-5xl font-extrabold tracking-tight">Digital store</h1>
      <form className="mt-6 flex max-w-lg gap-2" role="search">
        <label className="sr-only" htmlFor="q">Search products</label>
        <input id="q" name="q" defaultValue={q} placeholder="Search products" className="field" />
        {cat && <input type="hidden" name="cat" value={cat} />}
        <button className="btn">Search</button>
      </form>
      <div className="my-5 flex flex-wrap gap-2">
        {[{ slug: '', name: 'All' }, ...cats].map((c) => (
          <Link key={c.slug} href={`/store?${new URLSearchParams({ ...(q && { q }), ...(c.slug && { cat: c.slug }) })}`}
            className={`rounded-full border-2 border-forest px-4 py-2 text-sm font-bold ${cat === c.slug ? 'bg-forest text-lime' : 'bg-white'}`}>{c.name}</Link>
        ))}
      </div>
      {products.length === 0 ? (
        <p className="text-forest/70">No products yet.</p>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p: any) => (
            <Link key={p.id} href={`/store/${p.slug}`} className="card block transition hover:-rotate-1">
              <h2 className="text-xl font-bold">{p.title}</h2>
              <p className="mt-3 text-2xl font-extrabold">{inr(p.price_paise)}</p>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
