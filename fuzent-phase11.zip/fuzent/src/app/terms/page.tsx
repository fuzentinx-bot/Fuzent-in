import { LegalPage } from '@/components/legal-page';

export const metadata = { title: 'Terms and Conditions' };

export default function Page() {
  return <LegalPage title="Terms and Conditions" sections={['Using FUZENT', 'Accounts', 'Payments and orders', 'Content and conduct', 'Liability']} />;
}
