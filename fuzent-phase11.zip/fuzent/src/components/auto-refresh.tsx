'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

// While payment is unconfirmed, re-read the order from the server every 3s (max ~30s).
export function AutoRefresh() {
  const router = useRouter();
  useEffect(() => {
    let n = 0;
    const t = setInterval(() => { router.refresh(); if (++n >= 10) clearInterval(t); }, 3000);
    return () => clearInterval(t);
  }, [router]);
  return null;
}
