'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export type NavItem = { href: string; label: string; icon: string; badge?: number; exact?: boolean };

export function DashNav({ items, label }: { items: NavItem[]; label: string }) {
  const path = usePathname();
  return (
    <nav className="dside" aria-label={label}>
      <div className="dlogo">FUZ<i>ENT</i></div>
      {items.map((i) => {
        const on = i.exact ? path === i.href : path === i.href || path.startsWith(i.href + '/');
        return (
          <Link key={i.href} href={i.href} className="dt" aria-current={on ? 'page' : undefined}>
            <span className="ic" aria-hidden="true">{i.icon}</span>{i.label}{i.badge ? <b>{i.badge}</b> : null}
          </Link>
        );
      })}
    </nav>
  );
}
