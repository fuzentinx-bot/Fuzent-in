import { createClient } from '@/lib/supabase/server';
import { savePrefs } from '@/lib/prefs-actions';
import { Panel } from './widgets';

export async function PrefsForm({ back }: { back: string }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data } = await supabase.from('profiles').select('prefs').eq('id', user!.id).single();
  const p = (data?.prefs ?? {}) as { email?: boolean; inapp?: boolean };
  return (
    <Panel title="Notifications">
      <form action={savePrefs} className="grid gap-3">
        <input type="hidden" name="back" value={back} />
        <label className="flex items-center gap-3 font-bold"><input type="checkbox" name="email" defaultChecked={p.email !== false} className="size-5" /> Email me about new activity</label>
        <label className="flex items-center gap-3 font-bold"><input type="checkbox" name="inapp" defaultChecked={p.inapp !== false} className="size-5" /> Show alerts in the app</label>
        <button className="btn w-fit">Save</button>
      </form>
    </Panel>
  );
}
