import Link from 'next/link';
import { DashNav, type NavItem } from './dash-nav';

export function DashShell({ label, nav, links = [], children }: { label: string; nav: NavItem[]; links?: [string, string][]; children: React.ReactNode }) {
  return (
    <div className="dsh">
      <DashNav items={nav} label={`${label} sections`} />
      <div className="dmain">
        <div className="dtop">
          <p className="text-lg font-extrabold">{label}</p>
          <div className="flex flex-wrap gap-2">
            {links.map(([href, text]) => <Link key={href} href={href} className="btn btn-ghost min-h-[44px] px-4 text-sm">{text}</Link>)}
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}
