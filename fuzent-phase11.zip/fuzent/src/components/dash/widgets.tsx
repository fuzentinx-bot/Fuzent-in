import type { ReactNode } from 'react';
import Link from 'next/link';
import { inr } from '@/lib/money';

export function Kpis({ items }: { items: { tone: 1 | 2 | 3 | 4; label: string; value: ReactNode }[] }) {
  return <div className="kp">{items.map((i) => <div key={i.label} className={`kc k${i.tone}`}><small>{i.label}</small><b>{i.value}</b></div>)}</div>;
}
export const Panel = ({ title, children }: { title?: string; children: ReactNode }) =>
  <section className="pnl">{title && <h2>{title}</h2>}{children}</section>;

const GOOD = ['paid', 'approved', 'accepted', 'completed', 'open', 'confirmed', 'resolved'];
const BAD = ['rejected', 'failed', 'refunded', 'closed', 'cancelled'];
export function Pill({ s }: { s: string }) {
  const k = s.toLowerCase();
  return <span className={`pl ${GOOD.includes(k) ? 'pl-good' : BAD.includes(k) ? 'pl-bad' : 'pl-warn'}`}>{s.replace(/_/g, ' ')}</span>;
}

export function Bars({ data, label }: { data: { label: string; value: number }[]; label: string }) {
  if (!data.length) return <p className="text-forest/70">Nothing to chart yet.</p>;
  const max = Math.max(...data.map((d) => d.value), 1), step = 300 / data.length, bw = Math.min(36, step - 6);
  return (
    <svg viewBox="0 0 320 140" role="img" aria-label={label} className="h-auto w-full">
      {data.map((d, i) => {
        const h = Math.max(4, Math.round((d.value / max) * 100)), x = 10 + i * step;
        return (
          <g key={d.label + i}>
            <rect x={x} y={118 - h} width={bw} height={h} rx={6} fill={i === data.length - 1 ? '#0A3F2F' : '#C6EC7B'} stroke="#0A3F2F" strokeWidth={1.5} />
            <text x={x + bw / 2} y={134} fontSize={9} textAnchor="middle" fill="currentColor">{d.label.slice(-4)}</text>
          </g>
        );
      })}
    </svg>
  );
}

export function Donut({ parts, label }: { parts: { label: string; value: number; color: string }[]; label: string }) {
  const total = parts.reduce((a, p) => a + p.value, 0);
  if (!total) return <p className="text-forest/70">Nothing here yet.</p>;
  const r = 40, c = 2 * Math.PI * r;
  let off = 0;
  return (
    <div className="flex flex-wrap items-center gap-4">
      <svg viewBox="0 0 100 100" width={130} height={130} role="img" aria-label={label}>
        <circle cx={50} cy={50} r={r} fill="none" stroke="#d6d1bb" strokeWidth={14} />
        {parts.filter((p) => p.value).map((p) => {
          const d = (p.value / total) * c, el = <circle key={p.label} cx={50} cy={50} r={r} fill="none" stroke={p.color} strokeWidth={14} strokeDasharray={`${d} ${c - d}`} strokeDashoffset={-off} transform="rotate(-90 50 50)" />;
          off += d; return el;
        })}
        <text x={50} y={55} textAnchor="middle" fontSize={18} fontWeight={800} fill="currentColor">{total}</text>
      </svg>
      <ul className="text-sm">{parts.filter((p) => p.value).map((p) => <li key={p.label}><span className="mr-2 inline-block size-2.5 rounded-full" style={{ background: p.color }} />{p.label} {p.value}</li>)}</ul>
    </div>
  );
}

export function Feed({ items }: { items: { title: string; body: string | null; created_at: string }[] }) {
  return (
    <Panel title="Activity">
      {!items.length ? <p className="text-forest/70">No activity yet.</p> : items.map((n, i) => (
        <p key={i} className="mb-2.5"><b>{n.title}</b><br /><span className="text-[13px] text-forest/70">{n.body} · {new Date(n.created_at).toLocaleString('en-IN')}</span></p>
      ))}
    </Panel>
  );
}

export function OrdersTable({ rows }: { rows: { id: string; order_no: string; total_paise: number; payment_status: string; status: string }[] }) {
  if (!rows.length) return <p className="text-forest/70">No orders yet.</p>;
  return (
    <div className="overflow-x-auto"><table className="w-full text-left"><thead><tr><th className="p-2">Order</th><th className="p-2">Total</th><th className="p-2">Status</th></tr></thead>
      <tbody>{rows.map((o) => (
        <tr key={o.id} className="border-t border-forest/15"><td className="p-2"><Link className="underline" href={`/orders/${o.id}`}>{o.order_no}</Link></td><td className="p-2">{inr(o.total_paise)}</td>
          <td className="p-2"><Pill s={o.payment_status === 'paid' ? o.status : `payment ${o.payment_status}`} /></td></tr>
      ))}</tbody></table></div>
  );
}

export const orderParts = (o: { payment_status: string }[]) => [
  { label: 'Paid', value: o.filter((x) => x.payment_status === 'paid').length, color: '#0A3F2F' },
  { label: 'Verifying', value: o.filter((x) => x.payment_status === 'pending').length, color: '#8F6B45' },
  { label: 'Awaiting payment', value: o.filter((x) => x.payment_status === 'created').length, color: '#C6EC7B' },
  { label: 'Refunded', value: o.filter((x) => ['refunded', 'partially_refunded'].includes(x.payment_status)).length, color: '#b84a4a' },
  { label: 'Other', value: o.filter((x) => !['paid', 'pending', 'created', 'refunded', 'partially_refunded'].includes(x.payment_status)).length, color: '#9db8ac' },
];
export const appParts = (a: { status: string }[]) => [
  { label: 'Submitted', value: a.filter((x) => x.status === 'submitted').length, color: '#8F6B45' },
  { label: 'Accepted', value: a.filter((x) => x.status === 'accepted').length, color: '#0A3F2F' },
  { label: 'Rejected', value: a.filter((x) => x.status === 'rejected').length, color: '#b84a4a' },
];
export const one = <T,>(v: T | T[] | null | undefined): T | undefined => (Array.isArray(v) ? v[0] : v ?? undefined);
