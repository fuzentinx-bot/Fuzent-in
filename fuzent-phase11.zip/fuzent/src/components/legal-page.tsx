export function LegalPage({ title, sections }: { title: string; sections: string[] }) {
  return (
    <main className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">{title}</h1>
      <p className="my-4 rounded-2xl border-2 border-forest bg-lime p-3 font-bold">Draft outline only. Have a lawyer write and review the final text before launch.</p>
      {sections.map((s) => <section key={s} className="card mb-3"><h2 className="text-xl font-bold">{s}</h2><p className="mt-1 text-forest/70">[YOUR POLICY TEXT]</p></section>)}
    </main>
  );
}
