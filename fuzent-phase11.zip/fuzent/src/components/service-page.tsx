import { createClient } from '@/lib/supabase/server';
import { Err, Ok, F } from '@/components/ui';
import { requestService } from '@/app/services/actions';
import Link from 'next/link';

export async function ServicePage({ division, title, intro, error, done }: { division: 'makepro' | 'digixbite'; title: string; intro: string; error?: string; done?: string }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: services } = await supabase.from('services').select('id, title, description').eq('division', division).eq('is_active', true).order('title');
  return (
    <main className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-5xl font-extrabold tracking-tight">{title}</h1>
      <p className="mt-3 max-w-xl text-lg">{intro}</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {!services?.length ? <p className="text-forest/70">Service packages are added from the admin panel. You can still send a custom brief below.</p>
          : services.map((s) => <div key={s.id} className="card"><h2 className="text-xl font-bold">{s.title}</h2><p className="text-forest/70">{s.description}</p></div>)}
      </div>
      <h2 className="mb-3 mt-12 text-3xl font-extrabold">Send a project brief</h2>
      <Err e={error} /><Ok t={done ? 'Brief sent. We will reply in your alerts and by email.' : undefined} />
      {!user ? <Link className="btn" href={`/login?next=/${division}`}>Log in to send a brief</Link> : (
        <form action={requestService} className="card grid max-w-xl gap-4">
          <input type="hidden" name="division" value={division} />
          {services?.length ? (
            <label className="grid gap-1 text-sm font-bold">Service
              <select name="service" className="field">{services.map((s) => <option key={s.id}>{s.title}</option>)}<option>Custom request</option></select></label>
          ) : <F label="What kind of service?" name="service" />}
          <F label="Tell us what you need" name="brief" area /><F label="Budget in rupees (optional)" name="budget" type="number" req={false} />
          <button className="btn">Send brief</button>
        </form>
      )}
    </main>
  );
}
