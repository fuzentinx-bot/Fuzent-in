import Link from 'next/link';

const cols: [string, [string, string][]][] = [
  ['Divisions', [['/store', 'Digital Store'], ['/makepro', 'MakePro'], ['/digixbite', 'DigixBite'], ['/creators', 'Creators'], ['/freelance', 'Freelance']]],
  ['Company', [['/about', 'About'], ['/pricing', 'Pricing'], ['/faq', 'FAQ'], ['/contact', 'Contact'], ['/support', 'Support']]],
  ['Legal', [['/privacy', 'Privacy Policy'], ['/terms', 'Terms and Conditions'], ['/refund', 'Refund Policy'], ['/shipping', 'Shipping and Delivery']]],
];

export function SiteFooter() {
  return (
    <footer className="mt-16 bg-forest text-cream">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div><p className="text-2xl font-extrabold">FUZ<span className="text-lime">ENT</span></p><p className="mt-2 opacity-85">Build Beyond Limits.</p></div>
        {cols.map(([h, links]) => (
          <nav key={h} aria-label={h}><p className="font-bold">{h}</p>
            {links.map(([href, label]) => <Link key={href} href={href} className="block py-1 text-sm opacity-85 hover:text-lime hover:opacity-100">{label}</Link>)}</nav>
        ))}
      </div>
      <p className="mx-auto max-w-6xl px-5 pb-8 text-sm opacity-70">© 2026 FUZENT · fuzent.in</p>
    </footer>
  );
}
