'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

const links = [
  ['/solutions', 'Solutions'], ['/makepro', 'MakePro'], ['/digixbite', 'DigixBite'],
  ['/store', 'Store'], ['/creators', 'Creators'], ['/freelance', 'Freelance'],
] as const;

// Runs in the browser so the root layout stays static: public pages can be served from the CDN
// with no server or database work. This only decides which buttons to show; real access control
// is enforced by middleware, server checks and database policies.
export function SiteHeader() {
  const path = usePathname();
  const router = useRouter();
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    const sb = createClient();
    let live = true;
    sb.auth.getSession().then(async ({ data }) => {
      if (!live) return;
      setSignedIn(!!data.session);
      if (data.session) {
        const { count } = await sb.from('notifications').select('id', { count: 'exact', head: true }).is('read_at', null);
        if (live) setUnread(count ?? 0);
      } else setUnread(0);
    });
    const { data: sub } = sb.auth.onAuthStateChange((_e, session) => setSignedIn(!!session));
    return () => { live = false; sub.subscription.unsubscribe(); };
  }, [path]);

  async function logout() {
    await createClient().auth.signOut();
    setSignedIn(false);
    router.push('/');
    router.refresh();
  }

  const pill = 'rounded-full px-3 py-2 text-[15px] hover:bg-lime hover:text-forest';
  return (
    <header className="sticky top-0 z-30 bg-forest text-cream">
      <div className="mx-auto flex min-h-16 max-w-6xl items-center gap-3 px-5">
        <Link href="/" className="text-2xl font-extrabold tracking-tight">FUZ<span className="text-lime">ENT</span></Link>
        <nav aria-label="Main" className="ml-3 hidden flex-1 gap-1 lg:flex">
          {links.map(([href, label]) => <Link key={href} href={href} className={pill}>{label}</Link>)}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {signedIn && <Link href="/notifications" className={`${pill} hidden sm:inline-block`}>Alerts{unread > 0 ? ` (${unread})` : ''}</Link>}
          {signedIn === false && <Link href="/login" className="btn min-h-[44px] px-4">Log in</Link>}
          {signedIn && <><Link href="/dashboard" className="btn min-h-[44px] px-4">Dashboard</Link>
            <button onClick={logout} className="btn btn-ghost min-h-[44px] border-cream px-4 text-cream">Log out</button></>}
          <details className="relative lg:hidden">
            <summary className="btn btn-ghost min-h-[44px] cursor-pointer list-none border-cream px-4 text-cream" aria-label="Menu">Menu</summary>
            <div className="absolute right-0 top-12 grid w-56 gap-1 rounded-2xl border-2 border-forest bg-cream p-2 text-forest shadow-sticker">
              {links.map(([href, label]) => <Link key={href} href={href} className="rounded-xl px-3 py-2 font-bold hover:bg-lime">{label}</Link>)}
            </div>
          </details>
        </div>
      </div>
    </header>
  );
}
