export const Err = ({ e }: { e?: string }) =>
  e ? <p role="alert" className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">{e}</p> : null;
export const Ok = ({ t }: { t?: string }) =>
  t ? <p role="status" className="mb-4 rounded-xl bg-lime p-3 text-sm font-bold">{t}</p> : null;

export function F({ label, name, type = 'text', req = true, def = '', ph = '', area = false }:
  { label: string; name: string; type?: string; req?: boolean; def?: string; ph?: string; area?: boolean }) {
  return (
    <label className="grid gap-1 text-sm font-bold">{label}
      {area
        ? <textarea className="field" name={name} rows={4} required={req} defaultValue={def} placeholder={ph} />
        : <input className="field" name={name} type={type} required={req} defaultValue={def} placeholder={ph} />}
    </label>
  );
}
export const StatusTag = ({ s }: { s: string }) =>
  <span className="rounded-full bg-lime px-3 py-1 text-sm font-bold">{s}</span>;
