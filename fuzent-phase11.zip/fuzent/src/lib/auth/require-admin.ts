import 'server-only';
import { createClient } from '@/lib/supabase/server';
import { getRoles, isAdmin } from '@/lib/auth/roles';

// Server actions are public endpoints: every admin action must call this first.
export async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('unauthenticated');
  if (!isAdmin(await getRoles(supabase, user.id))) throw new Error('forbidden');
  return user;
}
