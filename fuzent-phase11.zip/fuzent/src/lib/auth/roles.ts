import type { SupabaseClient } from '@supabase/supabase-js';

export type RoleKey =
  | 'super_admin' | 'admin' | 'customer' | 'freelancer' | 'creator' | 'brand' | 'business_client';

export async function getRoles(supabase: SupabaseClient, userId: string): Promise<RoleKey[]> {
  const { data } = await supabase.from('user_roles').select('roles(key)').eq('user_id', userId);
  return (data ?? []).flatMap((row: any) => {
    const r = row.roles;
    return Array.isArray(r) ? r.map((x: any) => x.key) : r?.key ? [r.key] : [];
  }) as RoleKey[];
}

export const isAdmin = (roles: RoleKey[]) => roles.includes('admin') || roles.includes('super_admin');
