import 'server-only';
import { admin } from '@/lib/supabase/admin';
import { sendEmail } from '@/lib/email';
import { logEvent } from '@/lib/log';

type Db = ReturnType<typeof admin>;

async function notify(db: Db, userIds: string[], title: string, body: string, link: string) {
  for (const id of [...new Set(userIds)]) {
    const { data: p } = await db.from('profiles').select('email, prefs').eq('id', id).single();
    if (p?.prefs?.inapp !== false) await db.from('notifications').insert({ user_id: id, title, body, link });
    if (p?.email && p?.prefs?.email !== false) await sendEmail(p.email, title, body, link);
  }
}
async function adminIds(db: Db) {
  const { data: roles } = await db.from('roles').select('id').in('key', ['admin', 'super_admin']);
  const { data } = await db.from('user_roles').select('user_id').in('role_id', (roles ?? []).map((r) => r.id));
  return (data ?? []).map((r) => r.user_id as string);
}
const order = async (db: Db, id: string) => (await db.from('orders').select('id, order_no, customer_id').eq('id', id).single()).data!;
const ticket = async (db: Db, id: string) => (await db.from('support_tickets').select('id, user_id, subject').eq('id', id).single()).data!;

const handlers: Record<string, (p: any, db: Db) => Promise<void>> = {
  'payment.verified': async (p, db) => { const o = await order(db, p.order_id); await notify(db, [o.customer_id], 'Payment confirmed', `Order ${o.order_no} is confirmed. Your invoice is ready.`, `/orders/${o.id}`); },
  'payment.submitted': async (p, db) => { const o = await order(db, p.order_id); await notify(db, await adminIds(db), 'Payment to verify', `Order ${o.order_no} has a transaction ID waiting.`, '/admin/payments'); },
  'payment.rejected': async (p, db) => { const o = await order(db, p.order_id); await notify(db, [o.customer_id], 'Payment not matched', `We could not match your payment for ${o.order_no}. Please check the transaction ID.`, `/checkout/${o.id}`); },
  'order.refunded': async (p, db) => { const o = await order(db, p.order_id); await notify(db, [o.customer_id], 'Refund recorded', `A refund of Rs. ${(p.amount_paise / 100).toFixed(2)} was recorded for ${o.order_no}.`, `/orders/${o.id}`); },
  'application.accepted': async (p, db) => { const { data: a } = await db.from('applications').select('applicant_id').eq('id', p.application_id).single(); if (a) await notify(db, [a.applicant_id], 'You were accepted', 'Your application was accepted. Say hello in your messages.', '/messages'); },
  'application.rejected': async (p, db) => { const { data: a } = await db.from('applications').select('applicant_id').eq('id', p.application_id).single(); if (a) await notify(db, [a.applicant_id], 'Application update', 'Your application was not selected this time.', '/creators'); },
  'project.assigned': async (p, db) => { const { data: pr } = await db.from('projects').select('id, title, assignee_id').eq('id', p.project_id).single(); if (pr?.assignee_id) await notify(db, [pr.assignee_id], 'You got the project', `You were chosen for "${pr.title}".`, `/projects/${pr.id}`); },
  'project.requested': async (p, db) => { await notify(db, await adminIds(db), 'New service request', 'A customer sent a project brief.', `/projects/${p.project_id}`); },
  'ticket.created': async (p, db) => { const t = await ticket(db, p.ticket_id); await notify(db, await adminIds(db), 'New support ticket', t.subject, `/admin/support/${t.id}`); },
  'ticket.customer_replied': async (p, db) => { const t = await ticket(db, p.ticket_id); await notify(db, await adminIds(db), 'Customer replied', t.subject, `/admin/support/${t.id}`); },
  'ticket.replied': async (p, db) => { const t = await ticket(db, p.ticket_id); await notify(db, [t.user_id], 'Support replied', t.subject, `/support/${t.id}`); },
};

// Works through queued events. Safe to run often and from several places: each event is claimed first.
export async function processEvents(limit = 20) {
  const db = admin();
  const stale = new Date(Date.now() - 5 * 60_000).toISOString();
  const open = `claimed_at.is.null,claimed_at.lt.${stale}`;
  const { data: rows } = await db.from('automation_events').select('id, event_type, payload, attempts')
    .is('processed_at', null).lt('attempts', 5).or(open).order('created_at').limit(limit);
  let done = 0;
  for (const r of rows ?? []) {
    const { data: claimed } = await db.from('automation_events').update({ claimed_at: new Date().toISOString(), attempts: r.attempts + 1 })
      .eq('id', r.id).is('processed_at', null).or(open).select('id');
    if (!claimed?.length) continue;
    try {
      await handlers[r.event_type]?.(r.payload, db);
      await db.from('automation_events').update({ processed_at: new Date().toISOString(), error: null }).eq('id', r.id);
      done++;
    } catch (e) {
      logEvent('error', 'automation event failed', { event: r.event_type, id: r.id });
      await db.from('automation_events').update({ error: String(e).slice(0, 300) }).eq('id', r.id);
    }
  }
  return done;
}
