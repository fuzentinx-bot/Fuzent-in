export type CouponRule = { percent_off: number | null; amount_off_paise: number | null };

// Pure money maths, kept separate so it can be tested. Never goes below zero or above the subtotal.
export function computeDiscount(c: CouponRule, subtotalPaise: number): number {
  const raw = c.percent_off ? Math.floor((subtotalPaise * c.percent_off) / 100) : Math.min(c.amount_off_paise ?? 0, subtotalPaise);
  return Math.max(0, Math.min(raw, subtotalPaise));
}
