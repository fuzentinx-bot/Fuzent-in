import 'server-only';
import { admin } from '@/lib/supabase/admin';

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

// Sends through Resend's REST API. Never throws: failures are logged and the app carries on.
export async function sendEmail(to: string, subject: string, text: string, link?: string) {
  const db = admin();
  const key = process.env.RESEND_API_KEY, from = process.env.EMAIL_FROM;
  const subj = subject.replace(/[\r\n]+/g, ' ').slice(0, 150); // no header injection
  const log = (status: string, error?: string) => db.from('email_log').insert({ to_email: to, subject: subj, status, error: error?.slice(0, 300) });
  if (!key || !from) { await log('skipped'); return; }
  const site = process.env.NEXT_PUBLIC_SITE_URL ?? '';
  const html = `<div style="font-family:system-ui,sans-serif;max-width:520px"><p>${esc(text)}</p>${link ? `<p><a href="${esc(site + link)}">Open in FUZENT</a></p>` : ''}</div>`;
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to: [to], subject: subj, html }),
      signal: AbortSignal.timeout(8000),
    });
    await log(res.ok ? 'sent' : 'failed', res.ok ? undefined : await res.text());
  } catch (e) { await log('failed', String(e)); }
}
