// Outbound calls must never hang forever. Used for every Supabase request made on the server.
export const timedFetch = (ms = 10_000): typeof fetch => (input, init) =>
  fetch(input, { ...init, signal: init?.signal ?? AbortSignal.timeout(ms) });
