// Splits a GST-inclusive total. Configuration only: an accountant must confirm the rules before real invoices.
export function splitGst(totalPaise: number, ratePct: number, sameState: boolean) {
  if (!(ratePct > 0)) return { taxable: totalPaise, cgst: 0, sgst: 0, igst: 0 };
  const taxable = Math.round((totalPaise * 100) / (100 + ratePct));
  const tax = totalPaise - taxable;
  if (sameState) { const cgst = Math.floor(tax / 2); return { taxable, cgst, sgst: tax - cgst, igst: 0 }; }
  return { taxable, cgst: 0, sgst: 0, igst: tax };
}
