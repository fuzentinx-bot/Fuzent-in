import 'server-only';
import { admin } from '@/lib/supabase/admin';
import { splitGst } from '@/lib/gst';

// Creates one invoice per paid order (unique on order_id, so repeat calls are harmless).
// Item prices are treated as GST-INCLUSIVE when a rate is set. This is configuration, not
// a compliance guarantee: an accountant must validate the setup before real use.
export async function createInvoice(orderId: string) {
  const db = admin();
  const { data: o } = await db.from('orders').select('id, customer_id, subtotal_paise, discount_paise, total_paise, order_items(title_snapshot, unit_price_paise, quantity)').eq('id', orderId).single();
  if (!o) return;
  const [{ data: biz }, { data: cust }, { data: prof }] = await Promise.all([
    db.from('website_settings').select('value').eq('key', 'business.profile').maybeSingle(),
    db.from('customers').select('gstin, billing_address').eq('user_id', o.customer_id).maybeSingle(),
    db.from('profiles').select('full_name, email').eq('id', o.customer_id).single(),
  ]);
  const b = biz?.value ?? {};
  const rate = Number(b.gst_rate ?? 0);
  const buyerState = cust?.billing_address?.state;
  const { taxable, cgst, sgst, igst } = splitGst(o.total_paise, rate, !buyerState || !b.state || buyerState === b.state);
  const { data: no } = await db.rpc('next_invoice_no');
  const { error } = await db.from('invoices').insert({
    invoice_no: no, order_id: o.id, customer_id: o.customer_id, status: 'issued', issued_at: new Date().toISOString(),
    seller_gstin: b.gstin ?? null, buyer_gstin: cust?.gstin ?? null, sac_hsn: b.sac ?? null,
    subtotal_paise: taxable, discount_paise: o.discount_paise, cgst_paise: cgst, sgst_paise: sgst, igst_paise: igst, total_paise: o.total_paise,
    lines: o.order_items, buyer_name: prof?.full_name ?? prof?.email, seller_snapshot: b,
  });
  if (error && error.code !== '23505') throw error;
}
