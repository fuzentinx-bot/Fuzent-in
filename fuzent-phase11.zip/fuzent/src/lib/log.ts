// Structured logs with no personal data: only event names and ids. Never pass emails, tokens or payment details.
export function logEvent(level: 'info' | 'warn' | 'error', msg: string, fields: Record<string, string | number | boolean | null> = {}) {
  console[level === 'info' ? 'log' : level](JSON.stringify({ level, msg, ...fields, at: new Date().toISOString() }));
}
