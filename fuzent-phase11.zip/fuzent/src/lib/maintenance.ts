import 'server-only';
import { admin } from '@/lib/supabase/admin';

// Cancels orders nobody paid for within 48 hours and gives their coupon use back.
// Orders where the customer already sent a transaction ID are never touched.
export async function expireStaleOrders() {
  const db = admin();
  const cutoff = new Date(Date.now() - 48 * 3600_000).toISOString();
  const { data } = await db.from('orders').select('id, coupon_id').eq('payment_status', 'created').eq('status', 'pending').lt('created_at', cutoff).limit(100);
  let n = 0;
  for (const o of data ?? []) {
    const { data: upd } = await db.from('orders').update({ status: 'cancelled', payment_status: 'failed' }).eq('id', o.id).eq('payment_status', 'created').select('id');
    if (!upd?.length) continue;
    n++;
    await db.from('payments').update({ status: 'failed', failure_reason: 'expired' }).eq('order_id', o.id).eq('status', 'created');
    if (o.coupon_id) {
      const { data: red } = await db.from('coupon_redemptions').delete().eq('order_id', o.id).select('id');
      if (red?.length) {
        const { data: c } = await db.from('coupons').select('redeemed').eq('id', o.coupon_id).single();
        await db.from('coupons').update({ redeemed: Math.max(0, (c?.redeemed ?? 1) - 1) }).eq('id', o.coupon_id);
      }
    }
  }
  return n;
}
