// Small in-memory limiter for guessable actions (coupon codes, password reset).
// Works per server process: right for one instance. For several instances use a shared store (Redis).
const hits = new Map<string, number[]>();

export function hitLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  recent.push(now);
  hits.set(key, recent);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < windowMs)) hits.delete(k);
  return recent.length > max; // true = blocked
}
