import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';

// A customer can start at most 20 orders an hour. Stops accidental floods and abuse.
export async function tooManyOrders(db: SupabaseClient, userId: string) {
  const since = new Date(Date.now() - 3600_000).toISOString();
  const { count } = await db.from('orders').select('id', { count: 'exact', head: true }).eq('customer_id', userId).gte('created_at', since);
  return (count ?? 0) >= 20;
}
