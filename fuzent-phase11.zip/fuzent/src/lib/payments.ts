import 'server-only';
import { admin } from '@/lib/supabase/admin';
import { createInvoice } from '@/lib/invoices';
import { logEvent } from '@/lib/log';

// The ONLY place an order becomes paid, and only an admin action calls it,
// after checking the money actually arrived in the bank account.
export async function markPaid(paymentId: string, verifiedBy: string) {
  const db = admin();
  const { data: updated } = await db.from('payments')
    .update({ status: 'paid', verified_at: new Date().toISOString(), verified_by: verifiedBy })
    .eq('id', paymentId).eq('status', 'pending').not('utr', 'is', null).select('id, order_id, utr, amount_paise'); // only after the customer sent a transaction ID
  const p = updated?.[0];
  if (!p) return { ok: false as const }; // already paid or unknown: safe no-op

  await db.from('orders').update({ payment_status: 'paid', status: 'confirmed' }).eq('id', p.order_id);
  await db.from('audit_logs').insert({ actor_id: verifiedBy, action: 'payment.confirmed', entity: 'payment', entity_id: p.id, meta: { utr: p.utr, amount_paise: p.amount_paise } });
  await db.from('automation_events').insert({ event_type: 'payment.verified', payload: { order_id: p.order_id, payment_id: p.id } });
  await createInvoice(p.order_id).catch((e) => logEvent('error', 'invoice failed', { order: p.order_id })); // never blocks the payment
  return { ok: true as const };
}

// Sends the order back to "waiting for payment" so the customer can fix the transaction ID.
export async function rejectPayment(paymentId: string, actorId: string, reason: string) {
  const db = admin();
  const { data: updated } = await db.from('payments')
    .update({ status: 'created', utr: null, submitted_at: null, failure_reason: reason })
    .eq('id', paymentId).eq('status', 'pending').select('id, order_id, utr');
  const p = updated?.[0];
  if (!p) return;
  await db.from('orders').update({ payment_status: 'created' }).eq('id', p.order_id);
  await db.from('audit_logs').insert({ actor_id: actorId, action: 'payment.rejected', entity: 'payment', entity_id: p.id, meta: { reason } });
  await db.from('automation_events').insert({ event_type: 'payment.rejected', payload: { order_id: p.order_id } });
}
