'use server';

import { redirect } from 'next/navigation';
import { needUser } from '@/lib/forms';
import { safeRedirectPath } from '@/lib/safe-redirect';

export async function savePrefs(fd: FormData) {
  const safe = safeRedirectPath(fd.get('back'));
  const { supabase, user } = await needUser(safe);
  await supabase.from('profiles').update({ prefs: { email: fd.get('email') === 'on', inapp: fd.get('inapp') === 'on' } }).eq('id', user.id); // RLS: own profile
  redirect(`${safe}?saved=1`);
}
