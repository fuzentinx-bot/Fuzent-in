import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { computeDiscount } from '@/lib/discount';

export type PriceResult =
  | { error: string }
  | { discount: number; total: number; coupon: { id: string; code: string } | null };

// Coupons are validated here, on the server, every time. The browser never sends a price.
export async function priceOrder(db: SupabaseClient, userId: string, subtotal: number, code?: string): Promise<PriceResult> {
  if (!code?.trim()) return { discount: 0, total: subtotal, coupon: null };
  const { data: c } = await db.from('coupons').select('*').eq('code', code.trim()).maybeSingle();
  const now = Date.now();
  if (!c || !c.is_active || (c.valid_from && new Date(c.valid_from).getTime() > now) ||
      (c.valid_until && new Date(c.valid_until).getTime() < now) ||
      (c.max_redemptions != null && c.redeemed >= c.max_redemptions)) return { error: 'This coupon is not valid.' };
  if (subtotal < c.min_order_paise) return { error: `This coupon needs an order of at least ₹${c.min_order_paise / 100}.` };
  if (c.one_per_user) {
    const { count } = await db.from('coupon_redemptions').select('id', { count: 'exact', head: true }).eq('coupon_id', c.id).eq('user_id', userId);
    if (count) return { error: 'You have already used this coupon.' };
  }
  const discount = computeDiscount(c, subtotal);
  const total = subtotal - discount;
  if (total < 100) return { error: 'A coupon cannot make an order free.' };
  return { discount, total, coupon: { id: c.id, code: c.code } };
}
