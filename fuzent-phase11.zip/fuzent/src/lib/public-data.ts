import { createClient } from '@supabase/supabase-js';
import { unstable_cache } from 'next/cache';

// Public catalog reads: cookie-free client plus a short cache, so thousands of visitors
// cost the database one query per minute per list instead of one per page view.
// Admin actions call revalidateTag('catalog') to refresh sooner.
const db = () => createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { auth: { persistSession: false } });
const opts = (key: string, revalidate = 60) => ({ revalidate, tags: ['catalog'], });

export const getCategories = unstable_cache(async () => {
  const { data } = await db().from('product_categories').select('slug, name').order('sort_order');
  return data ?? [];
}, ['categories'], opts('categories', 300));

export const getProducts = unstable_cache(async (q: string, cat: string) => {
  let query = db().from('products').select('id, slug, title, price_paise, product_categories(slug, name)').eq('is_active', true).order('created_at', { ascending: false }).limit(60);
  if (q) query = query.ilike('title', `%${q.replace(/[%_]/g, '')}%`);
  const { data } = await query;
  return (data ?? []).filter((p: any) => !cat || (Array.isArray(p.product_categories) ? p.product_categories[0] : p.product_categories)?.slug === cat);
}, ['products'], opts('products'));

export const getProduct = unstable_cache(async (slug: string) => {
  const { data } = await db().from('products').select('id, slug, title, description, price_paise').eq('slug', slug).eq('is_active', true).maybeSingle();
  return data;
}, ['product'], opts('product'));

export const getCreators = unstable_cache(async () => {
  const { data } = await db().from('creators').select('user_id, handle, bio, niche').eq('status', 'approved').order('created_at', { ascending: false }).limit(60);
  return data ?? [];
}, ['creators'], opts('creators'));

export const getCreator = unstable_cache(async (handle: string) => {
  const { data } = await db().from('creators').select('handle, bio, niche, social_links, portfolio').eq('handle', handle).eq('status', 'approved').maybeSingle();
  return data;
}, ['creator'], opts('creator'));

export const getOpenCampaigns = unstable_cache(async () => {
  const { data } = await db().from('campaigns').select('id, title, brief, budget_paise').eq('approval', 'approved').eq('status', 'open').order('created_at', { ascending: false }).limit(30);
  return data ?? [];
}, ['campaigns'], opts('campaigns'));
