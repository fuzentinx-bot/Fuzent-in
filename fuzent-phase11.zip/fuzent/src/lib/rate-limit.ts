import 'server-only';
import { admin } from '@/lib/supabase/admin';

// Simple database-backed limit: at most `max` rows per hour for one user or email.
export async function tooMany(table: 'support_tickets' | 'contact_messages', col: 'user_id' | 'email', value: string, max = 5) {
  const since = new Date(Date.now() - 3600_000).toISOString();
  const { count } = await admin().from(table).select('id', { count: 'exact', head: true }).eq(col, value).gte('created_at', since);
  return (count ?? 0) >= max;
}
