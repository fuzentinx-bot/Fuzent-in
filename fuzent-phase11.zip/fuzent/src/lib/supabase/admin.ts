import 'server-only';
import { createClient } from '@supabase/supabase-js';
import { timedFetch } from '@/lib/fetch-timeout';

// Service-role client: bypasses RLS. Server only. Use for payments, webhooks and signed URLs.
export function admin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: timedFetch() },
  });
}
