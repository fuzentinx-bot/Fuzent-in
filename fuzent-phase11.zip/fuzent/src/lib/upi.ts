export const VPA_RE = /^[a-zA-Z0-9._-]{2,256}@[a-zA-Z]{2,64}$/;

// Builds the query string shared by the QR code and every app deep link.
export function upiQuery(o: { vpa: string; name: string; paise: number; ref: string }) {
  const q = new URLSearchParams({
    pa: o.vpa, pn: o.name, am: (o.paise / 100).toFixed(2), cu: 'INR', tn: o.ref, tr: o.ref,
  }).toString();
  return q.replace(/\+/g, '%20').replace(/%40/g, '@'); // UPI apps expect %20 and a literal @
}

export function upiLinks(q: string) {
  return [
    { label: 'Any UPI app', href: `upi://pay?${q}` },
    { label: 'Google Pay', href: `tez://upi/pay?${q}` },
    { label: 'PhonePe', href: `phonepe://pay?${q}` },
    { label: 'Paytm', href: `paytmmp://pay?${q}` },
  ];
}
