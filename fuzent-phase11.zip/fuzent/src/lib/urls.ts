export function isHttpsUrl(value: string): boolean {
  try { const u = new URL(value); return u.protocol === 'https:' && !!u.hostname; } catch { return false; }
}
// One link per line or comma separated, at most 5, every one must be https.
export function parseLinks(raw: string): string[] | null {
  const list = raw.split(/\n|,/).map((x) => x.trim()).filter(Boolean).slice(0, 5);
  return list.every(isHttpsUrl) ? list : null;
}
