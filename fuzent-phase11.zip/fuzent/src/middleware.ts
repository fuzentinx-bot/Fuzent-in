import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

// Refreshes the Supabase session on every request and requires login for private areas.
// Role checks (admin) happen in server layouts AND in database RLS: defense in depth.
export async function middleware(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll(list) {
          list.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        },
      },
    },
  );

  const { data: { user } } = await supabase.auth.getUser();
  const path = request.nextUrl.pathname;
  const isPrivate = path.startsWith('/dashboard') || path.startsWith('/my-data') || path.startsWith('/freelancer') || path.startsWith('/admin') || path.startsWith('/orders') || path.startsWith('/checkout') || path.startsWith('/cart') || path.startsWith('/invoices') || path.startsWith('/brand') || path.startsWith('/notifications') || path.startsWith('/support') || path.startsWith('/messages') || path.startsWith('/projects/new');

  if (!user && isPrivate) {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    url.searchParams.set('next', path);
    return NextResponse.redirect(url);
  }
  return response;
}

// Only private areas pass through here, so public pages never wait on an auth call.
export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*', '/orders/:path*', '/checkout/:path*', '/cart/:path*', '/invoices/:path*',
    '/brand/:path*', '/messages/:path*', '/notifications/:path*', '/support/:path*', '/freelancer/:path*', '/my-data/:path*', '/projects/new'],
};
