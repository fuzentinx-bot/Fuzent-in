-- Run AFTER you have signed up on your site and verified your email.
-- Replace the email below with the one you signed up with, then Run.
insert into user_roles (user_id, role_id)
select u.id, r.id
from auth.users u, roles r
where u.email = 'PUT-YOUR-EMAIL-HERE' and r.key = 'super_admin'
on conflict do nothing;
-- Check: this should return one row.
select u.email, r.key from user_roles ur join auth.users u on u.id = ur.user_id join roles r on r.id = ur.role_id where r.key = 'super_admin';
