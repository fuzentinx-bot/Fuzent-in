-- Direct UPI payments (no third-party gateway). Run after fuzent_schema_v1.sql.
-- payments.status meaning:
--   created = waiting for the customer to pay and submit a transaction ID (UTR)
--   pending = UTR submitted, waiting for an admin to check it against the bank
--   paid    = admin confirmed the credit in the bank account
alter table payments
  add column if not exists utr text,
  add column if not exists submitted_at timestamptz,
  add column if not exists verified_by uuid references profiles(id);
alter table payments alter column gateway set default 'upi_direct';
-- One UTR can only ever back one payment.
create unique index if not exists payments_utr_key on payments (utr) where utr is not null;
