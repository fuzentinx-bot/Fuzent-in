-- Run after 002. Cart, coupon rules, refunds, invoice numbering.
create table if not exists cart_items (
  user_id uuid references profiles(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  qty int not null default 1 check (qty between 1 and 10),
  primary key (user_id, product_id)
);
alter table cart_items enable row level security;
create policy own on cart_items for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table coupons
  add column if not exists min_order_paise int not null default 0,
  add column if not exists one_per_user boolean not null default true;

create table if not exists coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references coupons(id),
  user_id uuid not null references profiles(id),
  order_id uuid not null unique references orders(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table coupon_redemptions enable row level security;
create policy admin_all on coupon_redemptions for all using (is_admin()) with check (is_admin());
create policy own on coupon_redemptions for select using (user_id = auth.uid());

create table if not exists refunds (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references payments(id),
  order_id uuid not null references orders(id),
  amount_paise int not null check (amount_paise > 0),
  reason text not null,
  refund_utr text,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);
create index if not exists refunds_order_idx on refunds (order_id);
alter table refunds enable row level security;
create policy admin_all on refunds for all using (is_admin()) with check (is_admin());
create policy own on refunds for select using (exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));

alter table invoices
  add column if not exists lines jsonb not null default '[]',
  add column if not exists buyer_name text,
  add column if not exists seller_snapshot jsonb;
create unique index if not exists invoices_order_key on invoices (order_id);

create sequence if not exists invoice_seq start 1;
create or replace function next_invoice_no() returns text
language sql security definer set search_path = public as $$
  select 'FZ/' || to_char(now(), 'YY') || '/' || lpad(nextval('invoice_seq')::text, 5, '0')
$$;
revoke all on function next_invoice_no() from public, anon, authenticated; -- server (service role) only
