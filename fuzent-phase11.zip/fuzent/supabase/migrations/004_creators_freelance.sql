-- Run after 003. Marketplace: creators, brands, campaigns, freelancers, projects, messaging, reviews.
alter table projects add column if not exists is_open boolean not null default false,
                     add column if not exists skills text[] not null default '{}';
alter table freelancers add column if not exists display_name text;
alter table reviews add column if not exists project_id uuid unique references projects(id);
alter table conversations add column if not exists title text,
                          add column if not exists campaign_id uuid references campaigns(id);

-- People cannot approve themselves: only admins (or the server) may change status.
create or replace function protect_status() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not is_admin() then
    if tg_table_name = 'campaigns' then
      if new.approval is distinct from old.approval then raise exception 'not allowed'; end if;
    elsif new.status is distinct from old.status then raise exception 'not allowed'; end if;
  end if;
  return new;
end $$;
create trigger protect_creators    before update on creators    for each row execute function protect_status();
create trigger protect_freelancers before update on freelancers for each row execute function protect_status();
create trigger protect_brands      before update on brands      for each row execute function protect_status();
create trigger protect_campaigns   before update on campaigns   for each row execute function protect_status();

-- Replace the broad Phase 1 policies with narrower ones.
drop policy if exists own on creators;     drop policy if exists own on freelancers;
drop policy if exists own on brands;       drop policy if exists own on applications;
drop policy if exists brand_campaigns on campaigns; drop policy if exists own on reviews;

create policy own_sel on creators for select using (user_id = auth.uid());
create policy own_ins on creators for insert with check (user_id = auth.uid() and status = 'pending');
create policy own_upd on creators for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_sel on freelancers for select using (user_id = auth.uid());
create policy own_ins on freelancers for insert with check (user_id = auth.uid() and status = 'pending');
create policy own_upd on freelancers for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_sel on brands for select using (owner_id = auth.uid());
create policy own_ins on brands for insert with check (owner_id = auth.uid() and status = 'pending');
create policy own_upd on brands for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy brand_sel on campaigns for select using (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()));
create policy brand_ins on campaigns for insert with check (approval = 'pending' and exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid() and b.status = 'approved'));
create policy brand_upd on campaigns for update using (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()))
  with check (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()));

-- Applicants can create and read their own applications. Accept/reject/withdraw run on the server.
create policy app_sel on applications for select using (applicant_id = auth.uid());
create policy app_ins on applications for insert with check (applicant_id = auth.uid() and status = 'submitted');
create policy client_sees on applications for select using (exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid()));

-- Projects: open ones are visible to logged-in users; clients post their own.
create policy open_projects on projects for select to authenticated using (is_open);
create policy client_ins on projects for insert with check (client_id = auth.uid() and status = 'not_started');
-- Reviews have no client write policy: created by a server action after checking the project.
