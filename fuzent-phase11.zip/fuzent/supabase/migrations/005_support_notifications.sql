-- Run after 004. Support threads, contact messages, email log, automation claiming.
create table if not exists ticket_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references support_tickets(id) on delete cascade,
  author_id uuid not null references profiles(id),
  is_staff boolean not null default false,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists ticket_messages_idx on ticket_messages (ticket_id, created_at);
alter table ticket_messages enable row level security;
create policy admin_all on ticket_messages for all using (is_admin()) with check (is_admin());
create policy own_sel on ticket_messages for select using (exists (select 1 from support_tickets t where t.id = ticket_id and t.user_id = auth.uid()));
create policy own_ins on ticket_messages for insert with check (author_id = auth.uid() and is_staff = false and exists (select 1 from support_tickets t where t.id = ticket_id and t.user_id = auth.uid()));

-- Customers can open and read their tickets; status changes happen on the server or by admins.
drop policy if exists own on support_tickets;
create policy own_sel on support_tickets for select using (user_id = auth.uid());
create policy own_ins on support_tickets for insert with check (user_id = auth.uid() and status = 'open');

create table if not exists contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null, email text not null, message text not null,
  created_at timestamptz not null default now()
);
alter table contact_messages enable row level security;
create policy admin_all on contact_messages for all using (is_admin()) with check (is_admin());

create table if not exists email_log (
  id uuid primary key default gen_random_uuid(),
  to_email text not null, subject text not null,
  status text not null, error text,
  created_at timestamptz not null default now()
);
alter table email_log enable row level security;
create policy admin_read on email_log for select using (is_admin());

alter table automation_events add column if not exists claimed_at timestamptz;
