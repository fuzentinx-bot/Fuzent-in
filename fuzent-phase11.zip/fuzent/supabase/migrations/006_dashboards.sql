-- Run after 005. Dashboard settings: notification preferences and freelancer availability.
alter table profiles add column if not exists prefs jsonb not null default '{"email": true, "inapp": true}';
alter table freelancers add column if not exists available boolean not null default true;
