-- Run after 006. Indexes for the busiest queries, and cheaper row-level-security checks.
create index if not exists products_active_idx   on products (is_active, created_at desc);
create index if not exists creators_status_idx   on creators (status, created_at desc);
create index if not exists freelancers_status_idx on freelancers (status, created_at desc);
create index if not exists campaigns_open_idx    on campaigns (approval, status, created_at desc);
create index if not exists campaigns_brand_idx   on campaigns (brand_id);
create index if not exists applications_campaign_idx on applications (campaign_id, status);
create index if not exists applications_project_idx  on applications (project_id, status);
create index if not exists applications_applicant_idx on applications (applicant_id, created_at desc);
create index if not exists projects_open_idx     on projects (is_open, created_at desc);
create index if not exists tickets_user_idx      on support_tickets (user_id, status);
create index if not exists conv_members_user_idx on conversation_members (user_id);
create index if not exists orders_status_idx     on orders (payment_status, created_at desc);

-- Wrapping auth.uid() and is_admin() in a sub-select lets Postgres evaluate them once per
-- query instead of once per row. Same rules, much cheaper at volume.
do $$
declare r record;
begin
  for r in select tablename from pg_policies where schemaname = 'public' and policyname = 'admin_all' loop
    execute format('alter policy admin_all on public.%I using ((select is_admin())) with check ((select is_admin()))', r.tablename);
  end loop;
end $$;
alter policy own     on orders        using (customer_id = (select auth.uid()));
alter policy own     on notifications using (user_id = (select auth.uid()));
alter policy own_upd on notifications using (user_id = (select auth.uid()));
alter policy own     on user_roles    using (user_id = (select auth.uid()));
alter policy own     on cart_items    using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
