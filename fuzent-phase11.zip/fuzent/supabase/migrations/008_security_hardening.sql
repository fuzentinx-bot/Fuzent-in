-- Run after 007. Security hardening from the audit (see SECURITY-AUDIT.md). Additive: no data is deleted.

-- F-02 / F-03: people must not edit their own rating, email or active flag.
create or replace function protect_columns() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not is_admin() then
    if tg_table_name = 'profiles' then
      if new.email is distinct from old.email or new.is_active is distinct from old.is_active then raise exception 'not allowed'; end if;
    elsif tg_table_name = 'freelancers' then
      if new.rating_avg is distinct from old.rating_avg then raise exception 'not allowed'; end if;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists protect_profiles_cols on profiles;
create trigger protect_profiles_cols before update on profiles for each row execute function protect_columns();
drop trigger if exists protect_freelancers_cols on freelancers;
create trigger protect_freelancers_cols before update on freelancers for each row execute function protect_columns();

-- F-01: the rules for applying now live in the database, so calling the API directly cannot bypass them.
drop policy if exists app_ins on applications;
create policy app_ins on applications for insert with check (
  applicant_id = (select auth.uid()) and status = 'submitted' and (
    (campaign_id is not null and project_id is null
      and exists (select 1 from creators c where c.user_id = (select auth.uid()) and c.status = 'approved')
      and exists (select 1 from campaigns k where k.id = campaign_id and k.approval = 'approved' and k.status = 'open'))
    or
    (project_id is not null and campaign_id is null
      and exists (select 1 from freelancers f where f.user_id = (select auth.uid()) and f.status = 'approved')
      and exists (select 1 from projects p where p.id = project_id and p.is_open and p.client_id <> (select auth.uid())))
  )
);

-- F-04: a new project cannot start with someone already assigned, or in a non-marketplace division.
drop policy if exists client_ins on projects;
create policy client_ins on projects for insert with check (
  client_id = (select auth.uid()) and status = 'not_started' and assignee_id is null
  and division in ('makepro', 'digixbite', 'freelance')
);

-- F-05: refunds can never add up to more than the order total, even if two are submitted at once.
create or replace function refunds_guard() returns trigger language plpgsql as $$
declare v_total int; v_done int;
begin
  select total_paise into v_total from orders where id = new.order_id for update; -- locks the order
  select coalesce(sum(amount_paise), 0) into v_done from refunds where order_id = new.order_id;
  if v_done + new.amount_paise > v_total then raise exception 'refund exceeds order total'; end if;
  return new;
end $$;
drop trigger if exists refunds_guard_trg on refunds;
create trigger refunds_guard_trg before insert on refunds for each row execute function refunds_guard();
create unique index if not exists refunds_utr_key on refunds (refund_utr) where refund_utr is not null;

-- F-06: one payment row per order.
create unique index if not exists payments_order_key on payments (order_id);

-- F-13: the private file path and seller id are no longer readable through the public API.
revoke select on products from anon, authenticated;
grant select (id, category_id, slug, title, description, price_paise, cover_url, is_active, created_at, updated_at) on products to anon, authenticated;

-- F-14: people can only mark their own alerts as read, not rewrite them.
revoke update on notifications from anon, authenticated;
grant update (read_at) on notifications to authenticated;
