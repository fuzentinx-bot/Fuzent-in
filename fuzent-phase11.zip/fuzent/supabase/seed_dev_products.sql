-- DEV ONLY. Placeholder rows so the store is not empty while testing.
-- Replace with your real products before launch. Upload the real file to the
-- private "products" storage bucket and set file_path to its path.
insert into product_categories (slug, name, sort_order) values ('templates','Templates',1),('sheets','Sheets',2),('kits','Kits',3)
on conflict (slug) do nothing;

insert into products (category_id, slug, title, description, price_paise, file_path)
select id, 'dev-sample-template', 'DEV SAMPLE: Template', 'Placeholder product for testing checkout.', 10000, 'dev/sample.pdf'
from product_categories where slug = 'templates' on conflict (slug) do nothing;
