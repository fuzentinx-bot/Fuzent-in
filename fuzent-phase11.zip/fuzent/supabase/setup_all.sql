-- ==============================================================
-- FUZENT: complete database setup, ONE file. Run once on a NEW Supabase project.
-- Supabase: SQL Editor > New query > paste everything > Run.
-- Order inside: base schema, migrations 002 to 008, then storage bucket.
-- If it stops with an error, nothing is half-applied (it runs as one block): fix and run again.
-- ==============================================================

-- ########## 1. BASE SCHEMA (fuzent_schema_v1.sql) ##########
-- =====================================================================
-- FUZENT  |  Database schema v1  |  Supabase / PostgreSQL
-- Money is stored in paise (integer). Currency: INR.
-- Payments/payment_events are written ONLY by the server (service role).
-- Run in order. Review every policy before going live.
-- =====================================================================

create extension if not exists pgcrypto;
create extension if not exists citext;

-- ---------- ENUMS ----------------------------------------------------
create type division        as enum ('digital','makepro','digixbite','creators','freelance');
create type approval_status as enum ('pending','approved','rejected','suspended');
create type order_status    as enum ('pending','confirmed','processing','in_progress','under_review','completed','cancelled','refunded');
create type payment_status  as enum ('created','pending','paid','failed','refunded','partially_refunded');
create type invoice_status  as enum ('draft','issued','paid','void');
create type project_status  as enum ('not_started','in_progress','under_review','completed','on_hold','cancelled');
create type qr_type         as enum ('payment','order','business','custom');
create type ticket_status   as enum ('open','pending','resolved','closed');
create type application_status as enum ('submitted','shortlisted','accepted','rejected','withdrawn');

-- ---------- HELPERS --------------------------------------------------
create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- IDENTITY & RBAC -----------------------------------------
create table roles (
  id          smallint primary key generated always as identity,
  key         text unique not null,   -- super_admin, admin, customer, freelancer, creator, brand, business_client
  label       text not null
);
insert into roles (key,label) values
  ('super_admin','Super Admin'),('admin','Administrator'),('customer','Customer'),
  ('freelancer','Freelancer'),('creator','Creator'),('brand','Brand'),('business_client','Business Client');

create table permissions (
  id    int primary key generated always as identity,
  key   text unique not null           -- e.g. orders.read_all, products.write
);
create table role_permissions (
  role_id       smallint references roles(id) on delete cascade,
  permission_id int references permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

create table profiles (               -- 1:1 with auth.users
  id          uuid primary key references auth.users(id) on delete cascade,
  email       citext unique not null,
  full_name   text,
  phone       text,
  avatar_url  text,
  city        text,
  locale      text not null default 'en',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger trg_profiles_upd before update on profiles for each row execute function set_updated_at();

create table user_roles (
  user_id uuid references profiles(id) on delete cascade,
  role_id smallint references roles(id) on delete cascade,
  granted_at timestamptz not null default now(),
  primary key (user_id, role_id)
);
create index on user_roles (role_id);

-- Auto-create profile + default 'customer' role on signup
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  insert into user_roles (user_id, role_id)
  select new.id, id from roles where key = 'customer';
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Role checks (security definer avoids RLS recursion)
create or replace function has_role(_key text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles ur join roles r on r.id = ur.role_id
                 where ur.user_id = auth.uid() and r.key = _key);
$$;
create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles ur join roles r on r.id = ur.role_id
                 where ur.user_id = auth.uid() and r.key in ('admin','super_admin'));
$$;

-- ---------- ROLE PROFILES -------------------------------------------
create table customers (               -- billing identity for customers / business clients
  user_id      uuid primary key references profiles(id) on delete cascade,
  company_name text,
  gstin        text,
  billing_address jsonb,
  created_at   timestamptz not null default now()
);

create table creators (
  user_id      uuid primary key references profiles(id) on delete cascade,
  handle       text unique not null,
  bio          text,
  niche        text[],
  social_links jsonb not null default '{}',   -- {instagram:'', youtube:''}
  portfolio    jsonb not null default '[]',
  status       approval_status not null default 'pending',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create table freelancers (
  user_id      uuid primary key references profiles(id) on delete cascade,
  headline     text,
  skills       text[],
  experience   text,
  portfolio    jsonb not null default '[]',
  hourly_rate_paise int,
  status       approval_status not null default 'pending',
  rating_avg   numeric(3,2) not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create table brands (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null references profiles(id) on delete cascade,
  name         text not null,
  website      text,
  industry     text,
  logo_url     text,
  status       approval_status not null default 'pending',
  created_at   timestamptz not null default now()
);
create index on brands (owner_id);

-- ---------- CATALOG --------------------------------------------------
create table product_categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null, name text not null, sort_order int not null default 0
);
create table products (                -- Fuzent Digital
  id            uuid primary key default gen_random_uuid(),
  category_id   uuid references product_categories(id),
  seller_id     uuid references profiles(id),     -- null = FUZENT; set for creator-sold products
  slug          text unique not null,
  title         text not null,
  description   text,
  price_paise   int not null check (price_paise >= 0),
  file_path     text,                              -- private storage path, never public
  cover_url     text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on products (category_id);
create index on products (seller_id);

create table service_categories (
  id uuid primary key default gen_random_uuid(),
  division division not null check (division in ('makepro','digixbite')),
  slug text unique not null, name text not null
);
create table services (                -- MakePro / DigixBite packages
  id            uuid primary key default gen_random_uuid(),
  category_id   uuid references service_categories(id),
  division      division not null check (division in ('makepro','digixbite','freelance')),
  provider_id   uuid references profiles(id),      -- freelancer for marketplace listings
  slug          text unique not null,
  title         text not null,
  description   text,
  price_paise   int,                               -- null = custom quote
  billing       text not null default 'one_time',  -- one_time | monthly
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

create table coupons (
  id uuid primary key default gen_random_uuid(),
  code citext unique not null,
  percent_off smallint check (percent_off between 1 and 100),
  amount_off_paise int,
  valid_from timestamptz, valid_until timestamptz,
  max_redemptions int, redeemed int not null default 0,
  is_active boolean not null default true
);

-- ---------- ORDERS & PAYMENTS ---------------------------------------
create sequence order_seq start 1001;
create table orders (                  -- single table for all divisions
  id            uuid primary key default gen_random_uuid(),
  order_no      text unique not null default ('FZ-' || to_char(now(),'YY') || '-' || nextval('order_seq')),
  customer_id   uuid not null references profiles(id),
  division      division not null,
  status        order_status not null default 'pending',
  payment_status payment_status not null default 'created',
  subtotal_paise int not null check (subtotal_paise >= 0),
  discount_paise int not null default 0,
  tax_paise      int not null default 0,
  total_paise    int not null check (total_paise >= 0),
  coupon_id     uuid references coupons(id),
  requirements  jsonb not null default '{}',
  admin_notes   text,                              -- internal only
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on orders (customer_id, created_at desc);
create index on orders (status);
create trigger trg_orders_upd before update on orders for each row execute function set_updated_at();

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id),
  service_id uuid references services(id),
  title_snapshot text not null,
  unit_price_paise int not null,
  quantity int not null default 1 check (quantity > 0),
  check (num_nonnulls(product_id, service_id) = 1)
);
create index on order_items (order_id);

create table payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id),
  gateway text not null default 'upi_direct',
  gateway_order_id text unique,   -- unused with direct UPI
  gateway_payment_id text unique,
  method text,                                    -- upi, card, netbanking, wallet
  amount_paise int not null,
  status payment_status not null default 'created',
  failure_reason text,
  verified_at timestamptz,                        -- set ONLY after webhook/API verification
  created_at timestamptz not null default now()
);
create index on payments (order_id);

create table payment_events (          -- raw webhook log, idempotency
  id uuid primary key default gen_random_uuid(),
  gateway_event_id text unique not null,
  payment_id uuid references payments(id),
  event_type text not null,
  payload jsonb not null,
  signature_valid boolean not null,
  processed_at timestamptz,
  created_at timestamptz not null default now()
);

create table invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_no text unique not null,
  order_id uuid not null references orders(id),
  customer_id uuid not null references profiles(id),
  status invoice_status not null default 'draft',
  seller_gstin text, buyer_gstin text,
  sac_hsn text,
  subtotal_paise int not null, discount_paise int not null default 0,
  cgst_paise int not null default 0, sgst_paise int not null default 0, igst_paise int not null default 0,
  total_paise int not null,
  pdf_path text,
  issued_at timestamptz,
  created_at timestamptz not null default now()
);
create index on invoices (customer_id);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  service_id uuid references services(id),
  gateway_subscription_id text unique,
  status text not null default 'active',
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

-- ---------- QR -------------------------------------------------------
create table qr_codes (
  id uuid primary key default gen_random_uuid(),
  type qr_type not null,
  label text,
  order_id uuid references orders(id),
  target_url text,                                -- for order/business/custom
  upi_payload jsonb,                              -- merchant VPA, name, amount, ref (payment QR)
  style jsonb not null default '{}',              -- colors, logo, size
  is_active boolean not null default true,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);
create table qr_scans (
  id bigint primary key generated always as identity,
  qr_id uuid not null references qr_codes(id) on delete cascade,
  scanned_at timestamptz not null default now(),
  user_agent text, country text
);
create index on qr_scans (qr_id, scanned_at desc);

-- ---------- PROJECTS & MARKETPLACE ----------------------------------
create table projects (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id),
  division division not null,
  client_id uuid not null references profiles(id),
  assignee_id uuid references profiles(id),
  title text not null, brief text,
  status project_status not null default 'not_started',
  budget_paise int, due_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on projects (client_id);
create index on projects (assignee_id);
create table project_milestones (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null, due_date date,
  status project_status not null default 'not_started',
  sort_order int not null default 0
);
create table campaigns (               -- brand -> creator collaborations
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references brands(id) on delete cascade,
  title text not null, brief text,
  budget_paise int, deliverables jsonb not null default '[]',
  status text not null default 'draft',          -- draft | open | closed
  approval approval_status not null default 'pending',
  created_at timestamptz not null default now()
);
create table applications (            -- creators->campaigns, freelancers->projects
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null references profiles(id) on delete cascade,
  campaign_id uuid references campaigns(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  pitch text, quote_paise int,
  status application_status not null default 'submitted',
  created_at timestamptz not null default now(),
  check (num_nonnulls(campaign_id, project_id) = 1),
  unique (applicant_id, campaign_id), unique (applicant_id, project_id)
);
create table reviews (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles(id) on delete cascade,
  product_id uuid references products(id), service_id uuid references services(id),
  freelancer_id uuid references freelancers(user_id),
  order_id uuid references orders(id),           -- verified-purchase link
  rating smallint not null check (rating between 1 and 5),
  body text, is_published boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- COMMUNICATION -------------------------------------------
create table conversations (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id), project_id uuid references projects(id),
  created_at timestamptz not null default now()
);
create table conversation_members (
  conversation_id uuid references conversations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (conversation_id, user_id)
);
create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  body text not null, attachments jsonb not null default '[]',
  created_at timestamptz not null default now()
);
create index on messages (conversation_id, created_at);
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text not null, body text, link text,
  read_at timestamptz, created_at timestamptz not null default now()
);
create index on notifications (user_id, created_at desc);
create table support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  order_id uuid references orders(id),
  subject text not null, body text not null,
  status ticket_status not null default 'open',
  created_at timestamptz not null default now()
);

-- ---------- OPS ------------------------------------------------------
create table automation_events (       -- queue for the automation engine
  id uuid primary key default gen_random_uuid(),
  event_type text not null,            -- order.created, payment.verified, ...
  payload jsonb not null,
  attempts int not null default 0,
  processed_at timestamptz, error text,
  created_at timestamptz not null default now()
);
create index on automation_events (processed_at) where processed_at is null;
create table audit_logs (
  id bigint primary key generated always as identity,
  actor_id uuid, action text not null, entity text, entity_id text,
  meta jsonb, created_at timestamptz not null default now()
);
create table website_settings (
  key text primary key, value jsonb not null, updated_at timestamptz not null default now()
);

-- =====================================================================
-- ROW LEVEL SECURITY  (deny by default, then allow)
-- =====================================================================
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- Admin: full access on everything except secrets-by-design tables handled below
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public'
           and tablename not in ('payments','payment_events','audit_logs') loop
    execute format('create policy admin_all on public.%I for all using (is_admin()) with check (is_admin())', t);
  end loop;
end $$;
create policy admin_read on payments        for select using (is_admin());
create policy admin_read on payment_events  for select using (is_admin());
create policy admin_read on audit_logs      for select using (is_admin());
-- No insert/update policies on payments, payment_events, audit_logs:
-- only the server (service role) can write them.

-- Public catalog
create policy public_read on product_categories for select using (true);
create policy public_read on service_categories for select using (true);
create policy public_read on products  for select using (is_active);
create policy public_read on services  for select using (is_active);
create policy public_read on website_settings for select using (key like 'public.%');
create policy public_read on reviews   for select using (is_published);
create policy public_read on creators  for select using (status = 'approved');
create policy public_read on freelancers for select using (status = 'approved');
create policy public_read on campaigns for select using (approval = 'approved' and status = 'open');

-- Own-data policies
create policy own on profiles for select using (id = auth.uid());
create policy own_upd on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy own on user_roles for select using (user_id = auth.uid());
create policy own on customers  for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own on creators   for all using (user_id = auth.uid()) with check (user_id = auth.uid() and status = 'pending');
create policy own on freelancers for all using (user_id = auth.uid()) with check (user_id = auth.uid() and status = 'pending');
create policy own on brands     for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy own on subscriptions for select using (user_id = auth.uid());
create policy own on notifications for select using (user_id = auth.uid());
create policy own_upd on notifications for update using (user_id = auth.uid());
create policy own on support_tickets for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Orders: customers read their own; creation goes through server actions (price computed server-side)
create policy own on orders      for select using (customer_id = auth.uid());
create policy own on order_items for select using (exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));
create policy own on payments    for select using (exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));
create policy own on invoices    for select using (customer_id = auth.uid() and status <> 'draft');
create policy own on qr_codes    for select using (created_by = auth.uid());

-- Projects & applications
create policy parties on projects for select using (client_id = auth.uid() or assignee_id = auth.uid());
create policy parties on project_milestones for select using (exists (select 1 from projects p where p.id = project_id and (p.client_id = auth.uid() or p.assignee_id = auth.uid())));
create policy own on applications for all using (applicant_id = auth.uid()) with check (applicant_id = auth.uid());
create policy brand_sees on applications for select using (exists (select 1 from campaigns c join brands b on b.id = c.brand_id where c.id = campaign_id and b.owner_id = auth.uid()));
create policy brand_campaigns on campaigns for all using (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()))
  with check (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()) and approval = 'pending');
create policy own on reviews for insert with check (author_id = auth.uid());

-- Messaging: members only
create policy members on conversation_members for select using (user_id = auth.uid());
create policy members on conversations for select using (exists (select 1 from conversation_members m where m.conversation_id = id and m.user_id = auth.uid()));
create policy members_read on messages for select using (exists (select 1 from conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));
create policy members_write on messages for insert with check (sender_id = auth.uid() and exists (select 1 from conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));

-- NOTE: orders.admin_notes must never reach customers. Expose orders to the
-- client through a view without admin_notes, or select explicit columns.
-- Digital downloads: serve via signed URLs generated server-side after verifying a paid order.

-- ########## 002_upi_direct.sql ##########
-- Direct UPI payments (no third-party gateway). Run after fuzent_schema_v1.sql.
-- payments.status meaning:
--   created = waiting for the customer to pay and submit a transaction ID (UTR)
--   pending = UTR submitted, waiting for an admin to check it against the bank
--   paid    = admin confirmed the credit in the bank account
alter table payments
  add column if not exists utr text,
  add column if not exists submitted_at timestamptz,
  add column if not exists verified_by uuid references profiles(id);
alter table payments alter column gateway set default 'upi_direct';
-- One UTR can only ever back one payment.
create unique index if not exists payments_utr_key on payments (utr) where utr is not null;

-- ########## 003_cart_coupons_refunds_invoices.sql ##########
-- Run after 002. Cart, coupon rules, refunds, invoice numbering.
create table if not exists cart_items (
  user_id uuid references profiles(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  qty int not null default 1 check (qty between 1 and 10),
  primary key (user_id, product_id)
);
alter table cart_items enable row level security;
create policy own on cart_items for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table coupons
  add column if not exists min_order_paise int not null default 0,
  add column if not exists one_per_user boolean not null default true;

create table if not exists coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references coupons(id),
  user_id uuid not null references profiles(id),
  order_id uuid not null unique references orders(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table coupon_redemptions enable row level security;
create policy admin_all on coupon_redemptions for all using (is_admin()) with check (is_admin());
create policy own on coupon_redemptions for select using (user_id = auth.uid());

create table if not exists refunds (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references payments(id),
  order_id uuid not null references orders(id),
  amount_paise int not null check (amount_paise > 0),
  reason text not null,
  refund_utr text,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);
create index if not exists refunds_order_idx on refunds (order_id);
alter table refunds enable row level security;
create policy admin_all on refunds for all using (is_admin()) with check (is_admin());
create policy own on refunds for select using (exists (select 1 from orders o where o.id = order_id and o.customer_id = auth.uid()));

alter table invoices
  add column if not exists lines jsonb not null default '[]',
  add column if not exists buyer_name text,
  add column if not exists seller_snapshot jsonb;
create unique index if not exists invoices_order_key on invoices (order_id);

create sequence if not exists invoice_seq start 1;
create or replace function next_invoice_no() returns text
language sql security definer set search_path = public as $$
  select 'FZ/' || to_char(now(), 'YY') || '/' || lpad(nextval('invoice_seq')::text, 5, '0')
$$;
revoke all on function next_invoice_no() from public, anon, authenticated; -- server (service role) only

-- ########## 004_creators_freelance.sql ##########
-- Run after 003. Marketplace: creators, brands, campaigns, freelancers, projects, messaging, reviews.
alter table projects add column if not exists is_open boolean not null default false,
                     add column if not exists skills text[] not null default '{}';
alter table freelancers add column if not exists display_name text;
alter table reviews add column if not exists project_id uuid unique references projects(id);
alter table conversations add column if not exists title text,
                          add column if not exists campaign_id uuid references campaigns(id);

-- People cannot approve themselves: only admins (or the server) may change status.
create or replace function protect_status() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not is_admin() then
    if tg_table_name = 'campaigns' then
      if new.approval is distinct from old.approval then raise exception 'not allowed'; end if;
    elsif new.status is distinct from old.status then raise exception 'not allowed'; end if;
  end if;
  return new;
end $$;
create trigger protect_creators    before update on creators    for each row execute function protect_status();
create trigger protect_freelancers before update on freelancers for each row execute function protect_status();
create trigger protect_brands      before update on brands      for each row execute function protect_status();
create trigger protect_campaigns   before update on campaigns   for each row execute function protect_status();

-- Replace the broad Phase 1 policies with narrower ones.
drop policy if exists own on creators;     drop policy if exists own on freelancers;
drop policy if exists own on brands;       drop policy if exists own on applications;
drop policy if exists brand_campaigns on campaigns; drop policy if exists own on reviews;

create policy own_sel on creators for select using (user_id = auth.uid());
create policy own_ins on creators for insert with check (user_id = auth.uid() and status = 'pending');
create policy own_upd on creators for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_sel on freelancers for select using (user_id = auth.uid());
create policy own_ins on freelancers for insert with check (user_id = auth.uid() and status = 'pending');
create policy own_upd on freelancers for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_sel on brands for select using (owner_id = auth.uid());
create policy own_ins on brands for insert with check (owner_id = auth.uid() and status = 'pending');
create policy own_upd on brands for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy brand_sel on campaigns for select using (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()));
create policy brand_ins on campaigns for insert with check (approval = 'pending' and exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid() and b.status = 'approved'));
create policy brand_upd on campaigns for update using (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()))
  with check (exists (select 1 from brands b where b.id = brand_id and b.owner_id = auth.uid()));

-- Applicants can create and read their own applications. Accept/reject/withdraw run on the server.
create policy app_sel on applications for select using (applicant_id = auth.uid());
create policy app_ins on applications for insert with check (applicant_id = auth.uid() and status = 'submitted');
create policy client_sees on applications for select using (exists (select 1 from projects p where p.id = project_id and p.client_id = auth.uid()));

-- Projects: open ones are visible to logged-in users; clients post their own.
create policy open_projects on projects for select to authenticated using (is_open);
create policy client_ins on projects for insert with check (client_id = auth.uid() and status = 'not_started');
-- Reviews have no client write policy: created by a server action after checking the project.

-- ########## 005_support_notifications.sql ##########
-- Run after 004. Support threads, contact messages, email log, automation claiming.
create table if not exists ticket_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references support_tickets(id) on delete cascade,
  author_id uuid not null references profiles(id),
  is_staff boolean not null default false,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists ticket_messages_idx on ticket_messages (ticket_id, created_at);
alter table ticket_messages enable row level security;
create policy admin_all on ticket_messages for all using (is_admin()) with check (is_admin());
create policy own_sel on ticket_messages for select using (exists (select 1 from support_tickets t where t.id = ticket_id and t.user_id = auth.uid()));
create policy own_ins on ticket_messages for insert with check (author_id = auth.uid() and is_staff = false and exists (select 1 from support_tickets t where t.id = ticket_id and t.user_id = auth.uid()));

-- Customers can open and read their tickets; status changes happen on the server or by admins.
drop policy if exists own on support_tickets;
create policy own_sel on support_tickets for select using (user_id = auth.uid());
create policy own_ins on support_tickets for insert with check (user_id = auth.uid() and status = 'open');

create table if not exists contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null, email text not null, message text not null,
  created_at timestamptz not null default now()
);
alter table contact_messages enable row level security;
create policy admin_all on contact_messages for all using (is_admin()) with check (is_admin());

create table if not exists email_log (
  id uuid primary key default gen_random_uuid(),
  to_email text not null, subject text not null,
  status text not null, error text,
  created_at timestamptz not null default now()
);
alter table email_log enable row level security;
create policy admin_read on email_log for select using (is_admin());

alter table automation_events add column if not exists claimed_at timestamptz;

-- ########## 006_dashboards.sql ##########
-- Run after 005. Dashboard settings: notification preferences and freelancer availability.
alter table profiles add column if not exists prefs jsonb not null default '{"email": true, "inapp": true}';
alter table freelancers add column if not exists available boolean not null default true;

-- ########## 007_scale.sql ##########
-- Run after 006. Indexes for the busiest queries, and cheaper row-level-security checks.
create index if not exists products_active_idx   on products (is_active, created_at desc);
create index if not exists creators_status_idx   on creators (status, created_at desc);
create index if not exists freelancers_status_idx on freelancers (status, created_at desc);
create index if not exists campaigns_open_idx    on campaigns (approval, status, created_at desc);
create index if not exists campaigns_brand_idx   on campaigns (brand_id);
create index if not exists applications_campaign_idx on applications (campaign_id, status);
create index if not exists applications_project_idx  on applications (project_id, status);
create index if not exists applications_applicant_idx on applications (applicant_id, created_at desc);
create index if not exists projects_open_idx     on projects (is_open, created_at desc);
create index if not exists tickets_user_idx      on support_tickets (user_id, status);
create index if not exists conv_members_user_idx on conversation_members (user_id);
create index if not exists orders_status_idx     on orders (payment_status, created_at desc);

-- Wrapping auth.uid() and is_admin() in a sub-select lets Postgres evaluate them once per
-- query instead of once per row. Same rules, much cheaper at volume.
do $$
declare r record;
begin
  for r in select tablename from pg_policies where schemaname = 'public' and policyname = 'admin_all' loop
    execute format('alter policy admin_all on public.%I using ((select is_admin())) with check ((select is_admin()))', r.tablename);
  end loop;
end $$;
alter policy own     on orders        using (customer_id = (select auth.uid()));
alter policy own     on notifications using (user_id = (select auth.uid()));
alter policy own_upd on notifications using (user_id = (select auth.uid()));
alter policy own     on user_roles    using (user_id = (select auth.uid()));
alter policy own     on cart_items    using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- ########## 008_security_hardening.sql ##########
-- Run after 007. Security hardening from the audit (see SECURITY-AUDIT.md). Additive: no data is deleted.

-- F-02 / F-03: people must not edit their own rating, email or active flag.
create or replace function protect_columns() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not is_admin() then
    if tg_table_name = 'profiles' then
      if new.email is distinct from old.email or new.is_active is distinct from old.is_active then raise exception 'not allowed'; end if;
    elsif tg_table_name = 'freelancers' then
      if new.rating_avg is distinct from old.rating_avg then raise exception 'not allowed'; end if;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists protect_profiles_cols on profiles;
create trigger protect_profiles_cols before update on profiles for each row execute function protect_columns();
drop trigger if exists protect_freelancers_cols on freelancers;
create trigger protect_freelancers_cols before update on freelancers for each row execute function protect_columns();

-- F-01: the rules for applying now live in the database, so calling the API directly cannot bypass them.
drop policy if exists app_ins on applications;
create policy app_ins on applications for insert with check (
  applicant_id = (select auth.uid()) and status = 'submitted' and (
    (campaign_id is not null and project_id is null
      and exists (select 1 from creators c where c.user_id = (select auth.uid()) and c.status = 'approved')
      and exists (select 1 from campaigns k where k.id = campaign_id and k.approval = 'approved' and k.status = 'open'))
    or
    (project_id is not null and campaign_id is null
      and exists (select 1 from freelancers f where f.user_id = (select auth.uid()) and f.status = 'approved')
      and exists (select 1 from projects p where p.id = project_id and p.is_open and p.client_id <> (select auth.uid())))
  )
);

-- F-04: a new project cannot start with someone already assigned, or in a non-marketplace division.
drop policy if exists client_ins on projects;
create policy client_ins on projects for insert with check (
  client_id = (select auth.uid()) and status = 'not_started' and assignee_id is null
  and division in ('makepro', 'digixbite', 'freelance')
);

-- F-05: refunds can never add up to more than the order total, even if two are submitted at once.
create or replace function refunds_guard() returns trigger language plpgsql as $$
declare v_total int; v_done int;
begin
  select total_paise into v_total from orders where id = new.order_id for update; -- locks the order
  select coalesce(sum(amount_paise), 0) into v_done from refunds where order_id = new.order_id;
  if v_done + new.amount_paise > v_total then raise exception 'refund exceeds order total'; end if;
  return new;
end $$;
drop trigger if exists refunds_guard_trg on refunds;
create trigger refunds_guard_trg before insert on refunds for each row execute function refunds_guard();
create unique index if not exists refunds_utr_key on refunds (refund_utr) where refund_utr is not null;

-- F-06: one payment row per order.
create unique index if not exists payments_order_key on payments (order_id);

-- F-13: the private file path and seller id are no longer readable through the public API.
revoke select on products from anon, authenticated;
grant select (id, category_id, slug, title, description, price_paise, cover_url, is_active, created_at, updated_at) on products to anon, authenticated;

-- F-14: people can only mark their own alerts as read, not rewrite them.
revoke update on notifications from anon, authenticated;
grant update (read_at) on notifications to authenticated;

-- ########## Private storage bucket for paid files ##########
insert into storage.buckets (id, name, public) values ('products', 'products', false) on conflict (id) do nothing;
