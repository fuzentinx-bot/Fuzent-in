-- RLS and rules test for STAGING ONLY (never production). Run in the Supabase SQL Editor after setup_all.sql.
-- Everything runs inside one transaction and is rolled back at the end. Each check prints PASS or FAIL as a notice.
begin;
do $$
declare a uuid := gen_random_uuid(); b uuid := gen_random_uuid(); ok boolean; n int; oid uuid; pid uuid;
begin
  insert into auth.users (id, email) values (a, 'test-a@example.invalid'), (b, 'test-b@example.invalid');
  select id into pid from products limit 1;
  insert into orders (customer_id, division, subtotal_paise, total_paise) values (a, 'digital', 10000, 10000) returning id into oid;

  -- as user B
  perform set_config('request.jwt.claims', json_build_object('sub', b, 'role', 'authenticated')::text, true);
  set local role authenticated;

  select count(*) into n from orders where id = oid;
  raise notice '% B cannot read A''s order', case when n = 0 then 'PASS' else 'FAIL' end;

  begin insert into user_roles (user_id, role_id) select b, id from roles where key = 'super_admin'; ok := false;
  exception when others then ok := true; end;
  raise notice '% B cannot give himself admin', case when ok then 'PASS' else 'FAIL' end;

  begin update orders set payment_status = 'paid' where id = oid; get diagnostics n = row_count; ok := (n = 0);
  exception when others then ok := true; end;
  raise notice '% B cannot mark an order paid', case when ok then 'PASS' else 'FAIL' end;

  begin update profiles set email = 'x@example.invalid' where id = b; ok := false;
  exception when others then ok := true; end;
  raise notice '% B cannot change his profile email', case when ok then 'PASS' else 'FAIL' end;

  begin insert into applications (applicant_id, project_id, status) values (b, gen_random_uuid(), 'submitted'); ok := false;
  exception when others then ok := true; end;
  raise notice '% B cannot apply without being an approved freelancer', case when ok then 'PASS' else 'FAIL' end;

  begin perform file_path from products limit 1; ok := false;
  exception when others then ok := true; end;
  raise notice '% private file path is not readable', case when ok then 'PASS' else 'FAIL' end;

  reset role;
  perform set_config('request.jwt.claims', json_build_object('role', 'anon')::text, true);
  set local role anon;
  select count(*) into n from orders;
  raise notice '% anonymous visitors see no orders', case when n = 0 then 'PASS' else 'FAIL' end;
  reset role;
end $$;
rollback;
