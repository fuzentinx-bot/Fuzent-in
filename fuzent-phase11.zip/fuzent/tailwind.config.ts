import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        forest: { DEFAULT: '#0A3F2F', 2: '#0F5A43', deep: '#072B21' },
        cream: '#F3F0E4',
        lime: '#C6EC7B',
        tan: '#8F6B45',
      },
      fontFamily: { sans: ['var(--font-sans)', 'system-ui', 'sans-serif'] },
      boxShadow: { sticker: '4px 4px 0 #0A3F2F' },
    },
  },
  plugins: [],
};
export default config;
