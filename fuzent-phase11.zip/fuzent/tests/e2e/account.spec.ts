import { test, expect } from '@playwright/test';

// Needs a real TEST account on staging: E2E_EMAIL and E2E_PASSWORD (a normal customer, not an admin).
const email = process.env.E2E_EMAIL, password = process.env.E2E_PASSWORD;
test.skip(!email || !password, 'E2E_EMAIL and E2E_PASSWORD not set');

test('login, see dashboard, cannot reach admin, log out', async ({ page }) => {
  await page.goto('/login');
  await page.fill('input[name="email"]', email!);
  await page.fill('input[name="password"]', password!);
  await page.getByRole('button', { name: 'Log in' }).click();
  await expect(page).toHaveURL(/\/dashboard/);
  expect((await page.goto('/admin'))?.status()).toBe(404); // normal users must not see the admin area
  await page.goto('/dashboard');
  await page.getByRole('button', { name: 'Log out' }).click();
  await page.goto('/orders');
  await expect(page).toHaveURL(/\/login/);
});

test('wrong password shows a generic error', async ({ page }) => {
  await page.goto('/login');
  await page.fill('input[name="email"]', email!);
  await page.fill('input[name="password"]', 'definitely-wrong-password');
  await page.getByRole('button', { name: 'Log in' }).click();
  await expect(page.getByRole('alert')).toContainText('Email or password is wrong');
});

test('data export returns only JSON for the signed-in person', async ({ page }) => {
  await page.goto('/login');
  await page.fill('input[name="email"]', email!);
  await page.fill('input[name="password"]', password!);
  await page.getByRole('button', { name: 'Log in' }).click();
  await expect(page).toHaveURL(/\/dashboard/);
  const r = await page.request.get('/api/account/export');
  expect(r.status()).toBe(200);
  const body = await r.json();
  expect(body.account.email).toBe(email);
});
