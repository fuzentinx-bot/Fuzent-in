import { test, expect } from '@playwright/test';

const PUBLIC = ['/', '/store', '/creators', '/freelance', '/makepro', '/digixbite', '/pricing', '/faq', '/contact', '/login', '/privacy', '/terms'];
const WIDTHS = [320, 360, 375, 390, 414, 430, 600, 768, 820, 1024, 1280, 1366, 1440, 1536, 1600, 1920, 2560];

test('health endpoint answers and leaks nothing', async ({ request }) => {
  const r = await request.get('/api/health');
  expect([200, 503]).toContain(r.status());
  expect(Object.keys(await r.json())).toEqual(['ok']);
});

test('security headers are present', async ({ request }) => {
  const h = (await request.get('/')).headers();
  expect(h['x-frame-options']).toBe('DENY');
  expect(h['x-content-type-options']).toBe('nosniff');
  expect(h['content-security-policy']).toContain("frame-ancestors 'none'");
  expect(h['x-powered-by']).toBeUndefined();
});

for (const path of ['/dashboard', '/admin', '/orders', '/cart', '/freelancer', '/brand', '/my-data']) {
  test(`${path} sends a logged-out visitor to login`, async ({ page }) => {
    await page.goto(path);
    await expect(page).toHaveURL(/\/login/);
  });
}

test('private API routes refuse anonymous callers', async ({ request }) => {
  expect((await request.get('/api/account/export')).status()).toBe(401);
  expect((await request.get('/api/cron/automation')).status()).toBeGreaterThanOrEqual(401);
  expect([401, 404]).toContain((await request.get('/api/download/00000000-0000-0000-0000-000000000000')).status());
});

test('open redirect is blocked on login', async ({ page }) => {
  await page.goto('/login?next=//evil.example');
  await expect(page.locator('input[name="next"]')).toHaveValue('/dashboard');
});

test('mobile menu opens', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 800 });
  await page.goto('/');
  await page.getByText('Menu', { exact: true }).click();
  await expect(page.getByRole('link', { name: 'Store' }).first()).toBeVisible();
});

for (const w of WIDTHS) {
  test(`no sideways scrolling at ${w}px`, async ({ page }) => {
    await page.setViewportSize({ width: w, height: 800 });
    for (const path of PUBLIC) {
      await page.goto(path);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(overflow, `${path} at ${w}px`).toBeLessThanOrEqual(1);
    }
  });
}
