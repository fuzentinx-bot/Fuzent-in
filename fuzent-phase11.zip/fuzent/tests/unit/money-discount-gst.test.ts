import test from 'node:test';
import assert from 'node:assert/strict';
import { inr } from '../../src/lib/money.ts';
import { computeDiscount } from '../../src/lib/discount.ts';
import { splitGst } from '../../src/lib/gst.ts';

test('inr formats rupees from paise', () => {
  assert.match(inr(19900), /199/);
  assert.match(inr(19950), /199\.50/);
});
test('percent discount rounds down and never exceeds the subtotal', () => {
  assert.equal(computeDiscount({ percent_off: 10, amount_off_paise: null }, 19900), 1990);
  assert.equal(computeDiscount({ percent_off: 33, amount_off_paise: null }, 101), 33);
  assert.equal(computeDiscount({ percent_off: 100, amount_off_paise: null }, 5000), 5000);
});
test('rupee discount is capped at the subtotal and never negative', () => {
  assert.equal(computeDiscount({ percent_off: null, amount_off_paise: 50000 }, 19900), 19900);
  assert.equal(computeDiscount({ percent_off: null, amount_off_paise: 5000 }, 19900), 5000);
  assert.equal(computeDiscount({ percent_off: null, amount_off_paise: null }, 19900), 0);
});
test('GST split always adds back to the exact total (no lost paise)', () => {
  for (const total of [1, 99, 100, 19900, 123457, 999999]) for (const rate of [5, 12, 18, 28]) for (const same of [true, false]) {
    const r = splitGst(total, rate, same);
    assert.equal(r.taxable + r.cgst + r.sgst + r.igst, total, `${total} @${rate}%`);
    assert.ok(same ? r.igst === 0 : r.cgst === 0 && r.sgst === 0);
  }
});
test('no GST leaves the total untouched', () => {
  assert.deepEqual(splitGst(19900, 0, true), { taxable: 19900, cgst: 0, sgst: 0, igst: 0 });
});
