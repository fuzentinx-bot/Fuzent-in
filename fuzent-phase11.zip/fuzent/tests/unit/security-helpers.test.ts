import test from 'node:test';
import assert from 'node:assert/strict';
import { safeRedirectPath } from '../../src/lib/safe-redirect.ts';
import { parseLinks, isHttpsUrl } from '../../src/lib/urls.ts';
import { hitLimit } from '../../src/lib/mem-limit.ts';

test('redirects stay on the same site', () => {
  assert.equal(safeRedirectPath('/orders/1'), '/orders/1');
  for (const bad of ['//evil.com', 'https://evil.com', '/\\evil.com', 'javascript:alert(1)', '/a\r\nSet-Cookie: x', undefined, null, 42])
    assert.equal(safeRedirectPath(bad), '/dashboard', String(bad));
  assert.equal(safeRedirectPath('//x', '/home'), '/home');
});
test('only real https links are accepted', () => {
  assert.ok(isHttpsUrl('https://example.com/a'));
  for (const bad of ['http://example.com', 'javascript:alert(1)', 'data:text/html,hi', 'ftp://x.com', 'https://', 'not a url', ''])
    assert.ok(!isHttpsUrl(bad), bad);
});
test('portfolio links: all must be https, at most five are kept', () => {
  assert.deepEqual(parseLinks('https://a.com\nhttps://b.com'), ['https://a.com', 'https://b.com']);
  assert.equal(parseLinks('https://a.com\njavascript:alert(1)'), null);
  assert.equal(parseLinks('https://1.com,https://2.com,https://3.com,https://4.com,https://5.com,https://6.com')?.length, 5);
  assert.deepEqual(parseLinks(''), []);
});
test('limiter blocks after the allowed number and recovers after the window', async () => {
  const k = 'test-' + Math.random();
  assert.equal(hitLimit(k, 3, 50), false);
  assert.equal(hitLimit(k, 3, 50), false);
  assert.equal(hitLimit(k, 3, 50), false);
  assert.equal(hitLimit(k, 3, 50), true);
  await new Promise((r) => setTimeout(r, 70));
  assert.equal(hitLimit(k, 3, 50), false);
});
test('limiter keeps different people separate', () => {
  assert.equal(hitLimit('a-' + Math.random(), 1, 1000), false);
  assert.equal(hitLimit('b-' + Math.random(), 1, 1000), false);
});
