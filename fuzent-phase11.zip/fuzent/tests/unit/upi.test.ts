import test from 'node:test';
import assert from 'node:assert/strict';
import { upiQuery, VPA_RE, upiLinks } from '../../src/lib/upi.ts';

test('UPI query keeps the @ and uses %20, never +', () => {
  const q = upiQuery({ vpa: 'shop@okbank', name: 'My Shop', paise: 19900, ref: 'FZ-26-1001' });
  assert.match(q, /pa=shop@okbank/);
  assert.match(q, /pn=My%20Shop/);
  assert.ok(!q.includes('+'));
  assert.match(q, /am=199\.00/);
  assert.match(q, /cu=INR/);
  assert.match(q, /tr=FZ-26-1001/);
});
test('amount keeps two decimals', () => {
  assert.match(upiQuery({ vpa: 'a@b', name: 'x', paise: 5, ref: 'r' }), /am=0\.05/);
  assert.match(upiQuery({ vpa: 'a@b', name: 'x', paise: 100, ref: 'r' }), /am=1\.00/);
});
test('VPA validation accepts real IDs and rejects junk', () => {
  for (const ok of ['name@okhdfc', 'a.b-c_1@ybl', 'shop123@paytm']) assert.ok(VPA_RE.test(ok), ok);
  for (const bad of ['', 'a@', '@bank', 'a b@upi', 'x@y;drop', 'a@b@c', '<script>@x']) assert.ok(!VPA_RE.test(bad), bad);
});
test('every app link carries the same payment details', () => {
  const q = upiQuery({ vpa: 'a@b', name: 'x', paise: 100, ref: 'r' });
  for (const l of upiLinks(q)) assert.ok(l.href.endsWith(q));
});
